﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace Palitra
{
    public partial class StudentCardForm : Form
    {
        private readonly Student _student;

        // Карточка получает запись, только что прочитанную из базы по id
        public StudentCardForm(Student student)
        {
            InitializeComponent();
            Ui.Apply(this);

            _student = student;

            lblName.Text = _student.FullName;
            lblId.Text = "Код ученика: " + _student.Id;
            lblAge.Text = "Возраст: " + _student.Age + " лет";
            lblGroup.Text = "Направление: " + _student.Direction;
            lblFee.Text = "Стоимость обучения: " + _student.FeePerMonth.ToString("N2") + " руб./мес.";

            picCard.Image = Db.LoadImage(_student.ImagePath);
        }

        private void btnWord_Click(object sender, EventArgs e)
        {
            string path;
            try
            {
                Cursor = Cursors.WaitCursor;
                path = WordExporter.Create(_student);
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                ErrorGuard.Show("Не удалось создать документ Word", ex);
                return;
            }
            Cursor = Cursors.Default;

            lblFooter.Text = "Документ сохранён: " + Path.GetFileName(path);
            DialogResult open = MessageBox.Show("Документ создан:\n" + path +
                "\n\nОткрыть его сейчас?", "Word",
                MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (open != DialogResult.Yes) return;

            try
            {
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception)
            {
                MessageBox.Show("Файл создан, но открыть его не удалось: на компьютере " +
                    "нет программы для файлов .docx. Файл лежит в папке Документы, Palitra.");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
