﻿using System.Drawing;
using System.Windows.Forms;

namespace Palitra
{
    internal static class Ui
    {
        public static readonly Color Background = Color.FromArgb(246, 243, 238);
        public static readonly Color Accent = Color.FromArgb(52, 86, 108);
        public static readonly Color PanelColor = Color.FromArgb(255, 255, 255);

        public static void Apply(Control root)
        {
            foreach (Control c in root.Controls)
            {
                Button b = c as Button;
                if (b != null)
                {
                    b.FlatStyle = FlatStyle.Flat;
                    b.FlatAppearance.BorderSize = 0;
                    b.FlatAppearance.MouseOverBackColor = Color.FromArgb(78, 120, 148);
                    b.BackColor = Accent;
                    b.ForeColor = Color.White;
                    b.Font = new Font("Segoe UI", 9.75f, FontStyle.Bold);
                    b.Cursor = Cursors.Hand;
                    b.UseVisualStyleBackColor = false;
                }
                Apply(c);
            }
        }
    }
}