﻿using System;
using System.Windows.Forms;

namespace Palitra
{
    public partial class LessonsForm : Form
    {
        private class Lesson
        {
            public string Title;
            public string Teacher;
            public string Time;
            public string Place;
        }

        private readonly Lesson[] _lessons = new[]
        {
            new Lesson { Title = "Живопись. Натюрморт", Teacher = "Соколова А. П.", Time = "Пн, Ср 15:00–17:00", Place = "Кабинет 12" },
            new Lesson { Title = "Графика. Линия и штрих", Teacher = "Верещагин И. С.", Time = "Вт, Чт 14:00–16:00", Place = "Кабинет 08" },
            new Lesson { Title = "ДПИ. Керамика", Teacher = "Мельникова Е. А.", Time = "Сб 10:00–13:00", Place = "Мастерская 2" },
            new Lesson { Title = "Скульптура. Основы", Teacher = "Громов Д. В.", Time = "Ср 16:00–18:00", Place = "Мастерская 1" },
            new Lesson { Title = "Дизайн. Композиция", Teacher = "Ланская О. И.", Time = "Пт 15:00–17:00", Place = "Кабинет 15" }
        };

        public LessonsForm()
        {
            InitializeComponent();
            Ui.Apply(this);

            foreach (Lesson l in _lessons) lstLessons.Items.Add(l.Title);
            if (lstLessons.Items.Count > 0) lstLessons.SelectedIndex = 0;
        }

        private void lstLessons_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = lstLessons.SelectedIndex;
            if (i < 0) return;

            Lesson l = _lessons[i];
            lblLessonName.Text = l.Title;
            lblTeacher.Text = "Преподаватель: " + l.Teacher;
            lblTime.Text = "Время: " + l.Time;
            lblPlace.Text = "Место: " + l.Place;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}