﻿using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace Palitra
{
    // Защита от аварийного завершения. Любая непредвиденная ошибка
    // показывается пользователю понятным сообщением и записывается
    // в журнал errors.log, а программа продолжает работать.
    public static class ErrorGuard
    {
        public static string LogFile
        {
            get
            {
                string dir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Palitra");
                Directory.CreateDirectory(dir);
                return Path.Combine(dir, "errors.log");
            }
        }

        // Подключается один раз в Main до создания первой формы
        public static void Install()
        {
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += OnThreadException;
            AppDomain.CurrentDomain.UnhandledException += OnDomainException;
        }

        private static void OnThreadException(object sender, ThreadExceptionEventArgs e)
        {
            Show("Непредвиденная ошибка", e.Exception);
        }

        private static void OnDomainException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = e.ExceptionObject as Exception;
            Log(ex == null ? "неизвестная ошибка" : ex.ToString());
            MessageBox.Show("Программа столкнулась с ошибкой и будет закрыта.\n" +
                "Подробности записаны в файл:\n" + LogFile, "Палитра",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Выполнить действие; при ошибке показать сообщение «что не
        // получилось» и вернуть false вместо аварийного выхода
        public static bool Try(Action action, string what)
        {
            try
            {
                action();
                return true;
            }
            catch (ForbiddenException ex)
            {
                MessageBox.Show(ex.Message, "Нет прав",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message, "Палитра",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                Show(what, ex);
            }
            return false;
        }

        public static void Show(string what, Exception ex)
        {
            Log(what + ": " + ex);
            MessageBox.Show(what + ".\n\n" + Friendly(ex) +
                "\n\nПрограмма продолжает работу.", "Палитра",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Короткое объяснение без технических подробностей
        public static string Friendly(Exception ex)
        {
            string type = ex.GetType().Name;
            if (type == "NpgsqlException" || type == "SocketException" ||
                (ex.InnerException != null &&
                 ex.InnerException.GetType().Name == "SocketException"))
            {
                return "Нет связи с сервером базы данных. Проверьте, что служба " +
                    "PostgreSQL запущена, или переключитесь на SQLite " +
                    "в окне «Подключение к базе данных».";
            }
            if (ex is IOException || ex is UnauthorizedAccessException)
            {
                return "Не удалось прочитать или записать файл: " + ex.Message;
            }
            return ex.Message;
        }

        public static void Log(string text)
        {
            try
            {
                File.AppendAllText(LogFile, DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss") +
                    "  " + text + Environment.NewLine + Environment.NewLine);
            }
            catch
            {
                // журнал не обязателен: ошибка записи не должна мешать работе
            }
        }
    }
}
