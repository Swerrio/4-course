﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Npgsql;

namespace Palitra
{
    // Настройки подключения: вкладка PostgreSQL или вкладка SQLite.
    // Открывается из окна входа или сама, если при запуске база недоступна.
    public partial class ConnectionForm : Form
    {
        private readonly StorageKind oldKind = Storage.Kind;
        private readonly string oldPg = Storage.PgConnection;
        private readonly string oldFile = Storage.SqliteFile;

        public ConnectionForm(string error)
        {
            InitializeComponent();
            Ui.Apply(this);

            NpgsqlConnectionStringBuilder b;
            try
            {
                b = new NpgsqlConnectionStringBuilder(Storage.PgConnection);
            }
            catch (Exception)
            {
                b = new NpgsqlConnectionStringBuilder(Storage.DefaultPg);
            }
            txtHost.Text = b.Host;
            txtPort.Text = b.Port.ToString();
            txtDatabase.Text = b.Database;
            txtUser.Text = b.Username;
            txtPassword.Text = b.Password;
            txtFile.Text = Storage.SqliteFile;
            tabs.SelectedTab = Storage.Kind == StorageKind.Sqlite ? tabLite : tabPg;

            if (!string.IsNullOrEmpty(error))
            {
                lblInfo.ForeColor = Color.FromArgb(170, 50, 50);
                lblInfo.Text = "Подключиться не удалось: " + error;
            }
        }

        // Значения из полей в настройки. false, если поля заполнены неверно.
        private bool Apply()
        {
            if (tabs.SelectedTab == tabLite)
            {
                if (txtFile.Text.Trim().Length == 0)
                {
                    Result("Укажите файл базы SQLite.", false);
                    return false;
                }
                Storage.Kind = StorageKind.Sqlite;
                Storage.SqliteFile = txtFile.Text.Trim();
                return true;
            }

            int port;
            if (!int.TryParse(txtPort.Text.Trim(), out port) || port < 1 || port > 65535)
            {
                Result("Порт: целое число от 1 до 65535.", false);
                return false;
            }
            if (txtHost.Text.Trim().Length == 0 || txtDatabase.Text.Trim().Length == 0 ||
                txtUser.Text.Trim().Length == 0)
            {
                Result("Заполните сервер, базу данных и пользователя.", false);
                return false;
            }
            NpgsqlConnectionStringBuilder b = new NpgsqlConnectionStringBuilder();
            b.Host = txtHost.Text.Trim();
            b.Port = port;
            b.Database = txtDatabase.Text.Trim();
            b.Username = txtUser.Text.Trim();
            b.Password = txtPassword.Text;
            Storage.Kind = StorageKind.PostgreSql;
            Storage.PgConnection = b.ConnectionString;
            return true;
        }

        private void Result(string text, bool ok)
        {
            lblResult.ForeColor = ok ? Color.FromArgb(40, 120, 70) : Color.FromArgb(170, 50, 50);
            lblResult.Text = text;
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            if (!Apply()) return;
            Cursor = Cursors.WaitCursor;
            string error;
            bool ok = Storage.TryConnect(out error);
            Cursor = Cursors.Default;
            Result(ok ? "Подключение работает: " + Storage.Describe() + "."
                      : "Ошибка подключения: " + error, ok);
        }

        // «Сохранить»: база и таблицы создаются, если их ещё нет
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!Apply()) return;
            Cursor = Cursors.WaitCursor;
            string error;
            bool ok = Storage.TryInitialize(out error);
            Cursor = Cursors.Default;
            if (!ok)
            {
                Result("Ошибка подключения: " + error, false);
                return;
            }
            if (!Storage.Save())
            {
                MessageBox.Show("Подключение работает, но настройки не удалось " +
                    "записать в файл. Они будут действовать до закрытия программы.",
                    "Палитра", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            sfdFile.FileName = txtFile.Text;
            if (sfdFile.ShowDialog(this) == DialogResult.OK)
            {
                txtFile.Text = sfdFile.FileName;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        // Закрытие без сохранения возвращает прежние настройки
        private void ConnectionForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (DialogResult == DialogResult.OK) return;
            Storage.Kind = oldKind;
            Storage.PgConnection = oldPg;
            Storage.SqliteFile = oldFile;
        }
    }
}
