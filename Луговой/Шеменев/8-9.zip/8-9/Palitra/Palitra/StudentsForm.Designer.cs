﻿namespace Palitra
{
    partial class StudentsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.lblAppTitle = new System.Windows.Forms.Label();
            this.lblSection = new System.Windows.Forms.Label();
            this.grpData = new System.Windows.Forms.GroupBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.lblAgeHint = new System.Windows.Forms.Label();
            this.lblGroup = new System.Windows.Forms.Label();
            this.cmbGroup = new System.Windows.Forms.ComboBox();
            this.lblFee = new System.Windows.Forms.Label();
            this.txtFee = new System.Windows.Forms.TextBox();
            this.lblFeeHint = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblDataHint = new System.Windows.Forms.Label();
            this.grpCalc = new System.Windows.Forms.GroupBox();
            this.lblMonths = new System.Windows.Forms.Label();
            this.txtMonths = new System.Windows.Forms.TextBox();
            this.chkDiscount = new System.Windows.Forms.CheckBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.grpSearch = new System.Windows.Forms.GroupBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.dgvStudents = new System.Windows.Forms.DataGridView();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDirection = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEdit = new System.Windows.Forms.Button();
            this.grpFilter = new System.Windows.Forms.GroupBox();
            this.lblFilterDir = new System.Windows.Forms.Label();
            this.cmbFilterDir = new System.Windows.Forms.ComboBox();
            this.lblFilterAge = new System.Windows.Forms.Label();
            this.txtFilterAge = new System.Windows.Forms.TextBox();
            this.btnFilter = new System.Windows.Forms.Button();
            this.btnResetFilter = new System.Windows.Forms.Button();
            this.picWork = new System.Windows.Forms.PictureBox();
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.btnRemoveImage = new System.Windows.Forms.Button();
            this.btnCard = new System.Windows.Forms.Button();
            this.lblWorkHint = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnBackToMenu = new System.Windows.Forms.Button();
            this.panelTop.SuspendLayout();
            this.grpData.SuspendLayout();
            this.grpCalc.SuspendLayout();
            this.grpSearch.SuspendLayout();
            this.grpFilter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWork)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudents)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(86)))), ((int)(((byte)(108)))));
            this.panelTop.Controls.Add(this.lblAppTitle);
            this.panelTop.Controls.Add(this.lblSection);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(895, 52);
            this.panelTop.TabIndex = 0;
            // 
            // lblAppTitle
            // 
            this.lblAppTitle.AutoSize = true;
            this.lblAppTitle.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblAppTitle.ForeColor = System.Drawing.Color.White;
            this.lblAppTitle.Location = new System.Drawing.Point(14, 4);
            this.lblAppTitle.Name = "lblAppTitle";
            this.lblAppTitle.Size = new System.Drawing.Size(357, 28);
            this.lblAppTitle.TabIndex = 0;
            this.lblAppTitle.Text = "Художественная школа «Палитра»";
            // 
            // lblSection
            // 
            this.lblSection.AutoSize = true;
            this.lblSection.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(232)))), ((int)(((byte)(240)))));
            this.lblSection.Location = new System.Drawing.Point(16, 35);
            this.lblSection.Name = "lblSection";
            this.lblSection.Size = new System.Drawing.Size(320, 13);
            this.lblSection.TabIndex = 1;
            this.lblSection.Text = "Раздел: ученики, оплата и фото работ (данные из базы)";
            // 
            // grpData
            // 
            this.grpData.BackColor = System.Drawing.Color.White;
            this.grpData.Controls.Add(this.lblName);
            this.grpData.Controls.Add(this.txtName);
            this.grpData.Controls.Add(this.lblAge);
            this.grpData.Controls.Add(this.txtAge);
            this.grpData.Controls.Add(this.lblAgeHint);
            this.grpData.Controls.Add(this.lblGroup);
            this.grpData.Controls.Add(this.cmbGroup);
            this.grpData.Controls.Add(this.lblFee);
            this.grpData.Controls.Add(this.txtFee);
            this.grpData.Controls.Add(this.lblFeeHint);
            this.grpData.Controls.Add(this.btnAdd);
            this.grpData.Controls.Add(this.btnEdit);
            this.grpData.Controls.Add(this.btnDelete);
            this.grpData.Controls.Add(this.lblDataHint);
            this.grpData.Location = new System.Drawing.Point(10, 62);
            this.grpData.Name = "grpData";
            this.grpData.Size = new System.Drawing.Size(283, 217);
            this.grpData.TabIndex = 0;
            this.grpData.TabStop = false;
            this.grpData.Text = "Данные ученика";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(10, 23);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(37, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "ФИО:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(77, 21);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(194, 20);
            this.txtName.TabIndex = 1;
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(10, 53);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(52, 13);
            this.lblAge.TabIndex = 2;
            this.lblAge.Text = "Возраст:";
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(77, 50);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(78, 20);
            this.txtAge.TabIndex = 3;
            // 
            // lblAgeHint
            // 
            this.lblAgeHint.AutoSize = true;
            this.lblAgeHint.ForeColor = System.Drawing.Color.Gray;
            this.lblAgeHint.Location = new System.Drawing.Point(163, 53);
            this.lblAgeHint.Name = "lblAgeHint";
            this.lblAgeHint.Size = new System.Drawing.Size(62, 13);
            this.lblAgeHint.TabIndex = 4;
            this.lblAgeHint.Text = "лет (5–100)";
            // 
            // lblGroup
            // 
            this.lblGroup.AutoSize = true;
            this.lblGroup.Location = new System.Drawing.Point(10, 82);
            this.lblGroup.Name = "lblGroup";
            this.lblGroup.Size = new System.Drawing.Size(48, 13);
            this.lblGroup.TabIndex = 5;
            this.lblGroup.Text = "Кружок:";
            // 
            // cmbGroup
            // 
            this.cmbGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGroup.Location = new System.Drawing.Point(77, 80);
            this.cmbGroup.Name = "cmbGroup";
            this.cmbGroup.Size = new System.Drawing.Size(194, 21);
            this.cmbGroup.TabIndex = 6;
            // 
            // lblFee
            // 
            this.lblFee.AutoSize = true;
            this.lblFee.Location = new System.Drawing.Point(10, 112);
            this.lblFee.Name = "lblFee";
            this.lblFee.Size = new System.Drawing.Size(43, 13);
            this.lblFee.TabIndex = 7;
            this.lblFee.Text = "Месяц:";
            // 
            // txtFee
            // 
            this.txtFee.Location = new System.Drawing.Point(77, 109);
            this.txtFee.Name = "txtFee";
            this.txtFee.Size = new System.Drawing.Size(112, 20);
            this.txtFee.TabIndex = 8;
            // 
            // lblFeeHint
            // 
            this.lblFeeHint.AutoSize = true;
            this.lblFeeHint.ForeColor = System.Drawing.Color.Gray;
            this.lblFeeHint.Location = new System.Drawing.Point(197, 112);
            this.lblFeeHint.Name = "lblFeeHint";
            this.lblFeeHint.Size = new System.Drawing.Size(27, 13);
            this.lblFeeHint.TabIndex = 9;
            this.lblFeeHint.Text = "руб.";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(10, 146);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(82, 29);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            this.btnEdit.Location = new System.Drawing.Point(98, 146);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(82, 29);
            this.btnEdit.TabIndex = 11;
            this.btnEdit.Text = "Изменить";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(186, 146);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(85, 29);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lblDataHint
            // 
            this.lblDataHint.ForeColor = System.Drawing.Color.Gray;
            this.lblDataHint.Location = new System.Drawing.Point(10, 184);
            this.lblDataHint.Name = "lblDataHint";
            this.lblDataHint.Size = new System.Drawing.Size(262, 26);
            this.lblDataHint.TabIndex = 12;
            this.lblDataHint.Text = "Строка таблицы заполняет поля: исправьте их и нажмите «Изменить».";
            // 
            // grpCalc
            // 
            this.grpCalc.BackColor = System.Drawing.Color.White;
            this.grpCalc.Controls.Add(this.lblMonths);
            this.grpCalc.Controls.Add(this.txtMonths);
            this.grpCalc.Controls.Add(this.chkDiscount);
            this.grpCalc.Controls.Add(this.btnCalc);
            this.grpCalc.Controls.Add(this.lblResult);
            this.grpCalc.Location = new System.Drawing.Point(10, 289);
            this.grpCalc.Name = "grpCalc";
            this.grpCalc.Size = new System.Drawing.Size(283, 146);
            this.grpCalc.TabIndex = 1;
            this.grpCalc.TabStop = false;
            this.grpCalc.Text = "Расчёт стоимости обучения";
            // 
            // lblMonths
            // 
            this.lblMonths.AutoSize = true;
            this.lblMonths.Location = new System.Drawing.Point(10, 23);
            this.lblMonths.Name = "lblMonths";
            this.lblMonths.Size = new System.Drawing.Size(95, 13);
            this.lblMonths.TabIndex = 0;
            this.lblMonths.Text = "Месяцев оплаты:";
            // 
            // txtMonths
            // 
            this.txtMonths.Location = new System.Drawing.Point(129, 21);
            this.txtMonths.Name = "txtMonths";
            this.txtMonths.Size = new System.Drawing.Size(69, 20);
            this.txtMonths.TabIndex = 1;
            // 
            // chkDiscount
            // 
            this.chkDiscount.AutoSize = true;
            this.chkDiscount.Location = new System.Drawing.Point(10, 50);
            this.chkDiscount.Name = "chkDiscount";
            this.chkDiscount.Size = new System.Drawing.Size(147, 17);
            this.chkDiscount.TabIndex = 2;
            this.chkDiscount.Text = "Скидка 10% (льготники)";
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(10, 80);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(125, 29);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Рассчитать";
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lblResult
            // 
            this.lblResult.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(86)))), ((int)(((byte)(108)))));
            this.lblResult.Location = new System.Drawing.Point(10, 116);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(262, 23);
            this.lblResult.TabIndex = 4;
            this.lblResult.Text = "Итого: —";
            // 
            // lblCount
            // 
            this.lblCount.ForeColor = System.Drawing.Color.Gray;
            this.lblCount.Location = new System.Drawing.Point(10, 447);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(283, 21);
            this.lblCount.TabIndex = 2;
            this.lblCount.Text = "Показано: 0";
            // 
            // grpSearch
            // 
            this.grpSearch.BackColor = System.Drawing.Color.White;
            this.grpSearch.Controls.Add(this.txtSearch);
            this.grpSearch.Controls.Add(this.btnSearch);
            this.grpSearch.Controls.Add(this.btnAll);
            this.grpSearch.Location = new System.Drawing.Point(305, 62);
            this.grpSearch.Name = "grpSearch";
            this.grpSearch.Size = new System.Drawing.Size(283, 83);
            this.grpSearch.TabIndex = 2;
            this.grpSearch.TabStop = false;
            this.grpSearch.Text = "Поиск по ФИО или кружку";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(10, 23);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(163, 20);
            this.txtSearch.TabIndex = 0;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(180, 22);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(91, 23);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Найти";
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnAll
            // 
            this.btnAll.Location = new System.Drawing.Point(10, 52);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(261, 23);
            this.btnAll.TabIndex = 2;
            this.btnAll.Text = "Показать всех";
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // dgvStudents
            //
            this.dgvStudents.AllowUserToAddRows = false;
            this.dgvStudents.AllowUserToDeleteRows = false;
            this.dgvStudents.AllowUserToResizeRows = false;
            this.dgvStudents.AutoGenerateColumns = false;
            this.dgvStudents.BackgroundColor = System.Drawing.Color.White;
            this.dgvStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudents.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colName,
            this.colAge,
            this.colDirection});
            this.dgvStudents.Location = new System.Drawing.Point(305, 156);
            this.dgvStudents.MultiSelect = false;
            this.dgvStudents.Name = "dgvStudents";
            this.dgvStudents.ReadOnly = true;
            this.dgvStudents.RowHeadersVisible = false;
            this.dgvStudents.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStudents.Size = new System.Drawing.Size(283, 217);
            this.dgvStudents.TabIndex = 3;
            this.dgvStudents.SelectionChanged += new System.EventHandler(this.dgvStudents_SelectionChanged);
            //
            // colName
            //
            this.colName.DataPropertyName = "FullName";
            this.colName.HeaderText = "ФИО";
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            this.colName.Width = 140;
            //
            // colAge
            //
            this.colAge.DataPropertyName = "Age";
            this.colAge.HeaderText = "Лет";
            this.colAge.Name = "colAge";
            this.colAge.ReadOnly = true;
            this.colAge.Width = 40;
            //
            // colDirection
            //
            this.colDirection.DataPropertyName = "Direction";
            this.colDirection.HeaderText = "Кружок";
            this.colDirection.Name = "colDirection";
            this.colDirection.ReadOnly = true;
            this.colDirection.Width = 82;
            //
            // grpFilter
            // 
            this.grpFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.grpFilter.BackColor = System.Drawing.Color.White;
            this.grpFilter.Controls.Add(this.lblFilterDir);
            this.grpFilter.Controls.Add(this.cmbFilterDir);
            this.grpFilter.Controls.Add(this.lblFilterAge);
            this.grpFilter.Controls.Add(this.txtFilterAge);
            this.grpFilter.Controls.Add(this.btnFilter);
            this.grpFilter.Controls.Add(this.btnResetFilter);
            this.grpFilter.Location = new System.Drawing.Point(305, 383);
            this.grpFilter.Name = "grpFilter";
            this.grpFilter.Size = new System.Drawing.Size(283, 121);
            this.grpFilter.TabIndex = 4;
            this.grpFilter.TabStop = false;
            this.grpFilter.Text = "Фильтр учеников";
            // 
            // lblFilterDir
            // 
            this.lblFilterDir.AutoSize = true;
            this.lblFilterDir.Location = new System.Drawing.Point(10, 23);
            this.lblFilterDir.Name = "lblFilterDir";
            this.lblFilterDir.Size = new System.Drawing.Size(48, 13);
            this.lblFilterDir.TabIndex = 0;
            this.lblFilterDir.Text = "Кружок:";
            // 
            // cmbFilterDir
            // 
            this.cmbFilterDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilterDir.Location = new System.Drawing.Point(93, 21);
            this.cmbFilterDir.Name = "cmbFilterDir";
            this.cmbFilterDir.Size = new System.Drawing.Size(179, 21);
            this.cmbFilterDir.TabIndex = 1;
            // 
            // lblFilterAge
            // 
            this.lblFilterAge.AutoSize = true;
            this.lblFilterAge.Location = new System.Drawing.Point(10, 53);
            this.lblFilterAge.Name = "lblFilterAge";
            this.lblFilterAge.Size = new System.Drawing.Size(66, 13);
            this.lblFilterAge.TabIndex = 2;
            this.lblFilterAge.Text = "Возраст от:";
            // 
            // txtFilterAge
            // 
            this.txtFilterAge.Location = new System.Drawing.Point(93, 50);
            this.txtFilterAge.Name = "txtFilterAge";
            this.txtFilterAge.Size = new System.Drawing.Size(61, 20);
            this.txtFilterAge.TabIndex = 3;
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(163, 49);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(108, 23);
            this.btnFilter.TabIndex = 4;
            this.btnFilter.Text = "Применить";
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // btnResetFilter
            // 
            this.btnResetFilter.Location = new System.Drawing.Point(10, 83);
            this.btnResetFilter.Name = "btnResetFilter";
            this.btnResetFilter.Size = new System.Drawing.Size(261, 24);
            this.btnResetFilter.TabIndex = 5;
            this.btnResetFilter.Text = "Сбросить фильтр";
            this.btnResetFilter.Click += new System.EventHandler(this.btnResetFilter_Click);
            // 
            // picWork
            // 
            this.picWork.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picWork.BackColor = System.Drawing.Color.White;
            this.picWork.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picWork.Location = new System.Drawing.Point(600, 62);
            this.picWork.Name = "picWork";
            this.picWork.Size = new System.Drawing.Size(285, 260);
            this.picWork.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picWork.TabIndex = 5;
            this.picWork.TabStop = false;
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLoadImage.Location = new System.Drawing.Point(600, 331);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(137, 28);
            this.btnLoadImage.TabIndex = 6;
            this.btnLoadImage.Text = "Загрузить фото";
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // btnRemoveImage
            // 
            this.btnRemoveImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRemoveImage.Location = new System.Drawing.Point(746, 331);
            this.btnRemoveImage.Name = "btnRemoveImage";
            this.btnRemoveImage.Size = new System.Drawing.Size(139, 28);
            this.btnRemoveImage.TabIndex = 7;
            this.btnRemoveImage.Text = "Убрать фото";
            this.btnRemoveImage.Click += new System.EventHandler(this.btnRemoveImage_Click);
            // 
            // btnCard
            // 
            this.btnCard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCard.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnCard.Location = new System.Drawing.Point(600, 367);
            this.btnCard.Name = "btnCard";
            this.btnCard.Size = new System.Drawing.Size(285, 38);
            this.btnCard.TabIndex = 8;
            this.btnCard.Text = "Карточка ученика → Word";
            this.btnCard.Click += new System.EventHandler(this.btnCard_Click);
            // 
            // lblWorkHint
            // 
            this.lblWorkHint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblWorkHint.ForeColor = System.Drawing.Color.Gray;
            this.lblWorkHint.Location = new System.Drawing.Point(598, 407);
            this.lblWorkHint.Name = "lblWorkHint";
            this.lblWorkHint.Size = new System.Drawing.Size(285, 69);
            this.lblWorkHint.TabIndex = 9;
            this.lblWorkHint.Text = "1. Выберите ученика в списке.\r\n2. Загрузите jpg или png – фото появится выше.\r\n3." +
    " Нажмите «Карточка ученика», чтобы получить Word-документ.";
            // 
            // lblStatus
            // 
            this.lblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(240)))));
            this.lblStatus.Location = new System.Drawing.Point(7, 526);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.lblStatus.Size = new System.Drawing.Size(874, 38);
            this.lblStatus.TabIndex = 10;
            this.lblStatus.Text = "Готово. Выберите ученика в списке.";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnBackToMenu
            // 
            this.btnBackToMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBackToMenu.Location = new System.Drawing.Point(596, 492);
            this.btnBackToMenu.Name = "btnBackToMenu";
            this.btnBackToMenu.Size = new System.Drawing.Size(285, 31);
            this.btnBackToMenu.TabIndex = 11;
            this.btnBackToMenu.Text = "← Назад в главное меню";
            this.btnBackToMenu.Click += new System.EventHandler(this.btnBackToMenu_Click);
            // 
            // StudentsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(243)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(895, 573);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.grpData);
            this.Controls.Add(this.grpCalc);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.grpSearch);
            this.Controls.Add(this.dgvStudents);
            this.Controls.Add(this.grpFilter);
            this.Controls.Add(this.picWork);
            this.Controls.Add(this.btnLoadImage);
            this.Controls.Add(this.btnRemoveImage);
            this.Controls.Add(this.btnCard);
            this.Controls.Add(this.lblWorkHint);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnBackToMenu);
            this.MinimumSize = new System.Drawing.Size(911, 612);
            this.Name = "StudentsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Палитра — ученики и фото";
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.grpData.ResumeLayout(false);
            this.grpData.PerformLayout();
            this.grpCalc.ResumeLayout(false);
            this.grpCalc.PerformLayout();
            this.grpSearch.ResumeLayout(false);
            this.grpSearch.PerformLayout();
            this.grpFilter.ResumeLayout(false);
            this.grpFilter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWork)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudents)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblAppTitle;
        private System.Windows.Forms.Label lblSection;
        private System.Windows.Forms.GroupBox grpData;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblAgeHint;
        private System.Windows.Forms.Label lblGroup;
        private System.Windows.Forms.ComboBox cmbGroup;
        private System.Windows.Forms.Label lblFee;
        private System.Windows.Forms.TextBox txtFee;
        private System.Windows.Forms.Label lblFeeHint;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblDataHint;
        private System.Windows.Forms.GroupBox grpCalc;
        private System.Windows.Forms.Label lblMonths;
        private System.Windows.Forms.TextBox txtMonths;
        private System.Windows.Forms.CheckBox chkDiscount;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.GroupBox grpSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.DataGridView dgvStudents;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAge;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDirection;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.GroupBox grpFilter;
        private System.Windows.Forms.Label lblFilterDir;
        private System.Windows.Forms.ComboBox cmbFilterDir;
        private System.Windows.Forms.Label lblFilterAge;
        private System.Windows.Forms.TextBox txtFilterAge;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.Button btnResetFilter;
        private System.Windows.Forms.PictureBox picWork;
        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.Button btnRemoveImage;
        private System.Windows.Forms.Button btnCard;
        private System.Windows.Forms.Label lblWorkHint;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnBackToMenu;
    }
}