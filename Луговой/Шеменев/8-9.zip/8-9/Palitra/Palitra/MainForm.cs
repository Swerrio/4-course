﻿using System;
using System.Windows.Forms;

namespace Palitra
{
    // Главное меню работает как личный кабинет: набор кнопок зависит
    // от роли пользователя, под которым выполнен вход
    public partial class MainForm : Form
    {
        public bool SignedOut;

        public MainForm()
        {
            InitializeComponent();
            Ui.Apply(this);
            ShowCabinet();
            UpdateStats();
        }

        private void ShowCabinet()
        {
            AppUser u = Auth.User;
            lblWelcome.Text = "Добро пожаловать, " + (u == null ? "гость" : u.Title) + "!";
            if (Auth.IsAdmin)
            {
                lblRole.Text = "Кабинет администратора: ученики, оплата, пользователи";
                Text = "Палитра — кабинет администратора";
            }
            else
            {
                lblRole.Text = "Кабинет пользователя: просмотр учеников, карточки и расписание";
                Text = "Палитра — кабинет пользователя";
            }
            btnUsers.Visible = Auth.IsAdmin;
        }

        private void UpdateStats()
        {
            int count = 0;
            try
            {
                count = Db.Count();
                lblStats.Text = "В базе учеников: " + count + "    |    Версия приложения: 0.9";
            }
            catch (Exception ex)
            {
                ErrorGuard.Log("Подсчёт учеников: " + ex);
                lblStats.Text = "Нет связи с базой данных";
            }
        }

        private void btnStudents_Click(object sender, EventArgs e)
        {
            using (StudentsForm f = new StudentsForm())
            {
                f.ShowDialog(this);
            }
            UpdateStats();
        }

        private void btnLessons_Click(object sender, EventArgs e)
        {
            using (LessonsForm f = new LessonsForm())
            {
                f.ShowDialog(this);
            }
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            using (ProfileForm f = new ProfileForm())
            {
                f.ShowDialog(this);
            }
            ErrorGuard.Try(() =>
            {
                AppUser fresh = UsersDb.Get(Auth.User.Id);
                if (fresh != null) Auth.User = fresh;
            }, "Не удалось обновить данные профиля");
            ShowCabinet();
        }

        // Кнопка скрыта у пользователя, и переход ещё раз проверяет роль
        private void btnUsers_Click(object sender, EventArgs e)
        {
            if (!ErrorGuard.Try(() => Auth.DemandAdmin("управлять пользователями"),
                "Нет доступа"))
            {
                return;
            }
            using (UsersForm f = new UsersForm())
            {
                f.ShowDialog(this);
            }
        }

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            SignedOut = true;
            Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            SignedOut = false;
            Close();
        }
    }
}
