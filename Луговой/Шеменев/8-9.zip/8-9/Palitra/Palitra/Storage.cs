﻿using System;
using System.Configuration;
using System.Data.Common;
using System.Data.SQLite;
using System.IO;
using Npgsql;

namespace Palitra
{
    public enum StorageKind
    {
        PostgreSql,
        Sqlite
    }

    // Подключение к базе данных. Параметры лежат в файле
    // Palitra.exe.config (раздел connectionStrings и ключ Storage),
    // поэтому их можно поменять без перекомпиляции.
    //
    // Основное хранилище: PostgreSQL через Npgsql. Запасное: файл SQLite
    // рядом с программой, если сервер на компьютере не запускается.
    public static class Storage
    {
        public const string DefaultPg =
            "Host=localhost;Port=5432;Database=palitra;Username=postgres;Password=";

        public static StorageKind Kind = StorageKind.PostgreSql;
        public static string PgConnection = DefaultPg;
        public static string SqliteFile = Path.Combine(AppFolder, "palitra.db");

        public static string AppFolder
        {
            get { return AppDomain.CurrentDomain.BaseDirectory; }
        }

        public static string KindName
        {
            get { return Kind == StorageKind.Sqlite ? "SQLite" : "PostgreSQL"; }
        }

        // ---------------------------------------------- настройки
        public static void Load()
        {
            try
            {
                ConnectionStringSettings cs =
                    ConfigurationManager.ConnectionStrings["Palitra"];
                if (cs != null && cs.ConnectionString.Trim().Length > 0)
                {
                    PgConnection = cs.ConnectionString;
                }
                string kind = ConfigurationManager.AppSettings["Storage"];
                Kind = kind == "SQLite" ? StorageKind.Sqlite : StorageKind.PostgreSql;
                string file = ConfigurationManager.AppSettings["SqliteFile"];
                if (!string.IsNullOrWhiteSpace(file))
                {
                    SqliteFile = Path.IsPathRooted(file)
                        ? file : Path.Combine(AppFolder, file);
                }
            }
            catch (Exception ex)
            {
                // повреждённый файл настроек: работаем со значениями
                // по умолчанию
                ErrorGuard.Log("Чтение настроек: " + ex);
            }
        }

        // Сохранение выбора в Palitra.exe.config. Если папка программы
        // закрыта для записи, выбор действует до закрытия программы.
        public static bool Save()
        {
            try
            {
                Configuration config = ConfigurationManager.OpenExeConfiguration(
                    ConfigurationUserLevel.None);
                ConnectionStringSettings cs = config.ConnectionStrings
                    .ConnectionStrings["Palitra"];
                if (cs == null)
                {
                    config.ConnectionStrings.ConnectionStrings.Add(
                        new ConnectionStringSettings("Palitra", PgConnection));
                }
                else
                {
                    cs.ConnectionString = PgConnection;
                }
                SetSetting(config, "Storage", KindName);
                SetSetting(config, "SqliteFile", SqliteFile);
                config.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection("connectionStrings");
                ConfigurationManager.RefreshSection("appSettings");
                return true;
            }
            catch (Exception ex)
            {
                ErrorGuard.Log("Сохранение настроек: " + ex);
                return false;
            }
        }

        private static void SetSetting(Configuration config, string key, string value)
        {
            if (config.AppSettings.Settings[key] == null)
            {
                config.AppSettings.Settings.Add(key, value);
            }
            else
            {
                config.AppSettings.Settings[key].Value = value;
            }
        }

        // Описание подключения без пароля
        public static string Describe()
        {
            if (Kind == StorageKind.Sqlite)
            {
                return "SQLite, файл " + Path.GetFileName(SqliteFile);
            }
            try
            {
                NpgsqlConnectionStringBuilder b =
                    new NpgsqlConnectionStringBuilder(PgConnection);
                return "PostgreSQL, база " + b.Database + " (" + b.Host + ":" +
                    b.Port + ")";
            }
            catch (Exception)
            {
                return "PostgreSQL";
            }
        }

        // ---------------------------------------------- соединение
        public static DbConnection Open()
        {
            DbConnection conn;
            if (Kind == StorageKind.Sqlite)
            {
                conn = new SQLiteConnection("Data Source=" + SqliteFile);
            }
            else
            {
                NpgsqlConnectionStringBuilder b =
                    new NpgsqlConnectionStringBuilder(PgConnection);
                b.Timeout = 5;
                conn = new NpgsqlConnection(b.ConnectionString);
            }
            conn.Open();
            return conn;
        }

        // Команда с параметрами: Storage.Cmd(conn, sql, "@id", 5, "@name", "...")
        public static DbCommand Cmd(DbConnection conn, string sql,
            params object[] args)
        {
            DbCommand cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            for (int i = 0; i + 1 < args.Length; i += 2)
            {
                DbParameter p = cmd.CreateParameter();
                p.ParameterName = (string)args[i];
                p.Value = args[i + 1] ?? DBNull.Value;
                cmd.Parameters.Add(p);
            }
            return cmd;
        }

        public static int Execute(string sql, params object[] args)
        {
            using (DbConnection conn = Open())
            using (DbCommand cmd = Cmd(conn, sql, args))
            {
                return cmd.ExecuteNonQuery();
            }
        }

        public static object Scalar(string sql, params object[] args)
        {
            using (DbConnection conn = Open())
            using (DbCommand cmd = Cmd(conn, sql, args))
            {
                object v = cmd.ExecuteScalar();
                return v == DBNull.Value ? null : v;
            }
        }

        public static bool TryConnect(out string error)
        {
            try
            {
                using (DbConnection conn = Open())
                using (DbCommand cmd = Cmd(conn, "SELECT 1"))
                {
                    cmd.ExecuteScalar();
                }
                error = "";
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        // ---------------------------------------------- подготовка базы
        // Создаёт базу (только PostgreSQL), таблицы и стартовые данные.
        // pgAdmin для этого не нужен.
        public static bool TryInitialize(out string error)
        {
            try
            {
                if (Kind == StorageKind.PostgreSql)
                {
                    CreatePgDatabase();
                }
                using (DbConnection conn = Open())
                {
                    foreach (string sql in Kind == StorageKind.Sqlite
                        ? SqliteSchema : PgSchema)
                    {
                        using (DbCommand cmd = Cmd(conn, sql))
                        {
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                Db.SeedIfEmpty();
                UsersDb.SeedIfEmpty();
                error = "";
                return true;
            }
            catch (Exception ex)
            {
                ErrorGuard.Log("Подготовка базы: " + ex);
                error = ex.Message;
                return false;
            }
        }

        private static void CreatePgDatabase()
        {
            NpgsqlConnectionStringBuilder b = new NpgsqlConnectionStringBuilder(PgConnection);
            string name = b.Database;
            if (string.IsNullOrEmpty(name))
            {
                throw new InvalidOperationException("В строке подключения не указана база данных.");
            }
            foreach (char c in name)
            {
                if (!char.IsLetterOrDigit(c) && c != '_')
                {
                    throw new InvalidOperationException("Недопустимое имя базы данных: " + name);
                }
            }
            b.Database = "postgres";
            b.Timeout = 5;
            using (NpgsqlConnection conn = new NpgsqlConnection(b.ConnectionString))
            {
                conn.Open();
                using (NpgsqlCommand check = new NpgsqlCommand(
                    "SELECT COUNT(*) FROM pg_database WHERE datname = @n", conn))
                {
                    check.Parameters.AddWithValue("@n", name.ToLowerInvariant());
                    if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                    {
                        return;
                    }
                }
                using (NpgsqlCommand create = new NpgsqlCommand(
                    "CREATE DATABASE " + name.ToLowerInvariant(), conn))
                {
                    create.ExecuteNonQuery();
                }
            }
        }

        private static readonly string[] PgSchema =
        {
            "CREATE TABLE IF NOT EXISTS students (" +
            " id SERIAL PRIMARY KEY," +
            " full_name VARCHAR(120) NOT NULL," +
            " age INTEGER NOT NULL CHECK (age BETWEEN 5 AND 100)," +
            " direction VARCHAR(40) NOT NULL," +
            " fee_per_month NUMERIC(10,2) NOT NULL CHECK (fee_per_month > 0)," +
            " image_path TEXT)",

            "CREATE TABLE IF NOT EXISTS app_users (" +
            " id SERIAL PRIMARY KEY," +
            " login VARCHAR(50) NOT NULL UNIQUE," +
            " password_hash TEXT NOT NULL," +
            " role VARCHAR(20) NOT NULL CHECK (role IN ('Admin', 'User'))," +
            " full_name VARCHAR(120)," +
            " phone VARCHAR(30)," +
            " email VARCHAR(100)," +
            " photo_path TEXT," +
            " registered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        };

        private static readonly string[] SqliteSchema =
        {
            "CREATE TABLE IF NOT EXISTS students (" +
            " id INTEGER PRIMARY KEY AUTOINCREMENT," +
            " full_name TEXT NOT NULL," +
            " age INTEGER NOT NULL CHECK (age BETWEEN 5 AND 100)," +
            " direction TEXT NOT NULL," +
            " fee_per_month NUMERIC NOT NULL CHECK (fee_per_month > 0)," +
            " image_path TEXT)",

            "CREATE TABLE IF NOT EXISTS app_users (" +
            " id INTEGER PRIMARY KEY AUTOINCREMENT," +
            " login TEXT NOT NULL UNIQUE," +
            " password_hash TEXT NOT NULL," +
            " role TEXT NOT NULL CHECK (role IN ('Admin', 'User'))," +
            " full_name TEXT," +
            " phone TEXT," +
            " email TEXT," +
            " photo_path TEXT," +
            " registered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        };
    }
}
