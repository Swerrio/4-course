﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Drawing;
using System.IO;

namespace Palitra
{
    // Ученики школы. С ЛР №8 данные хранятся в таблице students базы
    // данных, а не в списке в памяти: каждый метод выполняет SQL-запрос.
    // Изменять данные может только администратор (проверка Auth в начале
    // метода, а не только на форме).
    public static class Db
    {
        public static readonly string[] Directions =
            { "Живопись", "Графика", "ДПИ", "Скульптура", "Дизайн" };

        private const string Select =
            "SELECT id, full_name, age, direction, fee_per_month, image_path " +
            "FROM students";

        // ---------------------------------------------- чтение
        public static List<Student> GetAll()
        {
            return Query(Select + " ORDER BY id");
        }

        // Поиск по части ФИО или по кружку, без учёта регистра
        public static List<Student> Search(string text)
        {
            return Query(Select +
                " WHERE LOWER(full_name) LIKE @q OR LOWER(direction) LIKE @q" +
                " ORDER BY id",
                "@q", "%" + text.Trim().ToLowerInvariant() + "%");
        }

        // Фильтр ЛР №5: направление (null = любое) и минимальный возраст
        public static List<Student> Filter(string direction, int minAge)
        {
            if (direction == null)
            {
                return Query(Select + " WHERE age >= @age ORDER BY id",
                    "@age", minAge);
            }
            return Query(Select + " WHERE direction = @dir AND age >= @age" +
                " ORDER BY id", "@dir", direction, "@age", minAge);
        }

        public static Student GetById(int id)
        {
            List<Student> list = Query(Select + " WHERE id = @id", "@id", id);
            return list.Count == 0 ? null : list[0];
        }

        public static int Count()
        {
            return Convert.ToInt32(Storage.Scalar("SELECT COUNT(*) FROM students"));
        }

        // ---------------------------------------------- изменение
        public static void Add(Student s)
        {
            Auth.DemandAdmin("добавлять учеников");
            Storage.Execute(
                "INSERT INTO students (full_name, age, direction, fee_per_month) " +
                "VALUES (@name, @age, @dir, @fee)",
                "@name", s.FullName, "@age", s.Age, "@dir", s.Direction,
                "@fee", s.FeePerMonth);
        }

        public static void Update(Student s)
        {
            Auth.DemandAdmin("изменять данные учеников");
            int n = Storage.Execute(
                "UPDATE students SET full_name = @name, age = @age, " +
                "direction = @dir, fee_per_month = @fee WHERE id = @id",
                "@name", s.FullName, "@age", s.Age, "@dir", s.Direction,
                "@fee", s.FeePerMonth, "@id", s.Id);
            if (n == 0)
            {
                throw new InvalidOperationException(
                    "Ученик не найден в базе: возможно, его уже удалили.");
            }
        }

        // Удаление по первичному ключу id
        public static void Delete(int id)
        {
            Auth.DemandAdmin("удалять учеников");
            Storage.Execute("DELETE FROM students WHERE id = @id", "@id", id);
        }

        public static void SetImage(int id, string relativePath)
        {
            Auth.DemandAdmin("менять фото работ");
            Storage.Execute("UPDATE students SET image_path = @p WHERE id = @id",
                "@p", relativePath, "@id", id);
        }

        public static void SeedIfEmpty()
        {
            if (Count() > 0)
            {
                return;
            }
            string sql = "INSERT INTO students (full_name, age, direction, fee_per_month) " +
                "VALUES (@name, @age, @dir, @fee)";
            Storage.Execute(sql, "@name", "Иванова Анна", "@age", 12, "@dir", "Живопись", "@fee", 3500m);
            Storage.Execute(sql, "@name", "Петров Максим", "@age", 14, "@dir", "Графика", "@fee", 3000m);
            Storage.Execute(sql, "@name", "Сидорова Елена", "@age", 10, "@dir", "ДПИ", "@fee", 2800m);
        }

        private static List<Student> Query(string sql, params object[] args)
        {
            List<Student> list = new List<Student>();
            using (DbConnection conn = Storage.Open())
            using (DbCommand cmd = Storage.Cmd(conn, sql, args))
            using (DbDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    list.Add(new Student
                    {
                        Id = Convert.ToInt32(r["id"]),
                        FullName = Convert.ToString(r["full_name"]),
                        Age = Convert.ToInt32(r["age"]),
                        Direction = Convert.ToString(r["direction"]),
                        FeePerMonth = Convert.ToDecimal(r["fee_per_month"]),
                        ImagePath = r["image_path"] == DBNull.Value
                            ? null : Convert.ToString(r["image_path"])
                    });
                }
            }
            return list;
        }

        // ---------------------------------------------- файлы изображений
        // Фото работ лежат в папке works рядом с программой,
        // в базе хранится путь относительно папки программы.
        public static string WorksFolder
        {
            get
            {
                string p = Path.Combine(Storage.AppFolder, "works");
                Directory.CreateDirectory(p);
                return p;
            }
        }

        public static string FullPath(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return null;
            }
            return Path.IsPathRooted(path) ? path : Path.Combine(Storage.AppFolder, path);
        }

        // Картинка читается в память целиком, файл не остаётся занятым.
        // Отсутствующий или повреждённый файл даёт null, а не ошибку.
        public static Image LoadImage(string path)
        {
            string full = FullPath(path);
            if (full == null || !File.Exists(full)) return null;
            try
            {
                using (MemoryStream ms = new MemoryStream(File.ReadAllBytes(full)))
                using (Image img = Image.FromStream(ms))
                {
                    return new Bitmap(img);
                }
            }
            catch
            {
                return null;
            }
        }
    }
}
