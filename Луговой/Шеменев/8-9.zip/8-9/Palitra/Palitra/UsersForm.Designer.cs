﻿namespace Palitra
{
    partial class UsersForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvUsers = new System.Windows.Forms.DataGridView();
            this.colLogin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpNew = new System.Windows.Forms.GroupBox();
            this.lblLogin = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.cmbRole = new System.Windows.Forms.ComboBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblCount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
            this.grpNew.SuspendLayout();
            this.SuspendLayout();
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(52, 86, 108);
            this.lblTitle.Location = new System.Drawing.Point(20, 16);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "ПОЛЬЗОВАТЕЛИ ПРОГРАММЫ";
            //
            this.dgvUsers.AllowUserToAddRows = false;
            this.dgvUsers.AllowUserToDeleteRows = false;
            this.dgvUsers.AllowUserToResizeRows = false;
            this.dgvUsers.AutoGenerateColumns = false;
            this.dgvUsers.BackgroundColor = System.Drawing.Color.White;
            this.dgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colLogin,
            this.colRole,
            this.colName});
            this.dgvUsers.Location = new System.Drawing.Point(24, 60);
            this.dgvUsers.MultiSelect = false;
            this.dgvUsers.Name = "dgvUsers";
            this.dgvUsers.ReadOnly = true;
            this.dgvUsers.RowHeadersVisible = false;
            this.dgvUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUsers.Size = new System.Drawing.Size(400, 280);
            this.dgvUsers.TabIndex = 0;
            //
            this.colLogin.DataPropertyName = "Login";
            this.colLogin.HeaderText = "Логин";
            this.colLogin.Name = "colLogin";
            this.colLogin.Width = 100;
            //
            this.colRole.DataPropertyName = "RoleText";
            this.colRole.HeaderText = "Роль";
            this.colRole.Name = "colRole";
            this.colRole.Width = 110;
            //
            this.colName.DataPropertyName = "FullName";
            this.colName.HeaderText = "Имя";
            this.colName.Name = "colName";
            this.colName.Width = 170;
            //
            this.grpNew.BackColor = System.Drawing.Color.White;
            this.grpNew.Controls.Add(this.lblLogin);
            this.grpNew.Controls.Add(this.txtLogin);
            this.grpNew.Controls.Add(this.lblPassword);
            this.grpNew.Controls.Add(this.txtPassword);
            this.grpNew.Controls.Add(this.lblName);
            this.grpNew.Controls.Add(this.txtName);
            this.grpNew.Controls.Add(this.lblRole);
            this.grpNew.Controls.Add(this.cmbRole);
            this.grpNew.Controls.Add(this.btnCreate);
            this.grpNew.Location = new System.Drawing.Point(440, 54);
            this.grpNew.Name = "grpNew";
            this.grpNew.Size = new System.Drawing.Size(240, 286);
            this.grpNew.TabStop = false;
            this.grpNew.Text = "Новая учётная запись";
            //
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(12, 24);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Text = "Логин:";
            //
            this.txtLogin.Location = new System.Drawing.Point(12, 42);
            this.txtLogin.MaxLength = 50;
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(214, 23);
            this.txtLogin.TabIndex = 0;
            //
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(12, 72);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Text = "Пароль (от 8 символов):";
            //
            this.txtPassword.Location = new System.Drawing.Point(12, 90);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(214, 23);
            this.txtPassword.TabIndex = 1;
            //
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 120);
            this.lblName.Name = "lblName";
            this.lblName.Text = "Имя и фамилия:";
            //
            this.txtName.Location = new System.Drawing.Point(12, 138);
            this.txtName.MaxLength = 120;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(214, 23);
            this.txtName.TabIndex = 2;
            //
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(12, 168);
            this.lblRole.Name = "lblRole";
            this.lblRole.Text = "Роль:";
            //
            this.cmbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRole.Items.AddRange(new object[] { "Пользователь", "Администратор" });
            this.cmbRole.Location = new System.Drawing.Point(12, 186);
            this.cmbRole.Name = "cmbRole";
            this.cmbRole.Size = new System.Drawing.Size(214, 23);
            this.cmbRole.TabIndex = 3;
            //
            this.btnCreate.Location = new System.Drawing.Point(12, 230);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(214, 36);
            this.btnCreate.TabIndex = 4;
            this.btnCreate.Text = "Создать";
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            //
            this.btnDelete.Location = new System.Drawing.Point(24, 352);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(200, 34);
            this.btnDelete.TabIndex = 1;
            this.btnDelete.Text = "Удалить выбранного";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            //
            this.btnClose.Location = new System.Drawing.Point(530, 352);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(150, 34);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Закрыть";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            //
            this.lblCount.AutoSize = true;
            this.lblCount.ForeColor = System.Drawing.Color.Gray;
            this.lblCount.Location = new System.Drawing.Point(236, 361);
            this.lblCount.Name = "lblCount";
            this.lblCount.Text = "Учётных записей: 0";
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.BackColor = System.Drawing.Color.FromArgb(246, 243, 238);
            this.ClientSize = new System.Drawing.Size(704, 402);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.dgvUsers);
            this.Controls.Add(this.grpNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblCount);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "UsersForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Палитра — пользователи";
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
            this.grpNew.ResumeLayout(false);
            this.grpNew.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLogin;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRole;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.GroupBox grpNew;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblCount;
    }
}
