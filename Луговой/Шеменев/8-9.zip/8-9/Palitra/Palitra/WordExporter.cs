﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Xml.Linq;

namespace Palitra
{
    // Карточка ученика в формате Word (.docx).
    //
    // До v0.8 документ создавался библиотекой Xceed DocX. Её версия 6.x
    // требует платный лицензионный ключ и без него выдаёт ошибку
    // «Licenser.LicenseKey property must be set», поэтому выгрузка
    // переписана без сторонних библиотек. Файл .docx — это zip-архив
    // с XML-частями; архив собирается классами System.IO.Compression,
    // а XML — классами System.Xml.Linq, которые входят в .NET Framework.
    public static class WordExporter
    {
        private static readonly XNamespace W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        private static readonly XNamespace R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private static readonly XNamespace WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing";
        private static readonly XNamespace A = "http://schemas.openxmlformats.org/drawingml/2006/main";
        private static readonly XNamespace PIC = "http://schemas.openxmlformats.org/drawingml/2006/picture";
        private static readonly XNamespace PR = "http://schemas.openxmlformats.org/package/2006/relationships";
        private static readonly XNamespace CT = "http://schemas.openxmlformats.org/package/2006/content-types";

        public static string Create(Student s)
        {
            string dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Palitra");
            Directory.CreateDirectory(dir);

            string safeName = string.Join("_", s.FullName.Split(Path.GetInvalidFileNameChars()))
                .Replace(' ', '_');
            string path = Path.Combine(dir,
                "Карточка_" + safeName + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".docx");

            byte[] png = null;
            int width = 0, height = 0;
            using (Image img = Db.LoadImage(s.ImagePath))
            {
                if (img != null)
                {
                    png = ToPng(img, 420, 300, out width, out height);
                }
            }

            XElement body = new XElement(W + "body",
                Para("КАРТОЧКА УЧЕНИКА", 40, true, false),
                Para("Художественная школа «Палитра»", 24, false, true),
                Para("", 24, false, false),
                Para("ФИО: " + s.FullName, 28, false, false),
                Para("Код ученика: " + s.Id, 24, false, false),
                Para("Возраст: " + s.Age + " лет", 24, false, false),
                Para("Направление: " + s.Direction, 24, false, false),
                Para("Стоимость обучения: " + s.FeePerMonth.ToString("N2") + " руб./мес.", 24, false, false),
                Para("Дата формирования: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm"), 24, false, false),
                Para("", 24, false, false));

            if (png != null)
            {
                body.Add(Para("Творческая работа ученика:", 24, true, false));
                body.Add(Picture(width, height));
                body.Add(Para("", 24, false, false));
            }
            body.Add(Para("Сформировано программой «Палитра».", 18, false, true));
            body.Add(new XElement(W + "sectPr",
                new XElement(W + "pgSz", new XAttribute(W + "w", 11906), new XAttribute(W + "h", 16838)),
                new XElement(W + "pgMar", new XAttribute(W + "top", 1134), new XAttribute(W + "right", 850),
                    new XAttribute(W + "bottom", 1134), new XAttribute(W + "left", 1701),
                    new XAttribute(W + "header", 708), new XAttribute(W + "footer", 708),
                    new XAttribute(W + "gutter", 0))));

            XDocument document = new XDocument(new XElement(W + "document",
                new XAttribute(XNamespace.Xmlns + "w", W), new XAttribute(XNamespace.Xmlns + "r", R),
                new XAttribute(XNamespace.Xmlns + "wp", WP), new XAttribute(XNamespace.Xmlns + "a", A),
                new XAttribute(XNamespace.Xmlns + "pic", PIC), body));

            // во временный файл, затем переименование: при ошибке
            // не остаётся наполовину записанного документа
            string temp = path + ".tmp";
            try
            {
                using (FileStream fs = new FileStream(temp, FileMode.Create, FileAccess.Write))
                using (ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Create))
                {
                    Put(zip, "[Content_Types].xml", ContentTypes());
                    Put(zip, "_rels/.rels", Rels(new XElement(PR + "Relationship",
                        new XAttribute("Id", "rId1"),
                        new XAttribute("Type", R.NamespaceName + "/officeDocument"),
                        new XAttribute("Target", "word/document.xml"))));
                    Put(zip, "word/_rels/document.xml.rels", Rels(
                        new XElement(PR + "Relationship", new XAttribute("Id", "rId1"),
                            new XAttribute("Type", R.NamespaceName + "/styles"),
                            new XAttribute("Target", "styles.xml")),
                        png == null ? null : new XElement(PR + "Relationship", new XAttribute("Id", "rId2"),
                            new XAttribute("Type", R.NamespaceName + "/image"),
                            new XAttribute("Target", "media/work.png"))));
                    Put(zip, "word/styles.xml", Styles());
                    Put(zip, "word/document.xml", document);
                    if (png != null)
                    {
                        ZipArchiveEntry e = zip.CreateEntry("word/media/work.png");
                        using (Stream st = e.Open())
                        {
                            st.Write(png, 0, png.Length);
                        }
                    }
                }
                if (File.Exists(path)) File.Delete(path);
                File.Move(temp, path);
            }
            finally
            {
                if (File.Exists(temp)) File.Delete(temp);
            }
            return path;
        }

        private static XElement Para(string text, int halfPoints, bool bold, bool italic)
        {
            XElement rPr = new XElement(W + "rPr");
            if (bold) rPr.Add(new XElement(W + "b"));
            if (italic) rPr.Add(new XElement(W + "i"));
            rPr.Add(new XElement(W + "sz", new XAttribute(W + "val", halfPoints)));
            XElement p = new XElement(W + "p",
                new XElement(W + "pPr", new XElement(W + "spacing", new XAttribute(W + "after", 80))));
            if (text.Length > 0)
            {
                p.Add(new XElement(W + "r", rPr,
                    new XElement(W + "t", new XAttribute(XNamespace.Xml + "space", "preserve"), text)));
            }
            return p;
        }

        private static XElement Picture(int px, int py)
        {
            long cx = px * 9525L, cy = py * 9525L;
            return new XElement(W + "p", new XElement(W + "r", new XElement(W + "drawing",
                new XElement(WP + "inline",
                    new XElement(WP + "extent", new XAttribute("cx", cx), new XAttribute("cy", cy)),
                    new XElement(WP + "docPr", new XAttribute("id", 1), new XAttribute("name", "Работа ученика")),
                    new XElement(A + "graphic", new XElement(A + "graphicData",
                        new XAttribute("uri", PIC.NamespaceName),
                        new XElement(PIC + "pic",
                            new XElement(PIC + "nvPicPr",
                                new XElement(PIC + "cNvPr", new XAttribute("id", 0), new XAttribute("name", "work.png")),
                                new XElement(PIC + "cNvPicPr")),
                            new XElement(PIC + "blipFill",
                                new XElement(A + "blip", new XAttribute(R + "embed", "rId2")),
                                new XElement(A + "stretch", new XElement(A + "fillRect"))),
                            new XElement(PIC + "spPr",
                                new XElement(A + "xfrm",
                                    new XElement(A + "off", new XAttribute("x", 0), new XAttribute("y", 0)),
                                    new XElement(A + "ext", new XAttribute("cx", cx), new XAttribute("cy", cy))),
                                new XElement(A + "prstGeom", new XAttribute("prst", "rect"),
                                    new XElement(A + "avLst"))))))))));
        }

        private static XDocument ContentTypes()
        {
            string main = "application/vnd.openxmlformats-officedocument.wordprocessingml.";
            return new XDocument(new XElement(CT + "Types",
                new XElement(CT + "Default", new XAttribute("Extension", "rels"),
                    new XAttribute("ContentType", "application/vnd.openxmlformats-package.relationships+xml")),
                new XElement(CT + "Default", new XAttribute("Extension", "xml"),
                    new XAttribute("ContentType", "application/xml")),
                new XElement(CT + "Default", new XAttribute("Extension", "png"),
                    new XAttribute("ContentType", "image/png")),
                new XElement(CT + "Override", new XAttribute("PartName", "/word/document.xml"),
                    new XAttribute("ContentType", main + "document.main+xml")),
                new XElement(CT + "Override", new XAttribute("PartName", "/word/styles.xml"),
                    new XAttribute("ContentType", main + "styles+xml"))));
        }

        private static XDocument Rels(params XElement[] items)
        {
            XElement root = new XElement(PR + "Relationships");
            foreach (XElement e in items)
            {
                if (e != null) root.Add(e);
            }
            return new XDocument(root);
        }

        private static XDocument Styles()
        {
            return new XDocument(new XElement(W + "styles",
                new XAttribute(XNamespace.Xmlns + "w", W),
                new XElement(W + "docDefaults", new XElement(W + "rPrDefault", new XElement(W + "rPr",
                    new XElement(W + "rFonts", new XAttribute(W + "ascii", "Times New Roman"),
                        new XAttribute(W + "hAnsi", "Times New Roman"), new XAttribute(W + "cs", "Times New Roman")),
                    new XElement(W + "sz", new XAttribute(W + "val", 24)),
                    new XElement(W + "lang", new XAttribute(W + "val", "ru-RU")))))));
        }

        private static void Put(ZipArchive zip, string name, XDocument xml)
        {
            ZipArchiveEntry e = zip.CreateEntry(name);
            using (Stream st = e.Open())
            using (StreamWriter w = new StreamWriter(st, new UTF8Encoding(false)))
            {
                w.Write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                w.Write(xml.Root.ToString(SaveOptions.DisableFormatting));
            }
        }

        // Картинка уменьшается с сохранением пропорций и записывается как PNG
        private static byte[] ToPng(Image img, int maxW, int maxH, out int w, out int h)
        {
            double k = Math.Min(1.0, Math.Min((double)maxW / img.Width, (double)maxH / img.Height));
            w = Math.Max(1, (int)(img.Width * k));
            h = Math.Max(1, (int)(img.Height * k));
            using (Bitmap bmp = new Bitmap(w, h))
            {
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.Clear(Color.White);
                    g.DrawImage(img, 0, 0, w, h);
                }
                using (MemoryStream ms = new MemoryStream())
                {
                    bmp.Save(ms, ImageFormat.Png);
                    return ms.ToArray();
                }
            }
        }
    }
}
