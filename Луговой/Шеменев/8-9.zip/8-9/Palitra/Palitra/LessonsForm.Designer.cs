﻿namespace Palitra
{
    partial class LessonsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lstLessons = new System.Windows.Forms.ListBox();
            this.grpDetails = new System.Windows.Forms.GroupBox();
            this.lblLessonName = new System.Windows.Forms.Label();
            this.lblTeacher = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblPlace = new System.Windows.Forms.Label();
            this.lblHint = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.grpDetails.SuspendLayout();
            this.SuspendLayout();
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(52, 86, 108);
            this.lblTitle.Location = new System.Drawing.Point(20, 16);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "Расписание занятий";
            //
            this.lstLessons.FormattingEnabled = true;
            this.lstLessons.IntegralHeight = false;
            this.lstLessons.ItemHeight = 15;
            this.lstLessons.Location = new System.Drawing.Point(20, 64);
            this.lstLessons.Name = "lstLessons";
            this.lstLessons.Size = new System.Drawing.Size(250, 280);
            this.lstLessons.SelectedIndexChanged += new System.EventHandler(this.lstLessons_SelectedIndexChanged);
            //
            this.grpDetails.BackColor = System.Drawing.Color.White;
            this.grpDetails.Controls.Add(this.lblLessonName);
            this.grpDetails.Controls.Add(this.lblTeacher);
            this.grpDetails.Controls.Add(this.lblTime);
            this.grpDetails.Controls.Add(this.lblPlace);
            this.grpDetails.Controls.Add(this.lblHint);
            this.grpDetails.Location = new System.Drawing.Point(290, 64);
            this.grpDetails.Name = "grpDetails";
            this.grpDetails.Size = new System.Drawing.Size(310, 280);
            this.grpDetails.TabStop = false;
            this.grpDetails.Text = "Информация о занятии";
            //
            this.lblLessonName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblLessonName.Location = new System.Drawing.Point(16, 30);
            this.lblLessonName.Name = "lblLessonName";
            this.lblLessonName.Size = new System.Drawing.Size(278, 50);
            //
            this.lblTeacher.Location = new System.Drawing.Point(16, 95);
            this.lblTeacher.Name = "lblTeacher";
            this.lblTeacher.Size = new System.Drawing.Size(278, 24);
            //
            this.lblTime.Location = new System.Drawing.Point(16, 135);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(278, 24);
            //
            this.lblPlace.Location = new System.Drawing.Point(16, 175);
            this.lblPlace.Name = "lblPlace";
            this.lblPlace.Size = new System.Drawing.Size(278, 24);
            //
            this.lblHint.ForeColor = System.Drawing.Color.Gray;
            this.lblHint.Location = new System.Drawing.Point(16, 225);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(278, 40);
            this.lblHint.Text = "Выберите занятие в списке слева.";
            //
            this.btnBack.Location = new System.Drawing.Point(20, 356);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(580, 30);
            this.btnBack.Text = "Назад в главное меню";
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.BackColor = System.Drawing.Color.FromArgb(246, 243, 238);
            this.ClientSize = new System.Drawing.Size(620, 400);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lstLessons);
            this.Controls.Add(this.grpDetails);
            this.Controls.Add(this.btnBack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LessonsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Палитра — расписание";
            this.grpDetails.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ListBox lstLessons;
        private System.Windows.Forms.GroupBox grpDetails;
        private System.Windows.Forms.Label lblLessonName;
        private System.Windows.Forms.Label lblTeacher;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblPlace;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Button btnBack;
    }
}