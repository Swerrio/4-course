﻿using System;
using System.Windows.Forms;

namespace Palitra
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            Ui.Apply(this);
            ShowStorage();
        }

        private void ShowStorage()
        {
            lblStorage.Text = "База данных: " + Storage.Describe();
        }

        // Вход: логин ищется в таблице app_users, пароль сверяется с хешем
        private void btnLogin_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            string login = txtLogin.Text.Trim();
            if (login.Length == 0 || txtPassword.Text.Length == 0)
            {
                lblError.Text = "Введите логин и пароль.";
                MessageBox.Show("Введите логин и пароль.", "Вход",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            AppUser user = null;
            if (!ErrorGuard.Try(() => user = UsersDb.SignIn(login, txtPassword.Text),
                "Не удалось проверить логин и пароль"))
            {
                lblError.Text = "Нет связи с базой данных.";
                return;
            }

            if (user == null)
            {
                lblError.Text = "Неверный логин или пароль.";
                MessageBox.Show("Неверный логин или пароль.", "Вход",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Clear();
                txtPassword.Focus();
                return;
            }

            Auth.User = user;
            OpenCabinet();
        }

        // Кабинет открывается по роли; после «Выйти из учётной записи»
        // снова показывается окно входа
        private void OpenCabinet()
        {
            Hide();
            bool signOut;
            using (MainForm main = new MainForm())
            {
                main.ShowDialog();
                signOut = main.SignedOut;
            }
            Auth.SignOut();

            if (signOut)
            {
                txtPassword.Clear();
                lblError.Text = "";
                Show();
                txtLogin.Focus();
            }
            else
            {
                Close();
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            using (ConnectionForm form = new ConnectionForm(null))
            {
                form.ShowDialog(this);
            }
            ShowStorage();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
