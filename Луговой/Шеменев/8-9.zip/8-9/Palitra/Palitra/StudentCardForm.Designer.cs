﻿namespace Palitra
{
    partial class StudentCardForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblGroup = new System.Windows.Forms.Label();
            this.lblFee = new System.Windows.Forms.Label();
            this.picCard = new System.Windows.Forms.PictureBox();
            this.btnWord = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblFooter = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picCard)).BeginInit();
            this.SuspendLayout();
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(52, 86, 108);
            this.lblTitle.Location = new System.Drawing.Point(24, 18);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "КАРТОЧКА УЧЕНИКА";
            //
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblName.Location = new System.Drawing.Point(24, 58);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(472, 34);
            //
            this.lblId.Location = new System.Drawing.Point(24, 100);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(472, 24);
            //
            this.lblAge.Location = new System.Drawing.Point(24, 130);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(472, 24);
            //
            this.lblGroup.Location = new System.Drawing.Point(24, 160);
            this.lblGroup.Name = "lblGroup";
            this.lblGroup.Size = new System.Drawing.Size(472, 24);
            //
            this.lblFee.Location = new System.Drawing.Point(24, 190);
            this.lblFee.Name = "lblFee";
            this.lblFee.Size = new System.Drawing.Size(472, 24);
            //
            this.picCard.BackColor = System.Drawing.Color.White;
            this.picCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCard.Location = new System.Drawing.Point(24, 230);
            this.picCard.Name = "picCard";
            this.picCard.Size = new System.Drawing.Size(472, 230);
            this.picCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCard.TabStop = false;
            //
            this.btnWord.Location = new System.Drawing.Point(24, 478);
            this.btnWord.Name = "btnWord";
            this.btnWord.Size = new System.Drawing.Size(300, 40);
            this.btnWord.Text = "СФОРМИРОВАТЬ WORD";
            this.btnWord.Click += new System.EventHandler(this.btnWord_Click);
            //
            this.btnClose.Location = new System.Drawing.Point(336, 478);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(160, 40);
            this.btnClose.Text = "Закрыть";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            //
            this.lblFooter.ForeColor = System.Drawing.Color.Gray;
            this.lblFooter.Location = new System.Drawing.Point(24, 526);
            this.lblFooter.Name = "lblFooter";
            this.lblFooter.Size = new System.Drawing.Size(472, 24);
            this.lblFooter.Text = "Сформировано программой «Палитра»";
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.BackColor = System.Drawing.Color.FromArgb(246, 243, 238);
            this.ClientSize = new System.Drawing.Size(520, 560);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblId);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.lblGroup);
            this.Controls.Add(this.lblFee);
            this.Controls.Add(this.picCard);
            this.Controls.Add(this.btnWord);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblFooter);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "StudentCardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Палитра — карточка ученика";
            ((System.ComponentModel.ISupportInitialize)(this.picCard)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblGroup;
        private System.Windows.Forms.Label lblFee;
        private System.Windows.Forms.PictureBox picCard;
        private System.Windows.Forms.Button btnWord;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblFooter;
    }
}