﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Palitra
{
    // ЛР 9: «Мой профиль». Пользователь меняет только свои данные.
    public partial class ProfileForm : Form
    {
        private const long MaxPhoto = 2 * 1024 * 1024;

        private AppUser _me;
        private string _newPhoto;      // выбранный, но ещё не сохранённый файл
        private bool _photoRemoved;

        public ProfileForm()
        {
            InitializeComponent();
            Ui.Apply(this);
            LoadMe();
        }

        private void LoadMe()
        {
            AppUser me = null;
            if (!ErrorGuard.Try(() => me = UsersDb.Get(Auth.User.Id),
                "Не удалось загрузить профиль") || me == null)
            {
                me = Auth.User;
            }
            _me = me;
            _newPhoto = null;
            _photoRemoved = false;

            lblLogin.Text = "Логин: " + me.Login;
            lblRole.Text = "Роль: " + me.RoleText;
            lblRegistered.Text = "Зарегистрирован: " + me.RegisteredAt.ToString("dd.MM.yyyy");
            txtFullName.Text = me.FullName;
            txtPhone.Text = me.Phone;
            txtEmail.Text = me.Email;
            SetPicture(Db.LoadImage(me.PhotoPath));
            lblPhotoInfo.Text = picPhoto.Image == null ? "фото не загружено" : "фото из профиля";
        }

        private void SetPicture(Image img)
        {
            Image old = picPhoto.Image;
            picPhoto.Image = img;
            if (old != null) old.Dispose();
        }

        // Выбор фото: формат, размер и содержимое проверяются сразу,
        // в базу фото попадает после «Сохранить изменения»
        private void btnPhoto_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Фото профиля";
                ofd.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*";
                if (ofd.ShowDialog(this) != DialogResult.OK) return;

                string ext = Path.GetExtension(ofd.FileName).ToLowerInvariant();
                if (ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".bmp")
                {
                    MessageBox.Show("Этот формат не подходит. Выберите изображение jpg, png или bmp.",
                        "Фото профиля", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                long size;
                try
                {
                    size = new FileInfo(ofd.FileName).Length;
                }
                catch (Exception ex)
                {
                    ErrorGuard.Show("Не удалось прочитать файл", ex);
                    return;
                }
                if (size > MaxPhoto)
                {
                    MessageBox.Show("Файл слишком большой (" + (size / 1048576.0).ToString("0.0") +
                        " МБ). Максимальный размер фото: 2 МБ.",
                        "Фото профиля", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Image img = Db.LoadImage(ofd.FileName);
                if (img == null)
                {
                    MessageBox.Show("Файл повреждён или не является изображением.",
                        "Фото профиля", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                SetPicture(img);
                _newPhoto = ofd.FileName;
                _photoRemoved = false;
                lblPhotoInfo.Text = "новое фото, не сохранено";
            }
        }

        private void btnRemovePhoto_Click(object sender, EventArgs e)
        {
            SetPicture(null);
            _newPhoto = null;
            _photoRemoved = true;
            lblPhotoInfo.Text = "фото будет удалено";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            lblSaved.Text = "";
            string email = txtEmail.Text.Trim();
            if (email.Length > 0 && (email.IndexOf('@') < 1 || email.Contains(" ")))
            {
                MessageBox.Show("Адрес электронной почты указан неверно.");
                return;
            }
            foreach (char c in txtPhone.Text)
            {
                if (!char.IsDigit(c) && "+-() ".IndexOf(c) < 0)
                {
                    MessageBox.Show("Телефон может содержать только цифры, пробел и символы + - ( ).");
                    return;
                }
            }

            AppUser u = new AppUser
            {
                Id = _me.Id,
                FullName = txtFullName.Text.Trim(),
                Phone = txtPhone.Text.Trim(),
                Email = email,
                PhotoPath = _photoRemoved ? null : _me.PhotoPath
            };

            bool ok = ErrorGuard.Try(() =>
            {
                if (_newPhoto != null)
                {
                    // копия под уникальным именем в папке UserPhotos
                    string dir = Path.Combine(Storage.AppFolder, "UserPhotos");
                    Directory.CreateDirectory(dir);
                    string name = "u" + _me.Id + "_" + Guid.NewGuid().ToString("N").Substring(0, 10) +
                        Path.GetExtension(_newPhoto).ToLowerInvariant();
                    File.Copy(_newPhoto, Path.Combine(dir, name));
                    u.PhotoPath = Path.Combine("UserPhotos", name);
                }
                UsersDb.SaveProfile(u);
            }, "Не удалось сохранить профиль");
            if (!ok) return;

            LoadMe();
            lblSaved.Text = "Изменения сохранены в базе данных.";
        }

        private void btnPassword_Click(object sender, EventArgs e)
        {
            if (txtOld.Text.Length == 0 || txtNew.Text.Length == 0 || txtRepeat.Text.Length == 0)
            {
                PasswordResult("Заполните все три поля.", false);
                return;
            }
            if (txtNew.Text.Length < 8)
            {
                PasswordResult("Новый пароль должен быть не короче 8 символов.", false);
                return;
            }
            if (txtNew.Text != txtRepeat.Text)
            {
                PasswordResult("Новый пароль и повтор не совпадают.", false);
                return;
            }

            bool changed = false;
            if (!ErrorGuard.Try(() => changed = UsersDb.ChangePassword(_me.Id, txtOld.Text, txtNew.Text),
                "Не удалось сменить пароль")) return;

            if (!changed)
            {
                PasswordResult("Старый пароль введён неверно, пароль не изменён.", false);
                return;
            }
            txtOld.Clear();
            txtNew.Clear();
            txtRepeat.Clear();
            PasswordResult("Пароль изменён.", true);
        }

        private void PasswordResult(string text, bool ok)
        {
            lblPasswordResult.ForeColor = ok ? Color.FromArgb(40, 120, 70) : Color.FromArgb(170, 50, 50);
            lblPasswordResult.Text = text;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
