﻿using System;
using System.Windows.Forms;

namespace Palitra
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // любая непредвиденная ошибка показывается сообщением,
            // программа не закрывается и не «выбивает» в отладчик
            ErrorGuard.Install();

            Storage.Load();
            if (!PrepareStorage())
            {
                return;
            }
            Application.Run(new LoginForm());
        }

        // Подключение к базе при запуске. Если PostgreSQL недоступен,
        // пользователь выбирает: локальная база SQLite, настройки
        // подключения или выход.
        private static bool PrepareStorage()
        {
            string error;
            while (!Storage.TryInitialize(out error))
            {
                if (Storage.Kind == StorageKind.PostgreSql)
                {
                    DialogResult answer = MessageBox.Show(
                        "Не удалось подключиться к PostgreSQL:\n" + error +
                        "\n\nДа: продолжить с локальной базой SQLite (сервер не нужен)." +
                        "\nНет: открыть настройки подключения." +
                        "\nОтмена: закрыть программу.",
                        "Палитра", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                    if (answer == DialogResult.Yes)
                    {
                        Storage.Kind = StorageKind.Sqlite;
                        Storage.Save();
                        continue;
                    }
                    if (answer == DialogResult.Cancel)
                    {
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Не удалось открыть файл базы SQLite:\n" + error,
                        "Палитра", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                using (ConnectionForm form = new ConnectionForm(error))
                {
                    if (form.ShowDialog() != DialogResult.OK)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
