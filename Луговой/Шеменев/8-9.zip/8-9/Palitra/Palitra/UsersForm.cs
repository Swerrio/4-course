﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Palitra
{
    // ЛР 9: управление учётными записями (только администратор)
    public partial class UsersForm : Form
    {
        public UsersForm()
        {
            InitializeComponent();
            Ui.Apply(this);
            cmbRole.SelectedIndex = 0;
            LoadUsers();
        }

        private void LoadUsers()
        {
            List<AppUser> list = null;
            if (!ErrorGuard.Try(() => list = UsersDb.GetAll(), "Не удалось загрузить пользователей"))
            {
                return;
            }
            dgvUsers.DataSource = list;
            lblCount.Text = "Учётных записей: " + list.Count;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            if (login.Length < 3)
            {
                MessageBox.Show("Логин должен быть не короче 3 символов.");
                return;
            }
            foreach (char c in login)
            {
                if (!char.IsLetterOrDigit(c) && c != '_' && c != '.')
                {
                    MessageBox.Show("В логине допускаются буквы, цифры, точка и подчёркивание.");
                    return;
                }
            }
            if (txtPassword.Text.Length < 8)
            {
                MessageBox.Show("Пароль должен быть не короче 8 символов.");
                return;
            }
            string role = cmbRole.SelectedIndex == 1 ? "Admin" : "User";
            if (!ErrorGuard.Try(() => UsersDb.Create(login, txtPassword.Text, role, txtName.Text.Trim()),
                "Не удалось создать учётную запись")) return;

            txtLogin.Clear();
            txtPassword.Clear();
            txtName.Clear();
            LoadUsers();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            AppUser u = dgvUsers.CurrentRow == null ? null : dgvUsers.CurrentRow.DataBoundItem as AppUser;
            if (u == null)
            {
                MessageBox.Show("Выберите учётную запись в таблице.");
                return;
            }
            if (MessageBox.Show("Удалить учётную запись «" + u.Login + "»?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            if (!ErrorGuard.Try(() => UsersDb.Delete(u.Id), "Не удалось удалить учётную запись")) return;
            LoadUsers();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
