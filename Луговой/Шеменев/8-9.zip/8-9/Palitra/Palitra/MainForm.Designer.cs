﻿namespace Palitra
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.btnStudents = new System.Windows.Forms.Button();
            this.btnLessons = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnUsers = new System.Windows.Forms.Button();
            this.btnSignOut = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblStats = new System.Windows.Forms.Label();
            this.SuspendLayout();
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(52, 86, 108);
            this.lblTitle.Location = new System.Drawing.Point(24, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "Художественная школа «Палитра»";
            //
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblWelcome.Location = new System.Drawing.Point(24, 62);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Text = "Добро пожаловать!";
            //
            this.lblRole.AutoSize = true;
            this.lblRole.ForeColor = System.Drawing.Color.FromArgb(52, 86, 108);
            this.lblRole.Location = new System.Drawing.Point(24, 86);
            this.lblRole.Name = "lblRole";
            this.lblRole.Text = "Кабинет";
            //
            this.btnStudents.Location = new System.Drawing.Point(24, 118);
            this.btnStudents.Name = "btnStudents";
            this.btnStudents.Size = new System.Drawing.Size(512, 46);
            this.btnStudents.TabIndex = 0;
            this.btnStudents.Text = "Ученики и творческие работы";
            this.btnStudents.Click += new System.EventHandler(this.btnStudents_Click);
            //
            this.btnLessons.Location = new System.Drawing.Point(24, 174);
            this.btnLessons.Name = "btnLessons";
            this.btnLessons.Size = new System.Drawing.Size(512, 46);
            this.btnLessons.TabIndex = 1;
            this.btnLessons.Text = "Расписание занятий";
            this.btnLessons.Click += new System.EventHandler(this.btnLessons_Click);
            //
            this.btnProfile.Location = new System.Drawing.Point(24, 230);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(251, 46);
            this.btnProfile.TabIndex = 2;
            this.btnProfile.Text = "Мой профиль";
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            //
            this.btnUsers.Location = new System.Drawing.Point(285, 230);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(251, 46);
            this.btnUsers.TabIndex = 3;
            this.btnUsers.Text = "Пользователи";
            this.btnUsers.Click += new System.EventHandler(this.btnUsers_Click);
            //
            this.btnSignOut.Location = new System.Drawing.Point(24, 296);
            this.btnSignOut.Name = "btnSignOut";
            this.btnSignOut.Size = new System.Drawing.Size(251, 38);
            this.btnSignOut.TabIndex = 4;
            this.btnSignOut.Text = "Выйти из учётной записи";
            this.btnSignOut.Click += new System.EventHandler(this.btnSignOut_Click);
            //
            this.btnExit.Location = new System.Drawing.Point(285, 296);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(251, 38);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Закрыть программу";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            //
            this.lblStats.AutoSize = true;
            this.lblStats.ForeColor = System.Drawing.Color.Gray;
            this.lblStats.Location = new System.Drawing.Point(24, 352);
            this.lblStats.Name = "lblStats";
            this.lblStats.Text = "В базе учеников: 0";
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.BackColor = System.Drawing.Color.FromArgb(246, 243, 238);
            this.ClientSize = new System.Drawing.Size(560, 386);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.btnStudents);
            this.Controls.Add(this.btnLessons);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnUsers);
            this.Controls.Add(this.btnSignOut);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblStats);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Палитра — главное меню";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Button btnStudents;
        private System.Windows.Forms.Button btnLessons;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnUsers;
        private System.Windows.Forms.Button btnSignOut;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblStats;
    }
}
