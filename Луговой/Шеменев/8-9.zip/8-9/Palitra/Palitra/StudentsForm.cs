﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Palitra
{
    public partial class StudentsForm : Form
    {
        // что сейчас показано в таблице: все ученики, поиск или фильтр
        private Func<List<Student>> _source = Db.GetAll;
        private bool _filling;

        public StudentsForm()
        {
            InitializeComponent();
            Ui.Apply(this);

            cmbGroup.Items.AddRange(Db.Directions);
            cmbGroup.SelectedIndex = 0;

            cmbFilterDir.Items.Add("Все направления");
            cmbFilterDir.Items.AddRange(Db.Directions);
            cmbFilterDir.SelectedIndex = 0;

            // Запрет ввода цифр в поле ФИО в реальном времени
            txtName.KeyPress += TxtName_KeyPress;

            ApplyRole();
            Reload(Db.GetAll);
        }

        // ЛР 9: пользователь только просматривает данные
        private void ApplyRole()
        {
            bool admin = Auth.IsAdmin;
            btnAdd.Enabled = admin;
            btnEdit.Enabled = admin;
            btnDelete.Enabled = admin;
            btnLoadImage.Enabled = admin;
            btnRemoveImage.Enabled = admin;
            txtName.ReadOnly = !admin;
            txtAge.ReadOnly = !admin;
            txtFee.ReadOnly = !admin;
            cmbGroup.Enabled = admin;
            if (!admin)
            {
                grpData.Text = "Данные ученика (только просмотр)";
                lblDataHint.Text = "Изменять данные может только администратор.";
                foreach (Button b in new[] { btnAdd, btnEdit, btnDelete, btnLoadImage, btnRemoveImage })
                {
                    b.BackColor = Color.FromArgb(170, 180, 188);
                }
            }
        }

        // ---------- Блокировка цифр в поле ФИО ----------
        private void TxtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                return;
            }
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != ' ' && e.KeyChar != '-' &&
                e.KeyChar != '.' && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // ---------- ЛР 8: загрузка из базы ----------
        private Student Selected
        {
            get
            {
                return dgvStudents.CurrentRow == null
                    ? null : dgvStudents.CurrentRow.DataBoundItem as Student;
            }
        }

        // Повторно выполняет запрос и показывает результат; selectId
        // выделяет нужную строку после добавления или изменения
        private bool Reload(Func<List<Student>> source, int selectId = 0)
        {
            List<Student> list = null;
            if (!ErrorGuard.Try(() => list = source(), "Не удалось загрузить учеников из базы"))
            {
                return false;
            }
            _source = source;

            _filling = true;
            dgvStudents.DataSource = list;
            _filling = false;

            int total = list.Count;
            ErrorGuard.Try(() => total = Db.Count(), "Не удалось посчитать учеников");
            lblCount.Text = "Показано: " + list.Count + " из " + total;

            if (selectId > 0)
            {
                foreach (DataGridViewRow row in dgvStudents.Rows)
                {
                    Student s = row.DataBoundItem as Student;
                    if (s != null && s.Id == selectId)
                    {
                        dgvStudents.CurrentCell = row.Cells[0];
                        break;
                    }
                }
            }
            ShowSelected();
            return true;
        }

        private void dgvStudents_SelectionChanged(object sender, EventArgs e)
        {
            if (!_filling) ShowSelected();
        }

        // Выбранная строка заполняет поля и показывает фото работы
        private void ShowSelected()
        {
            Student s = Selected;
            ShowPicture(s);
            if (s == null)
            {
                lblStatus.Text = "Список пуст.";
                return;
            }
            txtName.Text = s.FullName;
            txtAge.Text = s.Age.ToString();
            cmbGroup.Text = s.Direction;
            txtFee.Text = s.FeePerMonth.ToString("0.##");
            lblStatus.Text = "Выбран: " + s.FullName + " | " + s.Direction +
                             " | " + s.FeePerMonth.ToString("N0") + " руб./мес.";
        }

        private void ShowPicture(Student s)
        {
            Image old = picWork.Image;
            picWork.Image = Db.LoadImage(s == null ? null : s.ImagePath);
            if (old != null) old.Dispose();
        }

        // Проверка полей из ЛР 3; null, если что-то заполнено неверно
        private Student ReadFields()
        {
            string name = txtName.Text.Trim();
            if (name.Length == 0)
            {
                MessageBox.Show("Введите ФИО ученика.");
                txtName.Focus();
                return null;
            }
            if (name.Length > 120)
            {
                MessageBox.Show("ФИО не должно быть длиннее 120 символов.");
                return null;
            }
            foreach (char c in name)
            {
                if (!char.IsLetter(c) && c != ' ' && c != '-' && c != '.')
                {
                    MessageBox.Show("ФИО должно содержать только буквы, пробелы, дефис и точку.");
                    txtName.Focus();
                    return null;
                }
            }

            int age;
            if (!int.TryParse(txtAge.Text.Trim(), out age) || age < 5 || age > 100)
            {
                MessageBox.Show("Введите возраст числом от 5 до 100.");
                txtAge.Focus();
                return null;
            }

            decimal fee;
            if (!decimal.TryParse(txtFee.Text.Trim(), out fee) || fee <= 0 || fee > 1000000)
            {
                MessageBox.Show("Введите стоимость месяца числом от 1 до 1000000.");
                txtFee.Focus();
                return null;
            }

            return new Student { FullName = name, Age = age, Direction = cmbGroup.Text, FeePerMonth = fee };
        }

        // ---------- ЛР 8: добавление (INSERT) ----------
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Student s = ReadFields();
            if (s == null) return;
            if (!ErrorGuard.Try(() => Db.Add(s), "Не удалось добавить ученика")) return;

            Reload(Db.GetAll);
            int lastId = 0;
            foreach (DataGridViewRow row in dgvStudents.Rows)
            {
                Student r = row.DataBoundItem as Student;
                if (r != null && r.Id > lastId) lastId = r.Id;
            }
            Reload(Db.GetAll, lastId);
            lblStatus.Text = "Ученик добавлен в базу: " + s.FullName;
        }

        // ---------- ЛР 8: изменение (UPDATE по id) ----------
        private void btnEdit_Click(object sender, EventArgs e)
        {
            Student current = Selected;
            if (current == null)
            {
                MessageBox.Show("Сначала выберите ученика в таблице.");
                return;
            }
            Student s = ReadFields();
            if (s == null) return;
            s.Id = current.Id;
            if (!ErrorGuard.Try(() => Db.Update(s), "Не удалось сохранить изменения")) return;

            Reload(_source, s.Id);
            lblStatus.Text = "Изменения сохранены в базе: " + s.FullName;
        }

        // ---------- ЛР 8: удаление (DELETE по id) ----------
        private void btnDelete_Click(object sender, EventArgs e)
        {
            Student s = Selected;
            if (s == null)
            {
                MessageBox.Show("Сначала выберите ученика в таблице.");
                return;
            }
            if (MessageBox.Show("Удалить ученика " + s.FullName + "?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            if (!ErrorGuard.Try(() => Db.Delete(s.Id), "Не удалось удалить ученика")) return;
            Reload(_source);
            lblStatus.Text = "Ученик удалён из базы.";
        }

        // ---------- ЛР 3: поиск (запрос к базе) ----------
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string q = txtSearch.Text.Trim();
            if (q.Length == 0)
            {
                MessageBox.Show("Введите текст для поиска.");
                return;
            }
            if (!Reload(() => Db.Search(q))) return;
            int found = dgvStudents.Rows.Count;
            if (found == 0)
            {
                MessageBox.Show("Ничего не найдено по запросу: " + q);
            }
            lblStatus.Text = "Найдено совпадений: " + found;
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            cmbFilterDir.SelectedIndex = 0;
            txtFilterAge.Clear();
            Reload(Db.GetAll);
            lblStatus.Text = "Показаны все ученики.";
        }

        // ---------- ЛР 5: фильтр (запрос к базе) ----------
        private void btnFilter_Click(object sender, EventArgs e)
        {
            int minAge = 0;
            string text = txtFilterAge.Text.Trim();
            if (text.Length > 0)
            {
                if (!int.TryParse(text, out minAge) || minAge < 5 || minAge > 100)
                {
                    MessageBox.Show("Возраст должен быть числом от 5 до 100.");
                    return;
                }
            }

            string direction = cmbFilterDir.SelectedIndex <= 0 ? null : cmbFilterDir.Text;
            if (!Reload(() => Db.Filter(direction, minAge))) return;

            int found = dgvStudents.Rows.Count;
            if (found == 0)
                MessageBox.Show("Под фильтр не подошёл ни один ученик.");
            lblStatus.Text = "Фильтр применён. Найдено: " + found;
        }

        private void btnResetFilter_Click(object sender, EventArgs e)
        {
            cmbFilterDir.SelectedIndex = 0;
            txtFilterAge.Clear();
            Reload(Db.GetAll);
            lblStatus.Text = "Фильтр сброшен.";
        }

        // ---------- ЛР 4: расчёт стоимости обучения ----------
        private static decimal CalculateTuition(Student s, int months, bool discount)
        {
            decimal total = s.FeePerMonth * months;
            if (discount) total *= 0.9m;
            return Math.Round(total, 2);
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Student s = Selected;
            if (s == null)
            {
                MessageBox.Show("Сначала выберите ученика в таблице.");
                return;
            }

            string text = txtMonths.Text.Trim();
            if (text.Length == 0)
            {
                MessageBox.Show("Введите количество месяцев.");
                return;
            }

            int months;
            if (!int.TryParse(text, out months))
            {
                MessageBox.Show("Введите количество месяцев числом.");
                return;
            }
            if (months <= 0)
            {
                MessageBox.Show("Количество месяцев должно быть больше нуля.");
                return;
            }
            if (months > 120)
            {
                MessageBox.Show("Максимальный срок расчёта: 120 месяцев.");
                return;
            }

            decimal total = CalculateTuition(s, months, chkDiscount.Checked);
            lblResult.Text = "Итого: " + total.ToString("N2") + " руб.";
            lblStatus.Text = s.FullName + ": " + months + " мес. × " +
                             s.FeePerMonth.ToString("N0") + " руб." +
                             (chkDiscount.Checked ? " (скидка 10%)" : "");
        }

        // ---------- ЛР 5 и 8: фото работы, путь хранится в базе ----------
        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            Student s = Selected;
            if (s == null)
            {
                MessageBox.Show("Сначала выберите ученика в таблице.");
                return;
            }

            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Выберите фото работы ученика";
                ofd.Filter = "Изображения|*.jpg;*.jpeg;*.png|Все файлы|*.*";
                if (ofd.ShowDialog(this) != DialogResult.OK) return;

                string ext = Path.GetExtension(ofd.FileName).ToLowerInvariant();
                if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                {
                    MessageBox.Show("Поддерживаются только файлы .jpg и .png.");
                    return;
                }
                Image check = Db.LoadImage(ofd.FileName);
                if (check == null)
                {
                    MessageBox.Show("Файл не является корректным изображением.");
                    return;
                }
                check.Dispose();

                string name = s.Id + "_" + Guid.NewGuid().ToString("N").Substring(0, 12) + ext;
                string relative = Path.Combine("works", name);
                bool ok = ErrorGuard.Try(() =>
                {
                    Auth.DemandAdmin("менять фото работ");
                    File.Copy(ofd.FileName, Path.Combine(Db.WorksFolder, name), true);
                    Db.SetImage(s.Id, relative);
                }, "Не удалось сохранить фото");
                if (!ok) return;

                Reload(_source, s.Id);
                lblStatus.Text = "Фото сохранено для: " + s.FullName;
            }
        }

        private void btnRemoveImage_Click(object sender, EventArgs e)
        {
            Student s = Selected;
            if (s == null)
            {
                MessageBox.Show("Сначала выберите ученика в таблице.");
                return;
            }
            if (!ErrorGuard.Try(() => Db.SetImage(s.Id, null), "Не удалось убрать фото")) return;
            Reload(_source, s.Id);
            lblStatus.Text = "Изображение удалено.";
        }

        // ---------- ЛР 7 и 8: карточка по актуальной записи из базы ----------
        private void btnCard_Click(object sender, EventArgs e)
        {
            Student selected = Selected;
            if (selected == null)
            {
                MessageBox.Show("Сначала выберите ученика в таблице.");
                return;
            }
            Student fresh = null;
            if (!ErrorGuard.Try(() => fresh = Db.GetById(selected.Id),
                "Не удалось прочитать данные ученика")) return;
            if (fresh == null)
            {
                MessageBox.Show("Ученик уже удалён из базы.");
                Reload(_source);
                return;
            }
            using (StudentCardForm card = new StudentCardForm(fresh))
            {
                card.ShowDialog(this);
            }
        }

        // ---------- Возврат в главное меню ----------
        private void btnBackToMenu_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
