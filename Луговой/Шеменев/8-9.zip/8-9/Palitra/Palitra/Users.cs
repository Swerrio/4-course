﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Security.Cryptography;

namespace Palitra
{
    // Учётная запись сотрудника школы
    public class AppUser
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string Role { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string PhotoPath { get; set; }
        public DateTime RegisteredAt { get; set; }

        public bool IsAdmin { get { return Role == "Admin"; } }
        public string RoleText { get { return IsAdmin ? "Администратор" : "Пользователь"; } }
        public string Title
        {
            get { return string.IsNullOrWhiteSpace(FullName) ? Login : FullName; }
        }
    }

    // Операция запрещена для роли текущего пользователя
    public class ForbiddenException : Exception
    {
        public ForbiddenException(string message) : base(message) { }
    }

    // Текущий вход: кто работает и с какими правами
    public static class Auth
    {
        public static AppUser User;

        public static bool IsAdmin { get { return User != null && User.IsAdmin; } }

        public static void SignOut() { User = null; }

        public static void DemandAdmin(string action)
        {
            if (!IsAdmin)
            {
                throw new ForbiddenException(
                    "Недостаточно прав: " + action + " может только администратор.");
            }
        }

        public static void DemandSelf(int userId, string action)
        {
            if (User == null || User.Id != userId)
            {
                throw new ForbiddenException(
                    "Недостаточно прав: " + action + " можно только в своём профиле.");
            }
        }
    }

    // Хеш пароля: PBKDF2 (SHA-256), соль 16 байт, 40 000 итераций.
    // В поле password_hash хранится «итерации.соль.хеш».
    public static class PasswordHash
    {
        private const int Iterations = 40000;

        public static string Make(string password)
        {
            byte[] salt = new byte[16];
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }
            byte[] hash = Derive(password, salt, Iterations, 32);
            return Iterations + "." + Convert.ToBase64String(salt) + "." +
                Convert.ToBase64String(hash);
        }

        public static bool Check(string password, string stored)
        {
            try
            {
                string[] p = (stored ?? "").Split('.');
                if (p.Length != 3) return false;
                int iterations = int.Parse(p[0]);
                byte[] salt = Convert.FromBase64String(p[1]);
                byte[] expected = Convert.FromBase64String(p[2]);
                byte[] actual = Derive(password ?? "", salt, iterations, expected.Length);
                int diff = 0;
                for (int i = 0; i < expected.Length; i++)
                {
                    diff |= expected[i] ^ actual[i];
                }
                return diff == 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static byte[] Derive(string password, byte[] salt, int iterations, int size)
        {
            using (Rfc2898DeriveBytes kdf = new Rfc2898DeriveBytes(
                password, salt, iterations, HashAlgorithmName.SHA256))
            {
                return kdf.GetBytes(size);
            }
        }
    }

    // Таблица app_users
    public static class UsersDb
    {
        private const string Select =
            "SELECT id, login, password_hash, role, full_name, phone, email, " +
            "photo_path, registered_at FROM app_users";

        // Поиск по логину параметризованным запросом, затем проверка
        // пароля по хешу отдельным шагом в C#
        public static AppUser SignIn(string login, string password)
        {
            string hash = null;
            AppUser user = null;
            using (DbConnection conn = Storage.Open())
            using (DbCommand cmd = Storage.Cmd(conn, Select + " WHERE login = @login",
                "@login", login))
            using (DbDataReader r = cmd.ExecuteReader())
            {
                if (r.Read())
                {
                    hash = Convert.ToString(r["password_hash"]);
                    user = Read(r);
                }
            }
            if (user == null || !PasswordHash.Check(password, hash))
            {
                return null;
            }
            return user;
        }

        public static AppUser Get(int id)
        {
            List<AppUser> list = Query(Select + " WHERE id = @id", "@id", id);
            return list.Count == 0 ? null : list[0];
        }

        public static List<AppUser> GetAll()
        {
            Auth.DemandAdmin("просматривать список пользователей");
            return Query(Select + " ORDER BY id");
        }

        public static void Create(string login, string password, string role, string fullName)
        {
            Auth.DemandAdmin("создавать учётные записи");
            if (Convert.ToInt32(Storage.Scalar(
                "SELECT COUNT(*) FROM app_users WHERE login = @l", "@l", login)) > 0)
            {
                throw new InvalidOperationException("Логин «" + login + "» уже занят.");
            }
            Insert(login, password, role, fullName, null, null);
        }

        public static void Delete(int id)
        {
            Auth.DemandAdmin("удалять учётные записи");
            if (Auth.User.Id == id)
            {
                throw new InvalidOperationException(
                    "Нельзя удалить учётную запись, под которой выполнен вход.");
            }
            Storage.Execute("DELETE FROM app_users WHERE id = @id", "@id", id);
        }

        // Свой профиль: имя, телефон, почта и фото. Роль и логин не меняются.
        public static void SaveProfile(AppUser u)
        {
            Auth.DemandSelf(u.Id, "изменять данные");
            Storage.Execute(
                "UPDATE app_users SET full_name = @n, phone = @ph, email = @e, " +
                "photo_path = @p WHERE id = @id",
                "@n", u.FullName, "@ph", u.Phone, "@e", u.Email,
                "@p", u.PhotoPath, "@id", u.Id);
        }

        public static bool ChangePassword(int id, string oldPassword, string newPassword)
        {
            Auth.DemandSelf(id, "менять пароль");
            string stored = Convert.ToString(Storage.Scalar(
                "SELECT password_hash FROM app_users WHERE id = @id", "@id", id));
            if (!PasswordHash.Check(oldPassword, stored))
            {
                return false;
            }
            Storage.Execute("UPDATE app_users SET password_hash = @h WHERE id = @id",
                "@h", PasswordHash.Make(newPassword), "@id", id);
            return true;
        }

        // Две стартовые учётные записи: Admin и User. Хеш считается
        // в коде, в SQL паролей нет.
        public static void SeedIfEmpty()
        {
            if (Convert.ToInt32(Storage.Scalar("SELECT COUNT(*) FROM app_users")) > 0)
            {
                return;
            }
            Insert("director", "Palitra#26", "Admin", "Соколова Анна Павловна",
                "+7 905 310-21-01", "director@palitra.school");
            Insert("teacher", "Kist#2026", "User", "Громов Денис Викторович",
                "+7 905 310-21-02", "teacher@palitra.school");
        }

        private static void Insert(string login, string password, string role,
            string fullName, string phone, string email)
        {
            Storage.Execute(
                "INSERT INTO app_users (login, password_hash, role, full_name, phone, email) " +
                "VALUES (@l, @h, @r, @n, @ph, @e)",
                "@l", login, "@h", PasswordHash.Make(password), "@r", role,
                "@n", fullName, "@ph", phone, "@e", email);
        }

        private static List<AppUser> Query(string sql, params object[] args)
        {
            List<AppUser> list = new List<AppUser>();
            using (DbConnection conn = Storage.Open())
            using (DbCommand cmd = Storage.Cmd(conn, sql, args))
            using (DbDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    list.Add(Read(r));
                }
            }
            return list;
        }

        private static AppUser Read(DbDataReader r)
        {
            DateTime reg;
            object v = r["registered_at"];
            if (v is DateTime) reg = (DateTime)v;
            else if (!DateTime.TryParse(Convert.ToString(v), out reg)) reg = DateTime.Today;
            return new AppUser
            {
                Id = Convert.ToInt32(r["id"]),
                Login = Convert.ToString(r["login"]),
                Role = Convert.ToString(r["role"]),
                FullName = Text(r["full_name"]),
                Phone = Text(r["phone"]),
                Email = Text(r["email"]),
                PhotoPath = r["photo_path"] == DBNull.Value ? null : Convert.ToString(r["photo_path"]),
                RegisteredAt = reg
            };
        }

        private static string Text(object v)
        {
            return v == DBNull.Value ? "" : Convert.ToString(v);
        }
    }
}
