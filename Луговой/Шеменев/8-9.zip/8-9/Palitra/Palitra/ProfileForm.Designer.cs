﻿namespace Palitra
{
    partial class ProfileForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.picPhoto = new System.Windows.Forms.PictureBox();
            this.lblPhotoInfo = new System.Windows.Forms.Label();
            this.btnPhoto = new System.Windows.Forms.Button();
            this.btnRemovePhoto = new System.Windows.Forms.Button();
            this.lblLogin = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblRegistered = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblSaved = new System.Windows.Forms.Label();
            this.grpPassword = new System.Windows.Forms.GroupBox();
            this.lblOld = new System.Windows.Forms.Label();
            this.txtOld = new System.Windows.Forms.TextBox();
            this.lblNew = new System.Windows.Forms.Label();
            this.txtNew = new System.Windows.Forms.TextBox();
            this.lblRepeat = new System.Windows.Forms.Label();
            this.txtRepeat = new System.Windows.Forms.TextBox();
            this.btnPassword = new System.Windows.Forms.Button();
            this.lblPasswordResult = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picPhoto)).BeginInit();
            this.grpPassword.SuspendLayout();
            this.SuspendLayout();
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(52, 86, 108);
            this.lblTitle.Location = new System.Drawing.Point(20, 16);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "МОЙ ПРОФИЛЬ";
            //
            this.picPhoto.BackColor = System.Drawing.Color.White;
            this.picPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picPhoto.Location = new System.Drawing.Point(24, 60);
            this.picPhoto.Name = "picPhoto";
            this.picPhoto.Size = new System.Drawing.Size(170, 190);
            this.picPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picPhoto.TabStop = false;
            //
            this.lblPhotoInfo.ForeColor = System.Drawing.Color.Gray;
            this.lblPhotoInfo.Location = new System.Drawing.Point(24, 254);
            this.lblPhotoInfo.Name = "lblPhotoInfo";
            this.lblPhotoInfo.Size = new System.Drawing.Size(170, 18);
            this.lblPhotoInfo.Text = "фото не загружено";
            //
            this.btnPhoto.Location = new System.Drawing.Point(24, 276);
            this.btnPhoto.Name = "btnPhoto";
            this.btnPhoto.Size = new System.Drawing.Size(170, 30);
            this.btnPhoto.TabIndex = 5;
            this.btnPhoto.Text = "Выбрать фото";
            this.btnPhoto.Click += new System.EventHandler(this.btnPhoto_Click);
            //
            this.btnRemovePhoto.Location = new System.Drawing.Point(24, 312);
            this.btnRemovePhoto.Name = "btnRemovePhoto";
            this.btnRemovePhoto.Size = new System.Drawing.Size(170, 30);
            this.btnRemovePhoto.TabIndex = 6;
            this.btnRemovePhoto.Text = "Удалить фото";
            this.btnRemovePhoto.Click += new System.EventHandler(this.btnRemovePhoto_Click);
            //
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(214, 62);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Text = "Логин:";
            //
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(214, 86);
            this.lblRole.Name = "lblRole";
            this.lblRole.Text = "Роль:";
            //
            this.lblRegistered.AutoSize = true;
            this.lblRegistered.Location = new System.Drawing.Point(214, 110);
            this.lblRegistered.Name = "lblRegistered";
            this.lblRegistered.Text = "Зарегистрирован:";
            //
            this.lblFullName.AutoSize = true;
            this.lblFullName.Location = new System.Drawing.Point(214, 144);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Text = "Имя и фамилия:";
            //
            this.txtFullName.Location = new System.Drawing.Point(330, 141);
            this.txtFullName.MaxLength = 120;
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(214, 23);
            this.txtFullName.TabIndex = 0;
            //
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(214, 178);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Text = "Телефон:";
            //
            this.txtPhone.Location = new System.Drawing.Point(330, 175);
            this.txtPhone.MaxLength = 30;
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(214, 23);
            this.txtPhone.TabIndex = 1;
            //
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(214, 212);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Text = "Эл. почта:";
            //
            this.txtEmail.Location = new System.Drawing.Point(330, 209);
            this.txtEmail.MaxLength = 100;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(214, 23);
            this.txtEmail.TabIndex = 2;
            //
            this.btnSave.Location = new System.Drawing.Point(214, 248);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(330, 36);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Сохранить изменения";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            //
            this.lblSaved.ForeColor = System.Drawing.Color.FromArgb(40, 120, 70);
            this.lblSaved.Location = new System.Drawing.Point(214, 290);
            this.lblSaved.Name = "lblSaved";
            this.lblSaved.Size = new System.Drawing.Size(330, 36);
            //
            this.grpPassword.BackColor = System.Drawing.Color.White;
            this.grpPassword.Controls.Add(this.lblOld);
            this.grpPassword.Controls.Add(this.txtOld);
            this.grpPassword.Controls.Add(this.lblNew);
            this.grpPassword.Controls.Add(this.txtNew);
            this.grpPassword.Controls.Add(this.lblRepeat);
            this.grpPassword.Controls.Add(this.txtRepeat);
            this.grpPassword.Controls.Add(this.btnPassword);
            this.grpPassword.Controls.Add(this.lblPasswordResult);
            this.grpPassword.Location = new System.Drawing.Point(24, 356);
            this.grpPassword.Name = "grpPassword";
            this.grpPassword.Size = new System.Drawing.Size(520, 150);
            this.grpPassword.TabStop = false;
            this.grpPassword.Text = "Смена пароля";
            //
            this.lblOld.AutoSize = true;
            this.lblOld.Location = new System.Drawing.Point(12, 28);
            this.lblOld.Name = "lblOld";
            this.lblOld.Text = "Старый пароль:";
            //
            this.txtOld.Location = new System.Drawing.Point(170, 25);
            this.txtOld.Name = "txtOld";
            this.txtOld.PasswordChar = '*';
            this.txtOld.Size = new System.Drawing.Size(170, 23);
            this.txtOld.TabIndex = 0;
            //
            this.lblNew.AutoSize = true;
            this.lblNew.Location = new System.Drawing.Point(12, 58);
            this.lblNew.Name = "lblNew";
            this.lblNew.Text = "Новый пароль:";
            //
            this.txtNew.Location = new System.Drawing.Point(170, 55);
            this.txtNew.Name = "txtNew";
            this.txtNew.PasswordChar = '*';
            this.txtNew.Size = new System.Drawing.Size(170, 23);
            this.txtNew.TabIndex = 1;
            //
            this.lblRepeat.AutoSize = true;
            this.lblRepeat.Location = new System.Drawing.Point(12, 88);
            this.lblRepeat.Name = "lblRepeat";
            this.lblRepeat.Text = "Повтор нового:";
            //
            this.txtRepeat.Location = new System.Drawing.Point(170, 85);
            this.txtRepeat.Name = "txtRepeat";
            this.txtRepeat.PasswordChar = '*';
            this.txtRepeat.Size = new System.Drawing.Size(170, 23);
            this.txtRepeat.TabIndex = 2;
            //
            this.btnPassword.Location = new System.Drawing.Point(354, 25);
            this.btnPassword.Name = "btnPassword";
            this.btnPassword.Size = new System.Drawing.Size(154, 83);
            this.btnPassword.TabIndex = 3;
            this.btnPassword.Text = "Сменить пароль";
            this.btnPassword.Click += new System.EventHandler(this.btnPassword_Click);
            //
            this.lblPasswordResult.Location = new System.Drawing.Point(12, 118);
            this.lblPasswordResult.Name = "lblPasswordResult";
            this.lblPasswordResult.Size = new System.Drawing.Size(496, 22);
            //
            this.btnClose.Location = new System.Drawing.Point(394, 518);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(150, 34);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Закрыть";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.BackColor = System.Drawing.Color.FromArgb(246, 243, 238);
            this.ClientSize = new System.Drawing.Size(568, 566);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.picPhoto);
            this.Controls.Add(this.lblPhotoInfo);
            this.Controls.Add(this.btnPhoto);
            this.Controls.Add(this.btnRemovePhoto);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.lblRegistered);
            this.Controls.Add(this.lblFullName);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblSaved);
            this.Controls.Add(this.grpPassword);
            this.Controls.Add(this.btnClose);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ProfileForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Палитра — мой профиль";
            ((System.ComponentModel.ISupportInitialize)(this.picPhoto)).EndInit();
            this.grpPassword.ResumeLayout(false);
            this.grpPassword.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox picPhoto;
        private System.Windows.Forms.Label lblPhotoInfo;
        private System.Windows.Forms.Button btnPhoto;
        private System.Windows.Forms.Button btnRemovePhoto;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Label lblRegistered;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblSaved;
        private System.Windows.Forms.GroupBox grpPassword;
        private System.Windows.Forms.Label lblOld;
        private System.Windows.Forms.TextBox txtOld;
        private System.Windows.Forms.Label lblNew;
        private System.Windows.Forms.TextBox txtNew;
        private System.Windows.Forms.Label lblRepeat;
        private System.Windows.Forms.TextBox txtRepeat;
        private System.Windows.Forms.Button btnPassword;
        private System.Windows.Forms.Label lblPasswordResult;
        private System.Windows.Forms.Button btnClose;
    }
}
