﻿namespace Palitra
{
    partial class ConnectionForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.tabs = new System.Windows.Forms.TabControl();
            this.tabPg = new System.Windows.Forms.TabPage();
            this.lblHost = new System.Windows.Forms.Label();
            this.txtHost = new System.Windows.Forms.TextBox();
            this.lblPort = new System.Windows.Forms.Label();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.lblDatabase = new System.Windows.Forms.Label();
            this.txtDatabase = new System.Windows.Forms.TextBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.tabLite = new System.Windows.Forms.TabPage();
            this.lblLiteInfo = new System.Windows.Forms.Label();
            this.lblFile = new System.Windows.Forms.Label();
            this.txtFile = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.sfdFile = new System.Windows.Forms.SaveFileDialog();
            this.tabs.SuspendLayout();
            this.tabPg.SuspendLayout();
            this.tabLite.SuspendLayout();
            this.SuspendLayout();
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(52, 86, 108);
            this.lblTitle.Location = new System.Drawing.Point(20, 16);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "Подключение к базе данных";
            //
            this.lblInfo.ForeColor = System.Drawing.Color.Gray;
            this.lblInfo.Location = new System.Drawing.Point(22, 52);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(436, 48);
            this.lblInfo.Text = "Выберите вкладку с нужным хранилищем. Настройки сохраняются в файл Palitra.exe.config рядом с программой.";
            //
            this.tabs.Controls.Add(this.tabPg);
            this.tabs.Controls.Add(this.tabLite);
            this.tabs.Location = new System.Drawing.Point(20, 106);
            this.tabs.Name = "tabs";
            this.tabs.SelectedIndex = 0;
            this.tabs.Size = new System.Drawing.Size(440, 196);
            this.tabs.TabIndex = 0;
            //
            this.tabPg.BackColor = System.Drawing.Color.White;
            this.tabPg.Controls.Add(this.lblHost);
            this.tabPg.Controls.Add(this.txtHost);
            this.tabPg.Controls.Add(this.lblPort);
            this.tabPg.Controls.Add(this.txtPort);
            this.tabPg.Controls.Add(this.lblDatabase);
            this.tabPg.Controls.Add(this.txtDatabase);
            this.tabPg.Controls.Add(this.lblUser);
            this.tabPg.Controls.Add(this.txtUser);
            this.tabPg.Controls.Add(this.lblPassword);
            this.tabPg.Controls.Add(this.txtPassword);
            this.tabPg.Location = new System.Drawing.Point(4, 24);
            this.tabPg.Name = "tabPg";
            this.tabPg.Padding = new System.Windows.Forms.Padding(3);
            this.tabPg.Size = new System.Drawing.Size(432, 168);
            this.tabPg.TabIndex = 0;
            this.tabPg.Text = "PostgreSQL (сервер)";
            //
            this.lblHost.AutoSize = true;
            this.lblHost.Location = new System.Drawing.Point(14, 18);
            this.lblHost.Name = "lblHost";
            this.lblHost.Text = "Сервер:";
            //
            this.txtHost.Location = new System.Drawing.Point(120, 15);
            this.txtHost.Name = "txtHost";
            this.txtHost.Size = new System.Drawing.Size(170, 23);
            this.txtHost.TabIndex = 0;
            //
            this.lblPort.AutoSize = true;
            this.lblPort.Location = new System.Drawing.Point(302, 18);
            this.lblPort.Name = "lblPort";
            this.lblPort.Text = "Порт:";
            //
            this.txtPort.Location = new System.Drawing.Point(346, 15);
            this.txtPort.MaxLength = 5;
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(70, 23);
            this.txtPort.TabIndex = 1;
            //
            this.lblDatabase.AutoSize = true;
            this.lblDatabase.Location = new System.Drawing.Point(14, 54);
            this.lblDatabase.Name = "lblDatabase";
            this.lblDatabase.Text = "База данных:";
            //
            this.txtDatabase.Location = new System.Drawing.Point(120, 51);
            this.txtDatabase.Name = "txtDatabase";
            this.txtDatabase.Size = new System.Drawing.Size(296, 23);
            this.txtDatabase.TabIndex = 2;
            //
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(14, 90);
            this.lblUser.Name = "lblUser";
            this.lblUser.Text = "Пользователь:";
            //
            this.txtUser.Location = new System.Drawing.Point(120, 87);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(296, 23);
            this.txtUser.TabIndex = 3;
            //
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(14, 126);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Text = "Пароль:";
            //
            this.txtPassword.Location = new System.Drawing.Point(120, 123);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(296, 23);
            this.txtPassword.TabIndex = 4;
            //
            this.tabLite.BackColor = System.Drawing.Color.White;
            this.tabLite.Controls.Add(this.lblLiteInfo);
            this.tabLite.Controls.Add(this.lblFile);
            this.tabLite.Controls.Add(this.txtFile);
            this.tabLite.Controls.Add(this.btnBrowse);
            this.tabLite.Location = new System.Drawing.Point(4, 24);
            this.tabLite.Name = "tabLite";
            this.tabLite.Padding = new System.Windows.Forms.Padding(3);
            this.tabLite.Size = new System.Drawing.Size(432, 168);
            this.tabLite.TabIndex = 1;
            this.tabLite.Text = "SQLite (файл)";
            //
            this.lblLiteInfo.Location = new System.Drawing.Point(14, 14);
            this.lblLiteInfo.Name = "lblLiteInfo";
            this.lblLiteInfo.Size = new System.Drawing.Size(402, 48);
            this.lblLiteInfo.Text = "Запасной вариант, если сервер PostgreSQL на компьютере не запускается. База хранится в одном файле, сервер не нужен.";
            //
            this.lblFile.AutoSize = true;
            this.lblFile.Location = new System.Drawing.Point(14, 76);
            this.lblFile.Name = "lblFile";
            this.lblFile.Text = "Файл базы:";
            //
            this.txtFile.Location = new System.Drawing.Point(14, 96);
            this.txtFile.Name = "txtFile";
            this.txtFile.Size = new System.Drawing.Size(300, 23);
            this.txtFile.TabIndex = 0;
            //
            this.btnBrowse.Location = new System.Drawing.Point(322, 94);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(94, 27);
            this.btnBrowse.TabIndex = 1;
            this.btnBrowse.Text = "Обзор";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            //
            this.lblResult.Location = new System.Drawing.Point(22, 308);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(436, 36);
            //
            this.btnTest.Location = new System.Drawing.Point(20, 350);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(140, 34);
            this.btnTest.TabIndex = 1;
            this.btnTest.Text = "Проверить";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            //
            this.btnSave.Location = new System.Drawing.Point(170, 350);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(150, 34);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            //
            this.btnCancel.Location = new System.Drawing.Point(330, 350);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(130, 34);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            //
            this.sfdFile.DefaultExt = "db";
            this.sfdFile.Filter = "База SQLite|*.db";
            this.sfdFile.OverwritePrompt = false;
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.BackColor = System.Drawing.Color.FromArgb(246, 243, 238);
            this.ClientSize = new System.Drawing.Size(480, 400);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.tabs);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConnectionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Палитра — подключение к базе данных";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ConnectionForm_FormClosing);
            this.tabs.ResumeLayout(false);
            this.tabPg.ResumeLayout(false);
            this.tabPg.PerformLayout();
            this.tabLite.ResumeLayout(false);
            this.tabLite.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage tabPg;
        private System.Windows.Forms.Label lblHost;
        private System.Windows.Forms.TextBox txtHost;
        private System.Windows.Forms.Label lblPort;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label lblDatabase;
        private System.Windows.Forms.TextBox txtDatabase;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TabPage tabLite;
        private System.Windows.Forms.Label lblLiteInfo;
        private System.Windows.Forms.Label lblFile;
        private System.Windows.Forms.TextBox txtFile;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.SaveFileDialog sfdFile;
    }
}
