﻿namespace ArtSchoolApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.lblCourse = new System.Windows.Forms.Label();
            this.txtCourse = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnShowAll = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lstStudents = new System.Windows.Forms.ListBox();
            this.grpCalculate = new System.Windows.Forms.GroupBox();
            this.lblLessons = new System.Windows.Forms.Label();
            this.txtLessons = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            // === НОВЫЕ ЭЛЕМЕНТЫ ДЛЯ ЛР №5 ===
            this.grpFilter = new System.Windows.Forms.GroupBox();
            this.lblAgeFilter = new System.Windows.Forms.Label();
            this.cmbAgeFilter = new System.Windows.Forms.ComboBox();
            this.btnApplyFilter = new System.Windows.Forms.Button();
            this.grpImage = new System.Windows.Forms.GroupBox();
            this.picStudent = new System.Windows.Forms.PictureBox();
            this.btnAddImage = new System.Windows.Forms.Button();
            this.btnClearImage = new System.Windows.Forms.Button();
            this.lblImageStatus = new System.Windows.Forms.Label();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.grpCalculate.SuspendLayout();
            this.grpFilter.SuspendLayout();
            this.grpImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStudent)).BeginInit();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Text = "Художественная школа v0.3";

            // lblName
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 50);
            this.lblName.Text = "ФИО ученика:";
            this.txtName.Location = new System.Drawing.Point(130, 47);
            this.txtName.Size = new System.Drawing.Size(200, 20);

            // lblAge
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(12, 80);
            this.lblAge.Text = "Возраст:";
            this.txtAge.Location = new System.Drawing.Point(130, 77);
            this.txtAge.Size = new System.Drawing.Size(80, 20);

            // lblCourse
            this.lblCourse.AutoSize = true;
            this.lblCourse.Location = new System.Drawing.Point(12, 110);
            this.lblCourse.Text = "Название курса:";
            this.txtCourse.Location = new System.Drawing.Point(130, 107);
            this.txtCourse.Size = new System.Drawing.Size(200, 20);

            // btnAdd
            this.btnAdd.Location = new System.Drawing.Point(12, 145);
            this.btnAdd.Size = new System.Drawing.Size(90, 28);
            this.btnAdd.Text = "Добавить";

            // btnDelete
            this.btnDelete.Location = new System.Drawing.Point(110, 145);
            this.btnDelete.Size = new System.Drawing.Size(90, 28);
            this.btnDelete.Text = "Удалить";

            // btnShowAll
            this.btnShowAll.Location = new System.Drawing.Point(210, 145);
            this.btnShowAll.Size = new System.Drawing.Size(120, 28);
            this.btnShowAll.Text = "Показать всех";

            // lblSearch
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(12, 185);
            this.lblSearch.Text = "Поиск по ФИО:";
            this.txtSearch.Location = new System.Drawing.Point(130, 182);
            this.txtSearch.Size = new System.Drawing.Size(120, 20);

            // btnSearch
            this.btnSearch.Location = new System.Drawing.Point(260, 180);
            this.btnSearch.Size = new System.Drawing.Size(70, 25);
            this.btnSearch.Text = "Найти";

            // lstStudents
            this.lstStudents.FormattingEnabled = true;
            this.lstStudents.Location = new System.Drawing.Point(12, 215);
            this.lstStudents.Size = new System.Drawing.Size(320, 120);

            // === ГРУППА: РАСЧЁТ СТОИМОСТИ (из ЛР №4) ===
            this.grpCalculate.Controls.Add(this.lblLessons);
            this.grpCalculate.Controls.Add(this.txtLessons);
            this.grpCalculate.Controls.Add(this.lblPrice);
            this.grpCalculate.Controls.Add(this.txtPrice);
            this.grpCalculate.Controls.Add(this.btnCalculate);
            this.grpCalculate.Controls.Add(this.lblResult);
            this.grpCalculate.Location = new System.Drawing.Point(12, 345);
            this.grpCalculate.Size = new System.Drawing.Size(320, 120);
            this.grpCalculate.Text = "Расчёт стоимости обучения";

            this.lblLessons.AutoSize = true;
            this.lblLessons.Location = new System.Drawing.Point(10, 22);
            this.lblLessons.Text = "Занятий:";
            this.txtLessons.Location = new System.Drawing.Point(100, 19);
            this.txtLessons.Size = new System.Drawing.Size(60, 20);

            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(10, 50);
            this.lblPrice.Text = "Цена (руб.):";
            this.txtPrice.Location = new System.Drawing.Point(100, 47);
            this.txtPrice.Size = new System.Drawing.Size(60, 20);

            this.btnCalculate.Location = new System.Drawing.Point(170, 19);
            this.btnCalculate.Size = new System.Drawing.Size(140, 50);
            this.btnCalculate.Text = "Рассчитать";

            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblResult.Location = new System.Drawing.Point(10, 80);
            this.lblResult.Text = "Результат: ";
            this.lblResult.MaximumSize = new System.Drawing.Size(300, 0);

            // === ГРУППА: ФИЛЬТРАЦИЯ ПО ВОЗРАСТУ (НОВОЕ ДЛЯ ЛР №5) ===
            this.grpFilter.Controls.Add(this.lblAgeFilter);
            this.grpFilter.Controls.Add(this.cmbAgeFilter);
            this.grpFilter.Controls.Add(this.btnApplyFilter);
            this.grpFilter.Location = new System.Drawing.Point(350, 50);
            this.grpFilter.Size = new System.Drawing.Size(250, 100);
            this.grpFilter.Text = "Фильтрация по возрасту";

            this.lblAgeFilter.AutoSize = true;
            this.lblAgeFilter.Location = new System.Drawing.Point(10, 25);
            this.lblAgeFilter.Text = "Возрастная группа:";

            this.cmbAgeFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAgeFilter.Location = new System.Drawing.Point(10, 45);
            this.cmbAgeFilter.Size = new System.Drawing.Size(150, 21);
            this.cmbAgeFilter.Items.AddRange(new object[] {
                "Все возрасты",
                "5–9 лет (младшие)",
                "10–12 лет (средние)",
                "13–17 лет (старшие)"
            });
            this.cmbAgeFilter.SelectedIndex = 0;

            this.btnApplyFilter.Location = new System.Drawing.Point(170, 43);
            this.btnApplyFilter.Size = new System.Drawing.Size(70, 25);
            this.btnApplyFilter.Text = "Применить";

            // === ГРУППА: ИЗОБРАЖЕНИЕ (НОВОЕ ДЛЯ ЛР №5) ===
            this.grpImage.Controls.Add(this.picStudent);
            this.grpImage.Controls.Add(this.btnAddImage);
            this.grpImage.Controls.Add(this.btnClearImage);
            this.grpImage.Controls.Add(this.lblImageStatus);
            this.grpImage.Location = new System.Drawing.Point(350, 160);
            this.grpImage.Size = new System.Drawing.Size(250, 305);
            this.grpImage.Text = "Фотография ученика";

            this.picStudent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picStudent.Location = new System.Drawing.Point(10, 20);
            this.picStudent.Size = new System.Drawing.Size(230, 200);
            this.picStudent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picStudent.BackColor = System.Drawing.Color.White;

            this.btnAddImage.Location = new System.Drawing.Point(10, 230);
            this.btnAddImage.Size = new System.Drawing.Size(110, 30);
            this.btnAddImage.Text = "Добавить фото";

            this.btnClearImage.Location = new System.Drawing.Point(130, 230);
            this.btnClearImage.Size = new System.Drawing.Size(110, 30);
            this.btnClearImage.Text = "Очистить";

            this.lblImageStatus.AutoSize = true;
            this.lblImageStatus.Location = new System.Drawing.Point(10, 270);
            this.lblImageStatus.Text = "Фото не выбрано";
            this.lblImageStatus.ForeColor = System.Drawing.Color.Gray;

            // openFileDialog
            this.openFileDialog.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*";
            this.openFileDialog.Title = "Выберите фотографию ученика";

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 481);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.lblCourse);
            this.Controls.Add(this.txtCourse);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lstStudents);
            this.Controls.Add(this.grpCalculate);
            this.Controls.Add(this.grpFilter);
            this.Controls.Add(this.grpImage);
            this.Name = "Form1";
            this.Text = "Художественная школа v0.3";
            this.grpCalculate.ResumeLayout(false);
            this.grpCalculate.PerformLayout();
            this.grpFilter.ResumeLayout(false);
            this.grpFilter.PerformLayout();
            this.grpImage.ResumeLayout(false);
            this.grpImage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblCourse;
        private System.Windows.Forms.TextBox txtCourse;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ListBox lstStudents;
        private System.Windows.Forms.GroupBox grpCalculate;
        private System.Windows.Forms.Label lblLessons;
        private System.Windows.Forms.TextBox txtLessons;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblResult;
        // Новые элементы для ЛР №5
        private System.Windows.Forms.GroupBox grpFilter;
        private System.Windows.Forms.Label lblAgeFilter;
        private System.Windows.Forms.ComboBox cmbAgeFilter;
        private System.Windows.Forms.Button btnApplyFilter;
        private System.Windows.Forms.GroupBox grpImage;
        private System.Windows.Forms.PictureBox picStudent;
        private System.Windows.Forms.Button btnAddImage;
        private System.Windows.Forms.Button btnClearImage;
        private System.Windows.Forms.Label lblImageStatus;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
    }
}