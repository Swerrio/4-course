using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ArtSchoolApp
{
    public partial class Form1 : Form
    {
        private List<Student> allStudents = new List<Student>();
        private List<Student> displayedStudents = new List<Student>();

        public Form1()
        {
            InitializeComponent();

            this.btnAdd.Click += BtnAdd_Click;
            this.btnDelete.Click += BtnDelete_Click;
            this.btnSearch.Click += BtnSearch_Click;
            this.btnShowAll.Click += BtnShowAll_Click;
            this.btnCalculate.Click += BtnCalculate_Click;
            // Новые привязки для ЛР №5
            this.btnApplyFilter.Click += BtnApplyFilter_Click;
            this.btnAddImage.Click += BtnAddImage_Click;
            this.btnClearImage.Click += BtnClearImage_Click;
            this.lstStudents.SelectedIndexChanged += LstStudents_SelectedIndexChanged;

            RefreshList();
        }

        // =====================================================================
        // ДОБАВЛЕНИЕ УЧЕНИКА (из ЛР №3)
        // =====================================================================
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string ageText = txtAge.Text.Trim();
            string course = txtCourse.Text.Trim();

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Ошибка: Введите ФИО ученика.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(ageText, out int age) || age <= 0 || age > 120)
            {
                MessageBox.Show("Ошибка: Введите корректный возраст (целое число от 1 до 120).",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(course))
            {
                MessageBox.Show("Ошибка: Введите название курса.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Student newStudent = new Student
            {
                FullName = name,
                Age = age,
                CourseName = course,
                PhotoPath = null
            };

            allStudents.Add(newStudent);

            txtName.Clear();
            txtAge.Clear();
            txtCourse.Clear();
            txtName.Focus();

            RefreshList();
        }

        // =====================================================================
        // УДАЛЕНИЕ УЧЕНИКА (из ЛР №3)
        // =====================================================================
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (lstStudents.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите ученика в списке для удаления.",
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Student selectedStudent = displayedStudents[lstStudents.SelectedIndex];
            allStudents.Remove(selectedStudent);

            RefreshList();
            ClearImage();
        }

        // =====================================================================
        // ПОИСК УЧЕНИКА (из ЛР №3)
        // =====================================================================
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearch.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(searchQuery))
            {
                MessageBox.Show("Введите текст для поиска.",
                    "Поиск", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            displayedStudents = allStudents
                .Where(s => s.FullName.ToLower().Contains(searchQuery))
                .ToList();

            RefreshList();
        }

        private void BtnShowAll_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            cmbAgeFilter.SelectedIndex = 0;
            RefreshList();
        }

        // =====================================================================
        // РАСЧЁТ СТОИМОСТИ (из ЛР №4)
        // =====================================================================
        private decimal CalculateTrainingCost(int lessons, decimal pricePerLesson)
        {
            return lessons * pricePerLesson;
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            if (lstStudents.SelectedIndex == -1)
            {
                MessageBox.Show("Сначала выберите ученика из списка для расчёта.",
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string lessonsText = txtLessons.Text.Trim();
            string priceText = txtPrice.Text.Trim();

            if (string.IsNullOrEmpty(lessonsText) || string.IsNullOrEmpty(priceText))
            {
                MessageBox.Show("Заполните все поля для расчёта.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(lessonsText, out int lessons) || lessons <= 0)
            {
                MessageBox.Show("Введите корректное количество занятий (целое число больше 0).",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(priceText, NumberStyles.Any,
                CultureInfo.InvariantCulture, out decimal price) || price <= 0)
            {
                MessageBox.Show("Введите корректную стоимость занятия (число больше 0).",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (lessons > 10000 || price > 1000000)
            {
                MessageBox.Show("Слишком большие значения. Проверьте введённые данные.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal totalCost = CalculateTrainingCost(lessons, price);
            Student selectedStudent = displayedStudents[lstStudents.SelectedIndex];

            lblResult.Text = $"Стоимость обучения для {selectedStudent.FullName}: " +
                             $"{totalCost} руб. ({lessons} зан. по {price} руб.)";
        }

        // =====================================================================
        // НОВЫЙ МОДУЛЬ ЛР №5: ФИЛЬТРАЦИЯ УЧЕНИКОВ ПО ВОЗРАСТУ
        // =====================================================================

        /// <summary>
        /// Основная операция модуля фильтрации.
        /// Возвращает список учеников, попадающих в указанный возрастной диапазон.
        /// </summary>
        private List<Student> FilterStudentsByAge(List<Student> students, int minAge, int maxAge)
        {
            return students.Where(s => s.Age >= minAge && s.Age <= maxAge).ToList();
        }

        private void BtnApplyFilter_Click(object sender, EventArgs e)
        {
            int selectedIndex = cmbAgeFilter.SelectedIndex;

            // Применяем фильтр поверх текущего состояния (поиска)
            List<Student> source = string.IsNullOrWhiteSpace(txtSearch.Text)
                ? allStudents.ToList()
                : allStudents.Where(s => s.FullName.ToLower().Contains(txtSearch.Text.Trim().ToLower())).ToList();

            switch (selectedIndex)
            {
                case 0: // Все возрасты
                    displayedStudents = source;
                    break;
                case 1: // 5–9 лет
                    displayedStudents = FilterStudentsByAge(source, 5, 9);
                    break;
                case 2: // 10–12 лет
                    displayedStudents = FilterStudentsByAge(source, 10, 12);
                    break;
                case 3: // 13–17 лет
                    displayedStudents = FilterStudentsByAge(source, 13, 17);
                    break;
                default:
                    displayedStudents = source;
                    break;
            }

            RefreshList();

            if (displayedStudents.Count == 0)
            {
                MessageBox.Show("Ученики в выбранной возрастной группе не найдены.",
                    "Фильтрация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // =====================================================================
        // НОВЫЙ МОДУЛЬ ЛР №5: РАБОТА С ИЗОБРАЖЕНИЯМИ
        // =====================================================================

        private void BtnAddImage_Click(object sender, EventArgs e)
        {
            if (lstStudents.SelectedIndex == -1)
            {
                MessageBox.Show("Сначала выберите ученика из списка.",
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = openFileDialog.ShowDialog();

            if (result == DialogResult.Cancel)
            {
                lblImageStatus.Text = "Выбор отменён";
                lblImageStatus.ForeColor = Color.Gray;
                return;
            }

            string filePath = openFileDialog.FileName;
            string extension = Path.GetExtension(filePath).ToLower();

            // Проверка формата файла
            if (extension != ".jpg" && extension != ".jpeg" && extension != ".png" && extension != ".bmp")
            {
                MessageBox.Show("Неподдерживаемый формат файла.\nДопустимые форматы: .jpg, .jpeg, .png, .bmp",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblImageStatus.Text = "Неподдерживаемый формат";
                lblImageStatus.ForeColor = Color.Red;
                return;
            }

            try
            {
                // Загружаем изображение в PictureBox
                picStudent.Image = Image.FromFile(filePath);

                // Сохраняем путь в объекте ученика
                Student selectedStudent = displayedStudents[lstStudents.SelectedIndex];
                selectedStudent.PhotoPath = filePath;

                lblImageStatus.Text = $"Загружено: {Path.GetFileName(filePath)}";
                lblImageStatus.ForeColor = Color.Green;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось загрузить изображение:\n{ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblImageStatus.Text = "Ошибка загрузки";
                lblImageStatus.ForeColor = Color.Red;
            }
        }

        private void BtnClearImage_Click(object sender, EventArgs e)
        {
            ClearImage();
        }

        private void ClearImage()
        {
            if (picStudent.Image != null)
            {
                picStudent.Image.Dispose();
                picStudent.Image = null;
            }

            if (lstStudents.SelectedIndex != -1 && lstStudents.SelectedIndex < displayedStudents.Count)
            {
                Student selectedStudent = displayedStudents[lstStudents.SelectedIndex];
                selectedStudent.PhotoPath = null;
            }

            lblImageStatus.Text = "Фото не выбрано";
            lblImageStatus.ForeColor = Color.Gray;
        }

        /// <summary>
        /// При выборе ученика в списке — отображаем его фотографию (если есть).
        /// </summary>
        private void LstStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstStudents.SelectedIndex == -1)
            {
                ClearImage();
                return;
            }

            Student selectedStudent = displayedStudents[lstStudents.SelectedIndex];

            if (!string.IsNullOrEmpty(selectedStudent.PhotoPath) && File.Exists(selectedStudent.PhotoPath))
            {
                try
                {
                    if (picStudent.Image != null)
                    {
                        picStudent.Image.Dispose();
                    }
                    picStudent.Image = Image.FromFile(selectedStudent.PhotoPath);
                    lblImageStatus.Text = $"Загружено: {Path.GetFileName(selectedStudent.PhotoPath)}";
                    lblImageStatus.ForeColor = Color.Green;
                }
                catch
                {
                    lblImageStatus.Text = "Файл недоступен";
                    lblImageStatus.ForeColor = Color.Red;
                }
            }
            else
            {
                if (picStudent.Image != null)
                {
                    picStudent.Image.Dispose();
                    picStudent.Image = null;
                }
                lblImageStatus.Text = "Фото не выбрано";
                lblImageStatus.ForeColor = Color.Gray;
            }
        }

        // =====================================================================
        // ОБНОВЛЕНИЕ СПИСКА
        // =====================================================================
        private void RefreshList()
        {
            lstStudents.Items.Clear();

            if (string.IsNullOrWhiteSpace(txtSearch.Text) && cmbAgeFilter.SelectedIndex == 0)
            {
                displayedStudents = allStudents.ToList();
            }

            foreach (var student in displayedStudents)
            {
                lstStudents.Items.Add(student.ToString());
            }
        }
    }
}