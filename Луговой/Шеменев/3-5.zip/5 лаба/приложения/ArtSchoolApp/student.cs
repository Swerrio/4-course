﻿using System;

namespace ArtSchoolApp
{
    public class Student
    {
        public string FullName { get; set; }
        public int Age { get; set; }
        public string CourseName { get; set; }
        public string PhotoPath { get; set; } // Путь к фотографии ученика

        public override string ToString()
        {
            return $"{FullName} | Возраст: {Age} | Курс: {CourseName}";
        }
    }
}