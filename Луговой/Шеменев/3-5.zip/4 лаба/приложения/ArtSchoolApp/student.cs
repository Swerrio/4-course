﻿using System;

namespace ArtSchoolApp
{
    public class Student
    {
        public string FullName { get; set; }
        public int Age { get; set; }
        public string CourseName { get; set; }

        public override string ToString()
        {
            return $"{FullName} | Возраст: {Age} | Курс: {CourseName}";
        }
    }
}