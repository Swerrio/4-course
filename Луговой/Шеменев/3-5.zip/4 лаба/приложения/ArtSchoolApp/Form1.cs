using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace ArtSchoolApp
{
    public partial class Form1 : Form
    {
        // Коллекция для хранения всех учеников
        private List<Student> allStudents = new List<Student>();

        // Временная коллекция для отображения (нужна для поиска)
        private List<Student> displayedStudents = new List<Student>();

        public Form1()
        {
            InitializeComponent();

            // Привязка кнопок к методам
            this.btnAdd.Click += BtnAdd_Click;
            this.btnDelete.Click += BtnDelete_Click;
            this.btnSearch.Click += BtnSearch_Click;
            this.btnShowAll.Click += BtnShowAll_Click;
            this.btnCalculate.Click += BtnCalculate_Click; // Новая кнопка

            RefreshList();
        }

        // --- ДОБАВЛЕНИЕ УЧЕНИКА ---
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string ageText = txtAge.Text.Trim();
            string course = txtCourse.Text.Trim();

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Ошибка: Введите ФИО ученика.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(ageText, out int age) || age <= 0 || age > 120)
            {
                MessageBox.Show("Ошибка: Введите корректный возраст (целое число от 1 до 120).\nНельзя вводить буквы или отрицательные числа!", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(course))
            {
                MessageBox.Show("Ошибка: Введите название курса.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Student newStudent = new Student
            {
                FullName = name,
                Age = age,
                CourseName = course
            };

            allStudents.Add(newStudent);

            txtName.Clear();
            txtAge.Clear();
            txtCourse.Clear();
            txtName.Focus();

            RefreshList();
        }

        // --- УДАЛЕНИЕ УЧЕНИКА ---
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (lstStudents.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите ученика в списке для удаления.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Student selectedStudent = displayedStudents[lstStudents.SelectedIndex];
            allStudents.Remove(selectedStudent);

            RefreshList();
        }

        // --- ПОИСК УЧЕНИКА ---
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearch.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(searchQuery))
            {
                MessageBox.Show("Введите текст для поиска.", "Поиск", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            displayedStudents = allStudents
                .Where(s => s.FullName.ToLower().Contains(searchQuery))
                .ToList();

            RefreshList();
        }

        // --- СБРОС ПОИСКА ---
        private void BtnShowAll_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            RefreshList();
        }

        // =====================================================================
        // НОВЫЙ ФУНКЦИОНАЛЬНЫЙ МОДУЛЬ: РАСЧЁТ СТОИМОСТИ ОБУЧЕНИЯ (ЛР №4)
        // =====================================================================

        /// <summary>
        /// Основная операция функционального модуля.
        /// Выполняет расчёт стоимости обучения для выбранного ученика.
        /// </summary>
        /// <param name="lessons">Количество занятий (должно быть > 0)</param>
        /// <param name="pricePerLesson">Стоимость одного занятия (должна быть > 0)</param>
        /// <returns>Итоговая стоимость обучения</returns>
        private decimal CalculateTrainingCost(int lessons, decimal pricePerLesson)
        {
            return lessons * pricePerLesson;
        }

        /// <summary>
        /// Обработчик кнопки "Рассчитать".
        /// Выполняет валидацию ввода и вызывает метод CalculateTrainingCost.
        /// </summary>
        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            // 1. Проверка: выбран ли ученик
            if (lstStudents.SelectedIndex == -1)
            {
                MessageBox.Show("Сначала выберите ученика из списка для расчёта.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string lessonsText = txtLessons.Text.Trim();
            string priceText = txtPrice.Text.Trim();

            // 2. Проверка на пустые поля
            if (string.IsNullOrEmpty(lessonsText) || string.IsNullOrEmpty(priceText))
            {
                MessageBox.Show("Заполните все поля для расчёта.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 3. Проверка количества занятий (целое число > 0)
            if (!int.TryParse(lessonsText, out int lessons) || lessons <= 0)
            {
                MessageBox.Show("Введите корректное количество занятий (целое число больше 0).\nБуквы, символы и «Ё» недопустимы.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 4. Проверка стоимости (дробное или целое число > 0)
            // Используем NumberStyles.Any и CultureInfo.InvariantCulture, чтобы принимать и точку, и запятую
            if (!decimal.TryParse(priceText, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal price) || price <= 0)
            {
                MessageBox.Show("Введите корректную стоимость занятия (число больше 0).\nМожно использовать точку или запятую как разделитель.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 5. Проверка на слишком большое значение (защита от переполнения)
            if (lessons > 10000 || price > 1000000)
            {
                MessageBox.Show("Слишком большие значения. Проверьте введённые данные.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 6. Вызов основной операции (отдельный метод)
            decimal totalCost = CalculateTrainingCost(lessons, price);

            // 7. Получение данных выбранного ученика
            Student selectedStudent = displayedStudents[lstStudents.SelectedIndex];

            // 8. Отображение результата
            lblResult.Text = $"Стоимость обучения для {selectedStudent.FullName}: {totalCost} руб. ({lessons} зан. по {price} руб.)";
        }

        // --- ОБНОВЛЕНИЕ СПИСКА НА ЭКРАНЕ ---
        private void RefreshList()
        {
            lstStudents.Items.Clear();

            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                displayedStudents = allStudents.ToList();
            }

            foreach (var student in displayedStudents)
            {
                lstStudents.Items.Add(student.ToString());
            }
        }
    }
}