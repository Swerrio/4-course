﻿namespace ArtSchoolApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblName = new Label();
            txtName = new TextBox();
            lblAge = new Label();
            txtAge = new TextBox();
            lblCourse = new Label();
            txtCourse = new TextBox();
            btnAdd = new Button();
            btnDelete = new Button();
            btnShowAll = new Button();
            lblSearch = new Label();
            txtSearch = new TextBox();
            btnSearch = new Button();
            lstStudents = new ListBox();
            grpCalculate = new GroupBox();
            lblLessons = new Label();
            txtLessons = new TextBox();
            lblPrice = new Label();
            txtPrice = new TextBox();
            btnCalculate = new Button();
            lblResult = new Label();
            grpCalculate.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold);
            lblTitle.Location = new Point(14, 10);
            lblTitle.Margin = new Padding(4, 0, 4, 0);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(286, 24);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Художественная школа v0.2";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(14, 58);
            lblName.Margin = new Padding(4, 0, 4, 0);
            lblName.Name = "lblName";
            lblName.Size = new Size(85, 15);
            lblName.TabIndex = 1;
            lblName.Text = "ФИО ученика:";
            // 
            // txtName
            // 
            txtName.Location = new Point(140, 54);
            txtName.Margin = new Padding(4, 3, 4, 3);
            txtName.Name = "txtName";
            txtName.Size = new Size(291, 23);
            txtName.TabIndex = 2;
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.Location = new Point(14, 92);
            lblAge.Margin = new Padding(4, 0, 4, 0);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(53, 15);
            lblAge.TabIndex = 3;
            lblAge.Text = "Возраст:";
            // 
            // txtAge
            // 
            txtAge.Location = new Point(140, 89);
            txtAge.Margin = new Padding(4, 3, 4, 3);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(116, 23);
            txtAge.TabIndex = 4;
            // 
            // lblCourse
            // 
            lblCourse.AutoSize = true;
            lblCourse.Location = new Point(14, 127);
            lblCourse.Margin = new Padding(4, 0, 4, 0);
            lblCourse.Name = "lblCourse";
            lblCourse.Size = new Size(96, 15);
            lblCourse.TabIndex = 5;
            lblCourse.Text = "Название курса:";
            // 
            // txtCourse
            // 
            txtCourse.Location = new Point(140, 123);
            txtCourse.Margin = new Padding(4, 3, 4, 3);
            txtCourse.Name = "txtCourse";
            txtCourse.Size = new Size(291, 23);
            txtCourse.TabIndex = 6;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(14, 167);
            btnAdd.Margin = new Padding(4, 3, 4, 3);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(117, 35);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "Добавить";
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(140, 167);
            btnDelete.Margin = new Padding(4, 3, 4, 3);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(117, 35);
            btnDelete.TabIndex = 8;
            btnDelete.Text = "Удалить";
            // 
            // btnShowAll
            // 
            btnShowAll.Location = new Point(327, 167);
            btnShowAll.Margin = new Padding(4, 3, 4, 3);
            btnShowAll.Name = "btnShowAll";
            btnShowAll.Size = new Size(105, 35);
            btnShowAll.TabIndex = 9;
            btnShowAll.Text = "Показать всех";
            // 
            // lblSearch
            // 
            lblSearch.AutoSize = true;
            lblSearch.Location = new Point(14, 219);
            lblSearch.Margin = new Padding(4, 0, 4, 0);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(92, 15);
            lblSearch.TabIndex = 10;
            lblSearch.Text = "Поиск по ФИО:";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(140, 216);
            txtSearch.Margin = new Padding(4, 3, 4, 3);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(174, 23);
            txtSearch.TabIndex = 11;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(327, 213);
            btnSearch.Margin = new Padding(4, 3, 4, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(105, 29);
            btnSearch.TabIndex = 12;
            btnSearch.Text = "Найти";
            // 
            // lstStudents
            // 
            lstStudents.FormattingEnabled = true;
            lstStudents.Location = new Point(14, 260);
            lstStudents.Margin = new Padding(4, 3, 4, 3);
            lstStudents.Name = "lstStudents";
            lstStudents.Size = new Size(417, 139);
            lstStudents.TabIndex = 13;
            // 
            // grpCalculate
            // 
            grpCalculate.Controls.Add(lblLessons);
            grpCalculate.Controls.Add(txtLessons);
            grpCalculate.Controls.Add(lblPrice);
            grpCalculate.Controls.Add(txtPrice);
            grpCalculate.Controls.Add(btnCalculate);
            grpCalculate.Controls.Add(lblResult);
            grpCalculate.Location = new Point(14, 421);
            grpCalculate.Margin = new Padding(4, 3, 4, 3);
            grpCalculate.Name = "grpCalculate";
            grpCalculate.Padding = new Padding(4, 3, 4, 3);
            grpCalculate.Size = new Size(418, 162);
            grpCalculate.TabIndex = 14;
            grpCalculate.TabStop = false;
            grpCalculate.Text = "Расчёт стоимости обучения";
            // 
            // lblLessons
            // 
            lblLessons.AutoSize = true;
            lblLessons.Location = new Point(12, 29);
            lblLessons.Margin = new Padding(4, 0, 4, 0);
            lblLessons.Name = "lblLessons";
            lblLessons.Size = new Size(121, 15);
            lblLessons.TabIndex = 0;
            lblLessons.Text = "Количество занятий:";
            // 
            // txtLessons
            // 
            txtLessons.Location = new Point(175, 25);
            txtLessons.Margin = new Padding(4, 3, 4, 3);
            txtLessons.Name = "txtLessons";
            txtLessons.Size = new Size(93, 23);
            txtLessons.TabIndex = 1;
            // 
            // lblPrice
            // 
            lblPrice.AutoSize = true;
            lblPrice.Location = new Point(8, 63);
            lblPrice.Margin = new Padding(4, 0, 4, 0);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(157, 15);
            lblPrice.TabIndex = 2;
            lblPrice.Text = "Стоимость одного занятия:";
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(175, 60);
            txtPrice.Margin = new Padding(4, 3, 4, 3);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(93, 23);
            txtPrice.TabIndex = 3;
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(280, 23);
            btnCalculate.Margin = new Padding(4, 3, 4, 3);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(117, 63);
            btnCalculate.TabIndex = 4;
            btnCalculate.Text = "Рассчитать";
            btnCalculate.UseVisualStyleBackColor = true;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            lblResult.Location = new Point(12, 110);
            lblResult.Margin = new Padding(4, 0, 4, 0);
            lblResult.MaximumSize = new Size(385, 0);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(85, 15);
            lblResult.TabIndex = 5;
            lblResult.Text = "Результат: ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(448, 601);
            Controls.Add(lblTitle);
            Controls.Add(lblName);
            Controls.Add(txtName);
            Controls.Add(lblAge);
            Controls.Add(txtAge);
            Controls.Add(lblCourse);
            Controls.Add(txtCourse);
            Controls.Add(btnAdd);
            Controls.Add(btnDelete);
            Controls.Add(btnShowAll);
            Controls.Add(lblSearch);
            Controls.Add(txtSearch);
            Controls.Add(btnSearch);
            Controls.Add(lstStudents);
            Controls.Add(grpCalculate);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Художественная школа v0.2";
            grpCalculate.ResumeLayout(false);
            grpCalculate.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblCourse;
        private System.Windows.Forms.TextBox txtCourse;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ListBox lstStudents;

        // Новые элементы для ЛР №4
        private System.Windows.Forms.GroupBox grpCalculate;
        private System.Windows.Forms.Label lblLessons;
        private System.Windows.Forms.TextBox txtLessons;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblResult;
    }
}