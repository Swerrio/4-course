﻿using System.Linq;
using Microsoft.AspNetCore.Mvc;
using SquareMeter.Data;
using SquareMeter.Models;

namespace SquareMeter.Controllers
{
    // Регистрация, вход, личный кабинет и выход.
    // Все данные хранятся в памяти (DemoUsers), база данных не используется.
    public class AccountController : Controller
    {
        // ====== РЕГИСТРАЦИЯ ======
        public IActionResult Register()
        {
            // Если пользователь уже вошёл — незачем регистрироваться заново
            if (DemoUsers.GetCurrentUsername(HttpContext) != null)
                return RedirectToAction("Profile");

            return View(new RegisterViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel model)
        {
            // 1. Проверка пустых полей
            if (string.IsNullOrWhiteSpace(model.Username))
                model.Error = "Введите логин.";
            else if (string.IsNullOrWhiteSpace(model.Email))
                model.Error = "Введите e-mail.";
            else if (!model.Email.Contains("@") || !model.Email.Contains("."))
                model.Error = "Некорректный формат e-mail.";
            else if (string.IsNullOrWhiteSpace(model.Password))
                model.Error = "Введите пароль.";
            else if (model.Password != model.ConfirmPassword)
                model.Error = "Пароли не совпадают.";
            else if (model.Password.Length < 4)
                model.Error = "Пароль должен содержать не менее 4 символов.";

            if (model.Error != null)
                return View(model);

            // 2. Попытка регистрации (проверка уникальности внутри DemoUsers)
            string error = DemoUsers.Register(model.Username, model.Email, model.Password);
            if (error != null)
            {
                model.Error = error;
                return View(model);
            }

            // 3. Успех: автоматически входим и ведём в профиль
            DemoUsers.SignIn(HttpContext, model.Username.Trim());
            return RedirectToAction("Profile");
        }

        // ====== ВХОД ======
        public IActionResult Login(string returnUrl)
        {
            if (DemoUsers.GetCurrentUsername(HttpContext) != null)
                return RedirectToAction("Profile");

            return View(new LoginViewModel { ReturnUrl = returnUrl });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (string.IsNullOrWhiteSpace(model.Username) ||
                string.IsNullOrWhiteSpace(model.Password))
            {
                model.Error = "Введите логин и пароль.";
                return View(model);
            }

            string error = DemoUsers.Login(model.Username, model.Password);
            if (error != null)
            {
                model.Error = error;
                return View(model);
            }

            DemoUsers.SignIn(HttpContext, model.Username.Trim());

            // Если пользователь пришёл со страницы объекта — вернём его туда
            if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
                return Redirect(model.ReturnUrl);

            return RedirectToAction("Profile");
        }

        // ====== ЛИЧНЫЙ КАБИНЕТ ======
        public IActionResult Profile()
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null)
                return RedirectToAction("Login");

            UserProfile profile = DemoUsers.GetCurrentProfile(HttpContext);

            ProfileViewModel model = new ProfileViewModel
            {
                Account = account,
                Profile = profile,
                IsCompleted = profile.IsCompleted(account),
                FavoriteItems = profile.Favorites
                    .Select(id => DemoCatalog.Find(id))
                    .Where(p => p != null)
                    .ToList()
            };
            return View(model);
        }

        // Сохранение изменений профиля
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Profile(string fullName, string phone)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null)
                return RedirectToAction("Login");

            DemoUsers.UpdateProfile(account.Username, fullName, phone);

            // Небольшой трюк: передаём сообщение об успехе через TempData
            TempData["Success"] = "Изменения сохранены.";
            return RedirectToAction("Profile");
        }

        // ====== ДОБАВЛЕНИЕ В ИЗБРАННОЕ (привилегия) ======
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddToFavorite(int id, string returnUrl)
        {
            UserProfile profile = DemoUsers.GetCurrentProfile(HttpContext);
            if (profile == null)
                return RedirectToAction("Login", new { returnUrl = returnUrl ?? "/Catalog" });

            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (!profile.IsCompleted(account))
            {
                TempData["Warning"] = "Заполните профиль, чтобы добавлять объекты в избранное.";
                return RedirectToAction("Profile");
            }

            DemoUsers.AddToFavorites(account.Username, id); // Используем новый метод
            return Redirect(returnUrl ?? Url.Action("Details", "Catalog", new { id }));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RemoveFromFavorite(int id)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null)
                return RedirectToAction("Login");

            DemoUsers.RemoveFromFavorites(account.Username, id); // Используем новый метод
            return RedirectToAction("Profile");
        }

        // ====== ВЫХОД ======
        public IActionResult Logout()
        {
            DemoUsers.SignOut(HttpContext);
            return RedirectToAction("Index", "Home");
        }

        // ===== РАЗДЕЛ "МОИ ДЕЙСТВИЯ" =====
        public IActionResult Actions()
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null)
                return RedirectToAction("Login");

            UserProfile profile = DemoUsers.GetCurrentProfile(HttpContext);

            // ВАЖНО: передаём данные в ViewBag, чтобы представление могло их прочитать
            ViewBag.Account = account;
            ViewBag.Profile = profile;
            ViewBag.IsCompleted = profile.IsCompleted(account);

            UserActionsViewModel model = new UserActionsViewModel
            {
                Username = account.Username,
                Requests = UserActions.GetUserRequests(account.Username),
                FavoriteItems = profile.Favorites
                    .Select(id => DemoCatalog.Find(id))
                    .Where(p => p != null)
                    .ToList(),
                ComparisonItems = UserActions.GetComparisonItems(account.Username),
                Notes = UserActions.GetUserNotes(account.Username),
                NoteProperties = UserActions.GetUserNotes(account.Username)
                    .Select(n => DemoCatalog.Find(n.PropertyId))
                    .Where(p => p != null)
                    .ToList()
            };
            return View("UserActions", model);
        }
    }
}