﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using SquareMeter.Data;
using SquareMeter.Models;

namespace SquareMeter.Controllers
{
    // Действия пользователя: заявки на просмотр, сравнение, заметки.
    public class RequestController : Controller
    {
        // ===== ЗАЯВКА НА ПРОСМОТР =====
        public IActionResult Create(int id)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null)
                return RedirectToAction("Login", "Account", new { returnUrl = Url.Action("Create", new { id }) });

            Property property = DemoCatalog.Find(id);
            if (property == null) return NotFound();

            CreateRequestViewModel model = new CreateRequestViewModel
            {
                PropertyId = id,
                PropertyTitle = property.Title,
                RequestDate = DateTime.Today.AddDays(1),
                RequestTime = "14:00"
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CreateRequestViewModel model)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null) return RedirectToAction("Login", "Account");

            // Валидация
            if (DemoCatalog.Find(model.PropertyId) == null)
                model.Error = "Объект не найден.";
            else if (model.RequestDate.Date < DateTime.Today)
                model.Error = "Дата просмотра не может быть в прошлом.";
            else if (string.IsNullOrWhiteSpace(model.RequestTime))
                model.Error = "Укажите время просмотра.";

            if (model.Error != null)
            {
                model.PropertyTitle = DemoCatalog.Find(model.PropertyId)?.Title;
                return View(model);
            }

            string error = UserActions.CreateRequest(
                account.Username, model.PropertyId,
                model.RequestDate, model.RequestTime, model.Comment);

            if (error != null)
            {
                model.Error = error;
                model.PropertyTitle = DemoCatalog.Find(model.PropertyId)?.Title;
                return View(model);
            }

            TempData["Success"] = $"Заявка № {UserActions.GetUserRequests(account.Username).First().Id} успешно создана. Мы свяжемся с вами для подтверждения.";
            return RedirectToAction("Actions", "Account");
        }

        // ===== ОТМЕНА ЗАЯВКИ =====
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CancelRequest(int id)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null) return RedirectToAction("Login", "Account");

            string error = UserActions.CancelRequest(account.Username, id);
            if (error != null)
                TempData["Warning"] = error;
            else
                TempData["Success"] = "Заявка отменена.";

            return RedirectToAction("Actions", "Account");
        }

        // ===== СРАВНЕНИЕ =====
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddToComparison(int id, string returnUrl)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null)
                return RedirectToAction("Login", "Account", new { returnUrl = returnUrl ?? "/Catalog" });

            string error = UserActions.AddToComparison(account.Username, id);
            if (error != null)
                TempData["Warning"] = error;
            else
                TempData["Success"] = "Объект добавлен в сравнение.";

            return Redirect(returnUrl ?? Url.Action("Details", "Catalog", new { id }));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RemoveFromComparison(int id)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null) return RedirectToAction("Login", "Account");

            UserActions.RemoveFromComparison(account.Username, id);
            return RedirectToAction("Actions", "Account");
        }

        public IActionResult Comparison()
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null) return RedirectToAction("Login", "Account");

            return View(UserActions.GetComparisonItems(account.Username));
        }

        // ===== ОТКРЫТИЕ ФОРМЫ ЗАМЕТКИ (GET) =====
        public IActionResult AddNote(int propertyId)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null)
                return RedirectToAction("Login", "Account", new { returnUrl = Url.Action("AddNote", new { propertyId }) });

            Property property = DemoCatalog.Find(propertyId);
            if (property == null) return NotFound();

            UserProfile profile = DemoUsers.GetCurrentProfile(HttpContext);
            if (profile == null || !profile.IsCompleted(account))
            {
                TempData["Warning"] = "Заполните профиль, чтобы добавлять заметки.";
                return RedirectToAction("Profile", "Account");
            }

            PropertyNote existingNote = UserActions.GetNote(account.Username, propertyId);
            ViewBag.Property = property;
            ViewBag.NoteText = existingNote?.Text ?? "";
            return View(); // Ищет файл Views/Request/AddNote.cshtml
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveNote(int propertyId, string noteText, string returnUrl)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null) return RedirectToAction("Login", "Account");

            string error = UserActions.SaveNote(account.Username, propertyId, noteText);
            if (error != null)
                TempData["Warning"] = error;
            else
                TempData["Success"] = "Заметка сохранена.";

            return Redirect(returnUrl ?? Url.Action("Details", "Catalog", new { id = propertyId }));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteNote(int propertyId)
        {
            UserAccount account = DemoUsers.GetCurrentUser(HttpContext);
            if (account == null) return RedirectToAction("Login", "Account");

            UserActions.DeleteNote(account.Username, propertyId);
            return RedirectToAction("Actions", "Account");
        }
    }
}