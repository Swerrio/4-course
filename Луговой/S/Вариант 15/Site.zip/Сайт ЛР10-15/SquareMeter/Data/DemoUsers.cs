﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using SquareMeter.Models;

namespace SquareMeter.Data
{
    public static class DemoUsers
    {
        private const string SessionKey = "CurrentUser";
        private const string DataFile = "users.json";

        private static readonly List<UserAccount> accounts = new List<UserAccount>();
        private static readonly Dictionary<string, UserProfile> profiles =
            new Dictionary<string, UserProfile>(StringComparer.OrdinalIgnoreCase);

        private static readonly object fileLock = new object();

        public static string SessionKeyUser => SessionKey;

        // Статический конструктор: загружает данные из файла при старте
        static DemoUsers()
        {
            LoadFromFile();
        }

        // Загрузка данных из JSON-файла
        private static void LoadFromFile()
        {
            if (!File.Exists(DataFile)) return;

            try
            {
                string json = File.ReadAllText(DataFile);
                var data = JsonSerializer.Deserialize<UserData>(json);
                if (data != null)
                {
                    accounts.Clear();
                    profiles.Clear();

                    if (data.Accounts != null)
                        accounts.AddRange(data.Accounts);

                    if (data.Profiles != null)
                    {
                        foreach (var kvp in data.Profiles)
                        {
                            profiles[kvp.Key] = kvp.Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка загрузки {DataFile}: {ex.Message}");
            }
        }

        // Сохранение данных в JSON-файл
        private static void SaveToFile()
        {
            lock (fileLock)
            {
                try
                {
                    var data = new UserData
                    {
                        Accounts = accounts,
                        Profiles = profiles
                    };

                    var options = new JsonSerializerOptions
                    {
                        WriteIndented = true
                    };

                    string json = JsonSerializer.Serialize(data, options);
                    File.WriteAllText(DataFile, json);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Ошибка сохранения {DataFile}: {ex.Message}");
                }
            }
        }

        // Вспомогательный класс для сериализации
        private class UserData
        {
            public List<UserAccount> Accounts { get; set; }
            public Dictionary<string, UserProfile> Profiles { get; set; }
        }

        // Регистрация
        public static string Register(string username, string email, string password)
        {
            if (string.IsNullOrWhiteSpace(username))
                return "Введите логин.";
            if (string.IsNullOrWhiteSpace(email))
                return "Введите e-mail.";
            if (string.IsNullOrWhiteSpace(password))
                return "Введите пароль.";

            username = username.Trim();
            email = email.Trim().ToLowerInvariant();

            if (accounts.Any(a =>
                string.Equals(a.Username, username, StringComparison.OrdinalIgnoreCase)))
                return "Пользователь с таким логином уже существует.";

            if (accounts.Any(a =>
                string.Equals(a.Email, email, StringComparison.OrdinalIgnoreCase)))
                return "Этот e-mail уже зарегистрирован.";

            UserAccount acc = new UserAccount
            {
                Username = username,
                Email = email,
                PasswordHash = UserAccount.HashPassword(password)
            };
            accounts.Add(acc);

            profiles[username] = new UserProfile
            {
                Username = username,
                RegisteredAt = DateTime.Now
            };

            SaveToFile(); // Сохраняем после регистрации
            return null;
        }

        // Вход
        public static string Login(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password))
                return "Введите логин и пароль.";

            UserAccount acc = accounts.FirstOrDefault(a =>
                string.Equals(a.Username, username.Trim(),
                    StringComparison.OrdinalIgnoreCase));
            if (acc == null) return "Неверный логин или пароль.";
            if (!acc.CheckPassword(password)) return "Неверный логин или пароль.";

            return null;
        }

        public static UserAccount GetAccount(string username)
        {
            if (string.IsNullOrWhiteSpace(username)) return null;
            return accounts.FirstOrDefault(a =>
                string.Equals(a.Username, username, StringComparison.OrdinalIgnoreCase));
        }

        public static UserProfile GetProfile(string username)
        {
            if (string.IsNullOrWhiteSpace(username)) return null;
            profiles.TryGetValue(username, out UserProfile profile);
            return profile;
        }

        // Обновление профиля
        public static void UpdateProfile(string username, string fullName, string phone)
        {
            UserProfile p = GetProfile(username);
            if (p == null) return;
            p.FullName = fullName?.Trim();
            p.Phone = phone?.Trim();

            SaveToFile(); // Сохраняем после обновления
        }

        // Добавление в избранное
        public static void AddToFavorites(string username, int propertyId)
        {
            UserProfile p = GetProfile(username);
            if (p == null) return;
            p.AddFavorite(propertyId);

            SaveToFile(); // Сохраняем после изменения избранного
        }

        // Удаление из избранного
        public static void RemoveFromFavorites(string username, int propertyId)
        {
            UserProfile p = GetProfile(username);
            if (p == null) return;
            p.RemoveFavorite(propertyId);

            SaveToFile(); // Сохраняем после изменения избранного
        }

        // Работа с сессией
        public static void SignIn(HttpContext context, string username)
        {
            context.Session.SetString(SessionKeyUser, username);
        }

        public static void SignOut(HttpContext context)
        {
            context.Session.Remove(SessionKeyUser);
        }

        public static string GetCurrentUsername(HttpContext context)
        {
            return context.Session.GetString(SessionKeyUser);
        }

        public static UserAccount GetCurrentUser(HttpContext context)
        {
            return GetAccount(GetCurrentUsername(context));
        }

        public static UserProfile GetCurrentProfile(HttpContext context)
        {
            return GetProfile(GetCurrentUsername(context));
        }
    }
}