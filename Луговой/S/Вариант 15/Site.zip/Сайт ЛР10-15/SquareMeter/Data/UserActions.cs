﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using SquareMeter.Models;

namespace SquareMeter.Data
{
    // Хранилище заявок на просмотр, списков сравнения и заметок.
    // Все данные сохраняются в JSON-файле userActions.json.
    public static class UserActions
    {
        private const string DataFile = "userActions.json";
        private static readonly object fileLock = new object();

        private static List<ViewingRequest> requests = new List<ViewingRequest>();
        private static Dictionary<string, ComparisonList> comparisons =
            new Dictionary<string, ComparisonList>(StringComparer.OrdinalIgnoreCase);
        private static Dictionary<string, List<PropertyNote>> notes =
            new Dictionary<string, List<PropertyNote>>(StringComparer.OrdinalIgnoreCase);

        // Загрузка данных при старте приложения
        static UserActions()
        {
            LoadFromFile();
        }

        // ===== ЗАГРУЗКА / СОХРАНЕНИЕ =====
        private static void LoadFromFile()
        {
            if (!File.Exists(DataFile)) return;
            try
            {
                string json = File.ReadAllText(DataFile);
                var data = JsonSerializer.Deserialize<ActionsData>(json);
                if (data == null) return;

                if (data.Requests != null) requests = data.Requests;
                if (data.Comparisons != null) comparisons = data.Comparisons;
                if (data.Notes != null) notes = data.Notes;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка загрузки {DataFile}: {ex.Message}");
            }
        }

        private static void SaveToFile()
        {
            lock (fileLock)
            {
                try
                {
                    var data = new ActionsData
                    {
                        Requests = requests,
                        Comparisons = comparisons,
                        Notes = notes
                    };
                    var options = new JsonSerializerOptions { WriteIndented = true };
                    File.WriteAllText(DataFile, JsonSerializer.Serialize(data, options));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Ошибка сохранения {DataFile}: {ex.Message}");
                }
            }
        }

        private class ActionsData
        {
            public List<ViewingRequest> Requests { get; set; }
            public Dictionary<string, ComparisonList> Comparisons { get; set; }
            public Dictionary<string, List<PropertyNote>> Notes { get; set; }
        }

        // ===== ЗАЯВКИ НА ПРОСМОТР =====
        public static string CreateRequest(string username, int propertyId,
            DateTime requestDate, string requestTime, string comment)
        {
            if (string.IsNullOrWhiteSpace(username))
                return "Необходима авторизация.";
            if (DemoCatalog.Find(propertyId) == null)
                return "Объект не найден.";
            if (requestDate.Date < DateTime.Today)
                return "Дата просмотра не может быть в прошлом.";
            if (string.IsNullOrWhiteSpace(requestTime))
                return "Укажите время просмотра.";

            // Защита от повторной заявки на тот же объект с тем же статусом
            bool alreadyExists = requests.Any(r =>
                string.Equals(r.Username, username, StringComparison.OrdinalIgnoreCase) &&
                r.PropertyId == propertyId &&
                r.Status != "Отменена");
            if (alreadyExists)
                return "У вас уже есть активная заявка на этот объект.";

            int newId = requests.Count == 0 ? 1 : requests.Max(r => r.Id) + 1;

            requests.Add(new ViewingRequest
            {
                Id = newId,
                Username = username,
                PropertyId = propertyId,
                RequestDate = requestDate,
                RequestTime = requestTime,
                Comment = comment?.Trim(),
                CreatedAt = DateTime.Now,
                Status = "Новая"
            });

            SaveToFile();
            return null;
        }

        public static IList<ViewingRequest> GetUserRequests(string username)
        {
            if (string.IsNullOrWhiteSpace(username)) return new List<ViewingRequest>();
            return requests
                .Where(r => string.Equals(r.Username, username, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(r => r.CreatedAt)
                .ToList();
        }

        public static string CancelRequest(string username, int requestId)
        {
            ViewingRequest req = requests.FirstOrDefault(r => r.Id == requestId);
            if (req == null) return "Заявка не найдена.";
            if (!string.Equals(req.Username, username, StringComparison.OrdinalIgnoreCase))
                return "Это чужая заявка.";
            if (req.Status == "Отменена") return "Заявка уже отменена.";

            req.Status = "Отменена";
            SaveToFile();
            return null;
        }

        // ===== СРАВНЕНИЕ ОБЪЕКТОВ =====
        public static ComparisonList GetComparison(string username)
        {
            if (string.IsNullOrWhiteSpace(username)) return new ComparisonList();
            if (!comparisons.TryGetValue(username, out ComparisonList list))
            {
                list = new ComparisonList { Username = username };
                comparisons[username] = list;
            }
            return list;
        }

        public static string AddToComparison(string username, int propertyId)
        {
            if (DemoCatalog.Find(propertyId) == null) return "Объект не найден.";
            ComparisonList list = GetComparison(username);
            if (!list.CanAdd) return "В списке сравнения уже 3 объекта. Удалите один, чтобы добавить другой.";
            list.Add(propertyId);
            SaveToFile();
            return null;
        }

        public static void RemoveFromComparison(string username, int propertyId)
        {
            ComparisonList list = GetComparison(username);
            list.Remove(propertyId);
            SaveToFile();
        }

        public static IList<Property> GetComparisonItems(string username)
        {
            return GetComparison(username).PropertyIds
                .Select(id => DemoCatalog.Find(id))
                .Where(p => p != null)
                .ToList();
        }

        // ===== ЗАМЕТКИ =====
        public static IList<PropertyNote> GetUserNotes(string username)
        {
            if (string.IsNullOrWhiteSpace(username)) return new List<PropertyNote>();
            if (!notes.TryGetValue(username, out List<PropertyNote> list))
                return new List<PropertyNote>();
            return list.OrderByDescending(n => n.UpdatedAt).ToList();
        }

        public static string SaveNote(string username, int propertyId, string text)
        {
            if (DemoCatalog.Find(propertyId) == null) return "Объект не найден.";
            if (string.IsNullOrWhiteSpace(text)) return "Введите текст заметки.";

            if (!notes.TryGetValue(username, out List<PropertyNote> list))
            {
                list = new List<PropertyNote>();
                notes[username] = list;
            }

            PropertyNote existing = list.FirstOrDefault(n => n.PropertyId == propertyId);
            if (existing != null)
            {
                existing.Text = text.Trim();
                existing.UpdatedAt = DateTime.Now;
            }
            else
            {
                list.Add(new PropertyNote
                {
                    Username = username,
                    PropertyId = propertyId,
                    Text = text.Trim(),
                    UpdatedAt = DateTime.Now
                });
            }

            SaveToFile();
            return null;
        }

        public static void DeleteNote(string username, int propertyId)
        {
            if (!notes.TryGetValue(username, out List<PropertyNote> list)) return;
            list.RemoveAll(n => n.PropertyId == propertyId);
            SaveToFile();
        }

        public static PropertyNote GetNote(string username, int propertyId)
        {
            if (!notes.TryGetValue(username, out List<PropertyNote> list)) return null;
            return list.FirstOrDefault(n => n.PropertyId == propertyId);
        }
    }
}