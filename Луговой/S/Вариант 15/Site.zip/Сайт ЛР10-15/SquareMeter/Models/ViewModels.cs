using System;
using System.Collections.Generic;

namespace SquareMeter.Models
{
    // Данные главной страницы, которые контроллер передаёт в представление
    public class HomeViewModel
    {
        public IList<Advantage> Advantages { get; set; }
        public IList<Category> Categories { get; set; }
        public IList<Property> Featured { get; set; }
        public int TotalCount { get; set; }
        public int CityCount { get; set; }
    }

    // Данные страницы каталога
    public class CatalogViewModel
    {
        public IList<Property> Items { get; set; }
        public IList<Category> Categories { get; set; }
        public string SelectedKey { get; set; }
        public string SelectedTitle { get; set; }
    }

    // Страница одного объекта и похожие предложения
    public class PropertyViewModel
    {
        public Property Item { get; set; }
        public Category Category { get; set; }
        public IList<Property> Similar { get; set; }
    }

    // Страница ошибки и страница «не найдено»
    public class StatusViewModel
    {
        public int Code { get; set; }
        public string Title { get; set; }
        public string Message { get; set; }
        public string RequestId { get; set; }
    }

    // Форма регистрации
    public class RegisterViewModel
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string Error { get; set; }
    }

    // Форма входа
    public class LoginViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Error { get; set; }
        public string ReturnUrl { get; set; }
    }

    // Страница личного кабинета
    public class ProfileViewModel
    {
        public UserAccount Account { get; set; }
        public UserProfile Profile { get; set; }
        public bool IsCompleted { get; set; }
        public string SuccessMessage { get; set; }
        public IList<Property> FavoriteItems { get; set; }
    }

    // Форма создания заявки на просмотр
    public class CreateRequestViewModel
    {
        public int PropertyId { get; set; }
        public string PropertyTitle { get; set; }
        public DateTime RequestDate { get; set; }
        public string RequestTime { get; set; }
        public string Comment { get; set; }
        public string Error { get; set; }
    }

    // Раздел "Мои действия" в личном кабинете
    public class UserActionsViewModel
    {
        public string Username { get; set; }
        public IList<ViewingRequest> Requests { get; set; }
        public IList<Property> FavoriteItems { get; set; }
        public IList<Property> ComparisonItems { get; set; }
        public IList<PropertyNote> Notes { get; set; }
        public IList<Property> NoteProperties { get; set; }
    }
}
