﻿using System;
using System.Collections.Generic;

namespace SquareMeter.Models
{
    // Персональные данные пользователя и его привилегии.
    // Для сайта недвижимости привилегия — сохранение объектов в «Избранное».
    public class UserProfile
    {
        public string Username { get; set; }   // связка с UserAccount
        public string FullName { get; set; }   // ФИО или имя
        public string Phone { get; set; }      // телефон
        public DateTime RegisteredAt { get; set; } = DateTime.Now;

        // Список ID объектов, добавленных в избранное
        public List<int> Favorites { get; set; } = new List<int>();

        // Профиль считается заполненным, когда указаны имя, e-mail и телефон.
        // e-mail берём из учётной записи, поэтому здесь проверяем только
        // FullName и Phone. Метод вызывается с передачей аккаунта.
        public bool IsCompleted(UserAccount account)
        {
            return account != null
                && !string.IsNullOrWhiteSpace(account.Email)
                && !string.IsNullOrWhiteSpace(FullName)
                && !string.IsNullOrWhiteSpace(Phone);
        }

        // Добавляет объект в избранное, если его там ещё нет
        public void AddFavorite(int propertyId)
        {
            if (!Favorites.Contains(propertyId))
                Favorites.Add(propertyId);
        }

        // Убирает объект из избранного
        public void RemoveFavorite(int propertyId)
        {
            Favorites.Remove(propertyId);
        }

        public bool IsFavorite(int propertyId)
        {
            return Favorites.Contains(propertyId);
        }
    }
}