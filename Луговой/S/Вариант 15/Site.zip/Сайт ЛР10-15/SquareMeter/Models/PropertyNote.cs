﻿using System;

namespace SquareMeter.Models
{
    // Заметка пользователя к объекту недвижимости
    public class PropertyNote
    {
        public string Username { get; set; }
        public int PropertyId { get; set; }
        public string Text { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}