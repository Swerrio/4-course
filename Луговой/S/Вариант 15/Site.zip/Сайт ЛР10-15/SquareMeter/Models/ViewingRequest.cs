﻿using System;

namespace SquareMeter.Models
{
    // Заявка на просмотр объекта недвижимости
    public class ViewingRequest
    {
        public int Id { get; set; }                    // уникальный номер заявки
        public string Username { get; set; }           // кто создал
        public int PropertyId { get; set; }            // ID объекта
        public DateTime RequestDate { get; set; }      // желаемая дата просмотра
        public string RequestTime { get; set; }        // желаемое время (например, "14:00")
        public string Comment { get; set; }            // комментарий пользователя
        public DateTime CreatedAt { get; set; }        // когда создана заявка
        public string Status { get; set; }             // "Новая", "Подтверждена", "Отменена"
    }
}