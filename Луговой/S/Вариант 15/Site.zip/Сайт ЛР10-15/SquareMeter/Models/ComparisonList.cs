﻿using System.Collections.Generic;

namespace SquareMeter.Models
{
    // Список объектов для сравнения (максимум 3)
    public class ComparisonList
    {
        public string Username { get; set; }
        public List<int> PropertyIds { get; set; } = new List<int>();

        public bool CanAdd => PropertyIds.Count < 3;

        public void Add(int propertyId)
        {
            if (!PropertyIds.Contains(propertyId) && CanAdd)
                PropertyIds.Add(propertyId);
        }

        public void Remove(int propertyId)
        {
            PropertyIds.Remove(propertyId);
        }

        public bool Contains(int propertyId)
        {
            return PropertyIds.Contains(propertyId);
        }
    }
}