using System;
using System.Security.Cryptography;
using System.Text;

namespace SquareMeter.Models
{
    // Учётная запись пользователя: данные для входа.
    // Пароль хранится только в виде хеша SHA-256.
    public class UserAccount
    {
        public string Username { get; set; }   // логин (уникальный)
        public string Email { get; set; }      // e-mail (уникальный)
        public string PasswordHash { get; set; } // хеш пароля

        // Преобразует пароль в хеш SHA-256 (строка в верхнем регистре)
        public static string HashPassword(string password)
        {
            if (string.IsNullOrEmpty(password)) return "";
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                    sb.Append(bytes[i].ToString("X2"));
                return sb.ToString();
            }
        }

        // Проверяет, совпадает ли введённый пароль с сохранённым хешем
        public bool CheckPassword(string password)
        {
            return string.Equals(PasswordHash, HashPassword(password),
                StringComparison.Ordinal);
        }
    }
}