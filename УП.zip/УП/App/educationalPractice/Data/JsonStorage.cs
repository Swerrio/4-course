﻿using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;

namespace educationalPractice.Data
{

    public static class JsonStorage
    {
        private static readonly JavaScriptSerializer Serializer = new JavaScriptSerializer();

        public static void Save<T>(string path, List<T> items)
        {
            string json = Serializer.Serialize(items);
            json = PrettyPrint(json);
            File.WriteAllText(path, json, new UTF8Encoding(true));
        }

        public static List<T> Load<T>(string path)
        {
            if (!File.Exists(path))
                return new List<T>();

            string json = File.ReadAllText(path, Encoding.UTF8);
            if (string.IsNullOrWhiteSpace(json))
                return new List<T>();

            return Serializer.Deserialize<List<T>>(json);
        }

        private static string PrettyPrint(string json)
        {
            var sb = new StringBuilder();
            int indent = 0;
            bool inQuotes = false;

            for (int i = 0; i < json.Length; i++)
            {
                char c = json[i];

                if (c == '"' && (i == 0 || json[i - 1] != '\\'))
                    inQuotes = !inQuotes;

                if (inQuotes)
                {
                    sb.Append(c);
                    continue;
                }

                switch (c)
                {
                    case '{':
                    case '[':
                        sb.Append(c);
                        sb.Append('\n');
                        indent++;
                        AppendIndent(sb, indent);
                        break;
                    case '}':
                    case ']':
                        sb.Append('\n');
                        indent--;
                        AppendIndent(sb, indent);
                        sb.Append(c);
                        break;
                    case ',':
                        sb.Append(c);
                        sb.Append('\n');
                        AppendIndent(sb, indent);
                        break;
                    case ':':
                        sb.Append(": ");
                        break;
                    default:
                        sb.Append(c);
                        break;
                }
            }

            return sb.ToString();
        }

        private static void AppendIndent(StringBuilder sb, int indent)
        {
            for (int i = 0; i < indent; i++)
                sb.Append("  ");
        }
    }
}
