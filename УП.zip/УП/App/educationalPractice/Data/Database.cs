﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using educationalPractice.Models;

namespace educationalPractice.Data
{

    public static class Database
    {

        public static readonly string DataDir =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");

        private static readonly string UsersPath = Path.Combine(DataDir, "users.json");
        private static readonly string DepartmentsPath = Path.Combine(DataDir, "departments.json");
        private static readonly string DocumentTypesPath = Path.Combine(DataDir, "document_types.json");
        private static readonly string ExecutorsPath = Path.Combine(DataDir, "executors.json");
        private static readonly string DocumentsPath = Path.Combine(DataDir, "documents.json");

        public static List<User> Users { get; private set; }
        public static List<Department> Departments { get; private set; }
        public static List<DocumentType> DocumentTypes { get; private set; }
        public static List<Executor> Executors { get; private set; }
        public static List<Document> Documents { get; private set; }

        public static void Load()
        {
            if (!Directory.Exists(DataDir))
                Directory.CreateDirectory(DataDir);

            Users = JsonStorage.Load<User>(UsersPath);
            Departments = JsonStorage.Load<Department>(DepartmentsPath);
            DocumentTypes = JsonStorage.Load<DocumentType>(DocumentTypesPath);
            Executors = JsonStorage.Load<Executor>(ExecutorsPath);
            Documents = JsonStorage.Load<Document>(DocumentsPath);

            SeedIfEmpty();
        }

        public static void SaveUsers() { JsonStorage.Save(UsersPath, Users); }
        public static void SaveDepartments() { JsonStorage.Save(DepartmentsPath, Departments); }
        public static void SaveDocumentTypes() { JsonStorage.Save(DocumentTypesPath, DocumentTypes); }
        public static void SaveExecutors() { JsonStorage.Save(ExecutorsPath, Executors); }
        public static void SaveDocuments() { JsonStorage.Save(DocumentsPath, Documents); }

        public static int NextUserId() { return Users.Count == 0 ? 1 : Users.Max(x => x.Id) + 1; }
        public static int NextDepartmentId() { return Departments.Count == 0 ? 1 : Departments.Max(x => x.Id) + 1; }
        public static int NextDocumentTypeId() { return DocumentTypes.Count == 0 ? 1 : DocumentTypes.Max(x => x.Id) + 1; }
        public static int NextExecutorId() { return Executors.Count == 0 ? 1 : Executors.Max(x => x.Id) + 1; }
        public static int NextDocumentId() { return Documents.Count == 0 ? 1 : Documents.Max(x => x.Id) + 1; }

        public static string DepartmentName(int id)
        {
            var d = Departments.FirstOrDefault(x => x.Id == id);
            return d != null ? d.Name : "";
        }

        public static string DocumentTypeName(int id)
        {
            var t = DocumentTypes.FirstOrDefault(x => x.Id == id);
            return t != null ? t.Name : "";
        }

        public static string ExecutorName(int id)
        {
            var e = Executors.FirstOrDefault(x => x.Id == id);
            return e != null ? e.FullName : "";
        }

        public static User Authenticate(string login, string password)
        {
            return Users.FirstOrDefault(u =>
                string.Equals(u.Login, login, StringComparison.OrdinalIgnoreCase) &&
                u.Password == password);
        }

        private static void SeedIfEmpty()
        {
            if (Users.Count == 0)
            {
                Users.Add(new User
                {
                    Id = 1,
                    Login = "admin",
                    Password = "admin",
                    FullName = "Администратор",
                    Role = "Администратор"
                });
                SaveUsers();
            }

            if (Departments.Count == 0)
            {
                Departments.Add(new Department { Id = 1, Name = "Канцелярия", Head = "Иванова И.И.", Phone = "101" });
                Departments.Add(new Department { Id = 2, Name = "Бухгалтерия", Head = "Петрова П.П.", Phone = "102" });
                Departments.Add(new Department { Id = 3, Name = "Отдел кадров", Head = "Сидоров С.С.", Phone = "103" });
                SaveDepartments();
            }

            if (DocumentTypes.Count == 0)
            {
                DocumentTypes.Add(new DocumentType { Id = 1, Name = "Приказ", Description = "Распорядительный документ" });
                DocumentTypes.Add(new DocumentType { Id = 2, Name = "Письмо", Description = "Деловая переписка" });
                DocumentTypes.Add(new DocumentType { Id = 3, Name = "Договор", Description = "Соглашение сторон" });
                DocumentTypes.Add(new DocumentType { Id = 4, Name = "Служебная записка", Description = "Внутренний документ" });
                SaveDocumentTypes();
            }

            if (Executors.Count == 0)
            {
                Executors.Add(new Executor { Id = 1, FullName = "Иванова Ирина Ивановна", Position = "Секретарь", DepartmentId = 1, Phone = "101" });
                Executors.Add(new Executor { Id = 2, FullName = "Петрова Полина Петровна", Position = "Бухгалтер", DepartmentId = 2, Phone = "102" });
                Executors.Add(new Executor { Id = 3, FullName = "Сидоров Семён Семёнович", Position = "Инспектор по кадрам", DepartmentId = 3, Phone = "103" });
                SaveExecutors();
            }

            if (Documents.Count == 0)
            {
                Documents.Add(new Document
                {
                    Id = 1,
                    RegNumber = "01-15/001",
                    Title = "О приёме на работу",
                    DocumentTypeId = 1,
                    ExecutorId = 3,
                    DepartmentId = 3,
                    RegDate = DateTime.Today.ToString("dd.MM.yyyy"),
                    Status = "Исполнен",
                    Content = "Приказ о приёме сотрудника на должность."
                });
                SaveDocuments();
            }
        }
    }
}
