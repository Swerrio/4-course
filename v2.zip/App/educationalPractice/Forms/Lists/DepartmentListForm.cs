﻿using System;
using System.Linq;
using System.Windows.Forms;
using educationalPractice.Data;
using educationalPractice.Forms.Edit;
using educationalPractice.Models;

namespace educationalPractice.Forms.Lists
{

    public partial class DepartmentListForm : Form
    {
        public DepartmentListForm()
        {
            InitializeComponent();
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            string filter = txtSearch.Text.Trim().ToLower();

            var rows = Database.Departments
                .Where(d => string.IsNullOrEmpty(filter)
                            || d.Name.ToLower().Contains(filter)
                            || (d.Head ?? "").ToLower().Contains(filter))
                .Select(d => new { d.Id, Название = d.Name, Руководитель = d.Head, Телефон = d.Phone })
                .ToList();

            grid.DataSource = rows;
            if (grid.Columns.Contains("Id"))
                grid.Columns["Id"].Visible = false;
        }

        private Department GetSelected()
        {
            if (grid.CurrentRow == null) return null;
            int id = (int)grid.CurrentRow.Cells["Id"].Value;
            return Database.Departments.FirstOrDefault(d => d.Id == id);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshGrid();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var item = new Department();
            using (var form = new DepartmentEditForm(item, true))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    item.Id = Database.NextDepartmentId();
                    Database.Departments.Add(item);
                    Database.SaveDepartments();
                    RefreshGrid();
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для редактирования.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var form = new DepartmentEditForm(item, false))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    Database.SaveDepartments();
                    RefreshGrid();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (Database.Executors.Any(x => x.DepartmentId == item.Id) ||
                Database.Documents.Any(x => x.DepartmentId == item.Id))
            {
                MessageBox.Show("Нельзя удалить департамент: он используется в исполнителях или документах.",
                    "Удаление невозможно", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Удалить запись «" + item.Name + "»?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Database.Departments.Remove(item);
                Database.SaveDepartments();
                RefreshGrid();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
