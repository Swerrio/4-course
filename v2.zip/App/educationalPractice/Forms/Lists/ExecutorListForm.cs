﻿using System;
using System.Linq;
using System.Windows.Forms;
using educationalPractice.Data;
using educationalPractice.Forms.Edit;
using educationalPractice.Models;

namespace educationalPractice.Forms.Lists
{

    public partial class ExecutorListForm : Form
    {
        public ExecutorListForm()
        {
            InitializeComponent();
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            string filter = txtSearch.Text.Trim().ToLower();

            var rows = Database.Executors
                .Where(x => string.IsNullOrEmpty(filter)
                            || x.FullName.ToLower().Contains(filter)
                            || (x.Position ?? "").ToLower().Contains(filter)
                            || Database.DepartmentName(x.DepartmentId).ToLower().Contains(filter))
                .Select(x => new
                {
                    x.Id,
                    ФИО = x.FullName,
                    Должность = x.Position,
                    Департамент = Database.DepartmentName(x.DepartmentId),
                    Телефон = x.Phone
                })
                .ToList();

            grid.DataSource = rows;
            if (grid.Columns.Contains("Id"))
                grid.Columns["Id"].Visible = false;
        }

        private Executor GetSelected()
        {
            if (grid.CurrentRow == null) return null;
            int id = (int)grid.CurrentRow.Cells["Id"].Value;
            return Database.Executors.FirstOrDefault(x => x.Id == id);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshGrid();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (Database.Departments.Count == 0)
            {
                MessageBox.Show("Сначала добавьте хотя бы один департамент.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var item = new Executor();
            using (var form = new ExecutorEditForm(item, true))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    item.Id = Database.NextExecutorId();
                    Database.Executors.Add(item);
                    Database.SaveExecutors();
                    RefreshGrid();
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для редактирования.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var form = new ExecutorEditForm(item, false))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    Database.SaveExecutors();
                    RefreshGrid();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (Database.Documents.Any(x => x.ExecutorId == item.Id))
            {
                MessageBox.Show("Нельзя удалить исполнителя: он используется в карточках документов.",
                    "Удаление невозможно", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Удалить запись «" + item.FullName + "»?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Database.Executors.Remove(item);
                Database.SaveExecutors();
                RefreshGrid();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
