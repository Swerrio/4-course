﻿using System;
using System.Linq;
using System.Windows.Forms;
using educationalPractice.Data;
using educationalPractice.Forms.Edit;
using educationalPractice.Models;

namespace educationalPractice.Forms.Lists
{

    public partial class DocumentTypeListForm : Form
    {
        public DocumentTypeListForm()
        {
            InitializeComponent();
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            string filter = txtSearch.Text.Trim().ToLower();

            var rows = Database.DocumentTypes
                .Where(t => string.IsNullOrEmpty(filter)
                            || t.Name.ToLower().Contains(filter)
                            || (t.Description ?? "").ToLower().Contains(filter))
                .Select(t => new { t.Id, Название = t.Name, Описание = t.Description })
                .ToList();

            grid.DataSource = rows;
            if (grid.Columns.Contains("Id"))
                grid.Columns["Id"].Visible = false;
        }

        private DocumentType GetSelected()
        {
            if (grid.CurrentRow == null) return null;
            int id = (int)grid.CurrentRow.Cells["Id"].Value;
            return Database.DocumentTypes.FirstOrDefault(t => t.Id == id);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshGrid();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var item = new DocumentType();
            using (var form = new DocumentTypeEditForm(item, true))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    item.Id = Database.NextDocumentTypeId();
                    Database.DocumentTypes.Add(item);
                    Database.SaveDocumentTypes();
                    RefreshGrid();
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для редактирования.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var form = new DocumentTypeEditForm(item, false))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    Database.SaveDocumentTypes();
                    RefreshGrid();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (Database.Documents.Any(x => x.DocumentTypeId == item.Id))
            {
                MessageBox.Show("Нельзя удалить вид документа: он используется в карточках документов.",
                    "Удаление невозможно", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Удалить запись «" + item.Name + "»?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Database.DocumentTypes.Remove(item);
                Database.SaveDocumentTypes();
                RefreshGrid();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
