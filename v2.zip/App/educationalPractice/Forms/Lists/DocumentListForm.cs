﻿using System;
using System.Linq;
using System.Windows.Forms;
using educationalPractice.Data;
using educationalPractice.Forms.Edit;
using educationalPractice.Models;

namespace educationalPractice.Forms.Lists
{

    public partial class DocumentListForm : Form
    {
        public DocumentListForm()
        {
            InitializeComponent();
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            string filter = txtSearch.Text.Trim().ToLower();

            var rows = Database.Documents
                .Where(d => string.IsNullOrEmpty(filter)
                            || (d.RegNumber ?? "").ToLower().Contains(filter)
                            || (d.Title ?? "").ToLower().Contains(filter)
                            || Database.DocumentTypeName(d.DocumentTypeId).ToLower().Contains(filter)
                            || Database.ExecutorName(d.ExecutorId).ToLower().Contains(filter)
                            || (d.Status ?? "").ToLower().Contains(filter))
                .Select(d => new
                {
                    d.Id,
                    Номер = d.RegNumber,
                    Заголовок = d.Title,
                    Вид = Database.DocumentTypeName(d.DocumentTypeId),
                    Исполнитель = Database.ExecutorName(d.ExecutorId),
                    Департамент = Database.DepartmentName(d.DepartmentId),
                    Дата = d.RegDate,
                    Статус = d.Status
                })
                .ToList();

            grid.DataSource = rows;
            if (grid.Columns.Contains("Id"))
                grid.Columns["Id"].Visible = false;
        }

        private Document GetSelected()
        {
            if (grid.CurrentRow == null) return null;
            int id = (int)grid.CurrentRow.Cells["Id"].Value;
            return Database.Documents.FirstOrDefault(d => d.Id == id);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshGrid();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (Database.DocumentTypes.Count == 0 || Database.Executors.Count == 0 || Database.Departments.Count == 0)
            {
                MessageBox.Show("Сначала заполните справочники: виды документов, исполнители и департаменты.",
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var item = new Document { RegDate = DateTime.Today.ToString("dd.MM.yyyy") };
            using (var form = new DocumentEditForm(item, true))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    item.Id = Database.NextDocumentId();
                    Database.Documents.Add(item);
                    Database.SaveDocuments();
                    RefreshGrid();
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для редактирования.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var form = new DocumentEditForm(item, false))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    Database.SaveDocuments();
                    RefreshGrid();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var item = GetSelected();
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Удалить документ «" + item.Title + "»?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Database.Documents.Remove(item);
                Database.SaveDocuments();
                RefreshGrid();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
