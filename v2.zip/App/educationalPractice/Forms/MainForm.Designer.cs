﻿namespace educationalPractice.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.btnDocuments = new System.Windows.Forms.Button();
            this.btnTypes = new System.Windows.Forms.Button();
            this.btnExecutors = new System.Windows.Forms.Button();
            this.btnDepartments = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(20, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(380, 70);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Информационная система\n«Делопроизводство»";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            this.lblUser.AutoSize = true;
            this.lblUser.ForeColor = System.Drawing.Color.DimGray;
            this.lblUser.Location = new System.Drawing.Point(22, 90);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 15);
            this.lblUser.TabIndex = 1;

            this.btnDocuments.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDocuments.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnDocuments.Location = new System.Drawing.Point(60, 120);
            this.btnDocuments.Name = "btnDocuments";
            this.btnDocuments.Size = new System.Drawing.Size(300, 42);
            this.btnDocuments.TabIndex = 2;
            this.btnDocuments.Text = "Карточки документов";
            this.btnDocuments.Click += new System.EventHandler(this.btnDocuments_Click);

            this.btnTypes.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnTypes.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnTypes.Location = new System.Drawing.Point(60, 170);
            this.btnTypes.Name = "btnTypes";
            this.btnTypes.Size = new System.Drawing.Size(300, 42);
            this.btnTypes.TabIndex = 3;
            this.btnTypes.Text = "Виды документов";
            this.btnTypes.Click += new System.EventHandler(this.btnTypes_Click);

            this.btnExecutors.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExecutors.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnExecutors.Location = new System.Drawing.Point(60, 220);
            this.btnExecutors.Name = "btnExecutors";
            this.btnExecutors.Size = new System.Drawing.Size(300, 42);
            this.btnExecutors.TabIndex = 4;
            this.btnExecutors.Text = "Исполнители";
            this.btnExecutors.Click += new System.EventHandler(this.btnExecutors_Click);

            this.btnDepartments.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDepartments.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnDepartments.Location = new System.Drawing.Point(60, 270);
            this.btnDepartments.Name = "btnDepartments";
            this.btnDepartments.Size = new System.Drawing.Size(300, 42);
            this.btnDepartments.TabIndex = 5;
            this.btnDepartments.Text = "Департаменты";
            this.btnDepartments.Click += new System.EventHandler(this.btnDepartments_Click);

            this.btnExit.BackColor = System.Drawing.Color.MistyRose;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnExit.Location = new System.Drawing.Point(60, 330);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(300, 42);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Выход";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 400);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.btnDocuments);
            this.Controls.Add(this.btnTypes);
            this.Controls.Add(this.btnExecutors);
            this.Controls.Add(this.btnDepartments);
            this.Controls.Add(this.btnExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ИС «Делопроизводство» - Главное меню";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnDocuments;
        private System.Windows.Forms.Button btnTypes;
        private System.Windows.Forms.Button btnExecutors;
        private System.Windows.Forms.Button btnDepartments;
        private System.Windows.Forms.Button btnExit;
    }
}
