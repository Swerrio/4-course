﻿using System;
using System.Windows.Forms;
using educationalPractice.Forms.Lists;

namespace educationalPractice.Forms
{

    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            if (LoginForm.CurrentUser != null)
                lblUser.Text = "Пользователь: " + LoginForm.CurrentUser.FullName;
            else
                lblUser.Text = "";
        }

        private void btnDocuments_Click(object sender, EventArgs e)
        {
            new DocumentListForm().ShowDialog();
        }

        private void btnTypes_Click(object sender, EventArgs e)
        {
            new DocumentTypeListForm().ShowDialog();
        }

        private void btnExecutors_Click(object sender, EventArgs e)
        {
            new ExecutorListForm().ShowDialog();
        }

        private void btnDepartments_Click(object sender, EventArgs e)
        {
            new DepartmentListForm().ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
