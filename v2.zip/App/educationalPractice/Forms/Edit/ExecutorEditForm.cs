﻿using System;
using System.Linq;
using System.Windows.Forms;
using educationalPractice.Data;
using educationalPractice.Models;

namespace educationalPractice.Forms.Edit
{

    public partial class ExecutorEditForm : Form
    {
        private readonly Executor _item;

        public ExecutorEditForm()
        {
            InitializeComponent();
        }

        public ExecutorEditForm(Executor item, bool isNew) : this()
        {
            _item = item;
            Text = isNew ? "Добавление исполнителя" : "Редактирование исполнителя";

            cboDepartment.DataSource = Database.Departments.ToList();

            FillFields();
        }

        private void FillFields()
        {
            txtFullName.Text = _item.FullName;
            txtPosition.Text = _item.Position;
            txtPhone.Text = _item.Phone;

            var current = cboDepartment.Items
                .Cast<Department>()
                .FirstOrDefault(d => d.Id == _item.DepartmentId);
            if (current != null)
                cboDepartment.SelectedItem = current;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                MessageBox.Show("Укажите ФИО исполнителя.", "Проверка",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFullName.Focus();
                return;
            }

            if (cboDepartment.SelectedItem == null)
            {
                MessageBox.Show("Сначала добавьте хотя бы один департамент.", "Проверка",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            _item.FullName = txtFullName.Text.Trim();
            _item.Position = txtPosition.Text.Trim();
            _item.Phone = txtPhone.Text.Trim();
            _item.DepartmentId = ((Department)cboDepartment.SelectedItem).Id;

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
