﻿using System;
using System.Windows.Forms;
using educationalPractice.Models;

namespace educationalPractice.Forms.Edit
{

    public partial class DocumentTypeEditForm : Form
    {
        private readonly DocumentType _item;

        public DocumentTypeEditForm()
        {
            InitializeComponent();
        }

        public DocumentTypeEditForm(DocumentType item, bool isNew) : this()
        {
            _item = item;
            Text = isNew ? "Добавление вида документа" : "Редактирование вида документа";
            FillFields();
        }

        private void FillFields()
        {
            txtName.Text = _item.Name;
            txtDescription.Text = _item.Description;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Укажите название вида документа.", "Проверка",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtName.Focus();
                return;
            }

            _item.Name = txtName.Text.Trim();
            _item.Description = txtDescription.Text.Trim();

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
