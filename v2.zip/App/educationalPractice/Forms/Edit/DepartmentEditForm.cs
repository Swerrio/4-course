﻿using System;
using System.Windows.Forms;
using educationalPractice.Models;

namespace educationalPractice.Forms.Edit
{

    public partial class DepartmentEditForm : Form
    {
        private readonly Department _item;

        public DepartmentEditForm()
        {
            InitializeComponent();
        }

        public DepartmentEditForm(Department item, bool isNew) : this()
        {
            _item = item;
            Text = isNew ? "Добавление департамента" : "Редактирование департамента";
            FillFields();
        }

        private void FillFields()
        {
            txtName.Text = _item.Name;
            txtHead.Text = _item.Head;
            txtPhone.Text = _item.Phone;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Укажите название департамента.", "Проверка",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtName.Focus();
                return;
            }

            _item.Name = txtName.Text.Trim();
            _item.Head = txtHead.Text.Trim();
            _item.Phone = txtPhone.Text.Trim();

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
