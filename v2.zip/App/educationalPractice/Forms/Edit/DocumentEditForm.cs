﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using educationalPractice.Data;
using educationalPractice.Models;

namespace educationalPractice.Forms.Edit
{

    public partial class DocumentEditForm : Form
    {
        private readonly Document _item;

        public DocumentEditForm()
        {
            InitializeComponent();
        }

        public DocumentEditForm(Document item, bool isNew) : this()
        {
            _item = item;
            Text = isNew ? "Добавление карточки документа" : "Редактирование карточки документа";

            cboType.DataSource = Database.DocumentTypes.ToList();
            cboExecutor.DataSource = Database.Executors.ToList();
            cboDepartment.DataSource = Database.Departments.ToList();

            FillFields();
        }

        private void FillFields()
        {
            txtRegNumber.Text = _item.RegNumber;
            txtTitle.Text = _item.Title;
            txtContent.Text = _item.Content;

            SelectById(cboType, _item.DocumentTypeId);
            SelectById(cboExecutor, _item.ExecutorId);
            SelectById(cboDepartment, _item.DepartmentId);

            DateTime date;
            if (DateTime.TryParseExact(_item.RegDate, "dd.MM.yyyy",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                dtpDate.Value = date;
            else
                dtpDate.Value = DateTime.Today;

            cboStatus.SelectedItem = string.IsNullOrEmpty(_item.Status) ? "Новый" : _item.Status;
            if (cboStatus.SelectedItem == null && cboStatus.Items.Count > 0)
                cboStatus.SelectedIndex = 0;
        }

        private void SelectById(ComboBox combo, int id)
        {
            foreach (var obj in combo.Items)
            {
                int objId = (int)obj.GetType().GetProperty("Id").GetValue(obj, null);
                if (objId == id)
                {
                    combo.SelectedItem = obj;
                    return;
                }
            }
            if (combo.Items.Count > 0)
                combo.SelectedIndex = 0;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRegNumber.Text))
            {
                MessageBox.Show("Укажите регистрационный номер документа.", "Проверка",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtRegNumber.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Укажите заголовок документа.", "Проверка",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTitle.Focus();
                return;
            }

            if (cboType.SelectedItem == null || cboExecutor.SelectedItem == null || cboDepartment.SelectedItem == null)
            {
                MessageBox.Show("Заполните справочники: виды документов, исполнители и департаменты должны быть непустыми.",
                    "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            _item.RegNumber = txtRegNumber.Text.Trim();
            _item.Title = txtTitle.Text.Trim();
            _item.DocumentTypeId = ((DocumentType)cboType.SelectedItem).Id;
            _item.ExecutorId = ((Executor)cboExecutor.SelectedItem).Id;
            _item.DepartmentId = ((Department)cboDepartment.SelectedItem).Id;
            _item.RegDate = dtpDate.Value.ToString("dd.MM.yyyy");
            _item.Status = cboStatus.SelectedItem != null ? cboStatus.SelectedItem.ToString() : "Новый";
            _item.Content = txtContent.Text.Trim();

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
