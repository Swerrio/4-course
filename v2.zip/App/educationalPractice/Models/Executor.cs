﻿namespace educationalPractice.Models
{

    public class Executor
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Position { get; set; }
        public int DepartmentId { get; set; }
        public string Phone { get; set; }

        public Executor()
        {
            FullName = "";
            Position = "";
            Phone = "";
        }

        public override string ToString()
        {
            return FullName;
        }
    }
}
