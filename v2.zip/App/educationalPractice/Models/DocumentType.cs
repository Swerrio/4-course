﻿namespace educationalPractice.Models
{

    public class DocumentType
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public DocumentType()
        {
            Name = "";
            Description = "";
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
