﻿namespace educationalPractice.Models
{

    public class User
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }

        public User()
        {
            Login = "";
            Password = "";
            FullName = "";
            Role = "Пользователь";
        }
    }
}
