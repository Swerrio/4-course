﻿namespace educationalPractice.Models
{

    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Head { get; set; }
        public string Phone { get; set; }

        public Department()
        {
            Name = "";
            Head = "";
            Phone = "";
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
