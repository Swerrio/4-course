﻿namespace educationalPractice.Models
{

    public class Document
    {
        public int Id { get; set; }
        public string RegNumber { get; set; }
        public string Title { get; set; }
        public int DocumentTypeId { get; set; }
        public int ExecutorId { get; set; }
        public int DepartmentId { get; set; }

        public string RegDate { get; set; }
        public string Status { get; set; }
        public string Content { get; set; }

        public Document()
        {
            RegNumber = "";
            Title = "";
            RegDate = "";
            Status = "Новый";
            Content = "";
        }
    }
}
