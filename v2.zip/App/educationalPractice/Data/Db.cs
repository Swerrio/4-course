﻿using System.Configuration;
using Npgsql;

namespace educationalPractice.Data
{
    public static class Db
    {
        public static string ConnectionString
        {
            get
            {
                var cs = ConfigurationManager.ConnectionStrings["Postgres"];
                if (cs != null && !string.IsNullOrWhiteSpace(cs.ConnectionString))
                    return cs.ConnectionString;
                return "Host=localhost;Port=5432;Database=praktika_db;Username=postgres;Password=Swerrio";
            }
        }

        public static NpgsqlConnection Open()
        {
            var conn = new NpgsqlConnection(ConnectionString);
            conn.Open();
            return conn;
        }
    }
}
