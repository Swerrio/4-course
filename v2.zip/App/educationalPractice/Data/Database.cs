﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Npgsql;
using NpgsqlTypes;
using educationalPractice.Models;

namespace educationalPractice.Data
{
    public static class Database
    {
        public static List<User> Users { get; private set; }
        public static List<Department> Departments { get; private set; }
        public static List<DocumentType> DocumentTypes { get; private set; }
        public static List<Executor> Executors { get; private set; }
        public static List<Document> Documents { get; private set; }

        public static void Load()
        {
            EnsureSchema();

            Users = ReadUsers();
            Departments = ReadDepartments();
            DocumentTypes = ReadDocumentTypes();
            Executors = ReadExecutors();
            Documents = ReadDocuments();

            SeedIfEmpty();
        }

        private static void EnsureSchema()
        {
            const string sql = @"
CREATE TABLE IF NOT EXISTS users (
    id        integer PRIMARY KEY,
    login     varchar(50)  NOT NULL,
    password  varchar(100) NOT NULL,
    full_name varchar(150),
    role      varchar(50)
);
CREATE TABLE IF NOT EXISTS departments (
    id    integer PRIMARY KEY,
    name  varchar(150) NOT NULL,
    head  varchar(150),
    phone varchar(50)
);
CREATE TABLE IF NOT EXISTS document_types (
    id          integer PRIMARY KEY,
    name        varchar(150) NOT NULL,
    description varchar(500)
);
CREATE TABLE IF NOT EXISTS executors (
    id            integer PRIMARY KEY,
    full_name     varchar(150) NOT NULL,
    position      varchar(150),
    department_id integer REFERENCES departments(id),
    phone         varchar(50)
);
CREATE TABLE IF NOT EXISTS documents (
    id               integer PRIMARY KEY,
    reg_number       varchar(50),
    title            varchar(300) NOT NULL,
    document_type_id integer REFERENCES document_types(id),
    executor_id      integer REFERENCES executors(id),
    department_id    integer REFERENCES departments(id),
    reg_date         date,
    status           varchar(50),
    content          text
);";
            using (var conn = Db.Open())
            using (var cmd = new NpgsqlCommand(sql, conn))
                cmd.ExecuteNonQuery();
        }

        // ---------- Чтение таблиц ----------

        private static List<User> ReadUsers()
        {
            var list = new List<User>();
            using (var conn = Db.Open())
            using (var cmd = new NpgsqlCommand(
                "SELECT id, login, password, full_name, role FROM users ORDER BY id", conn))
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    list.Add(new User
                    {
                        Id = r.GetInt32(0),
                        Login = Str(r, 1),
                        Password = Str(r, 2),
                        FullName = Str(r, 3),
                        Role = Str(r, 4)
                    });
            return list;
        }

        private static List<Department> ReadDepartments()
        {
            var list = new List<Department>();
            using (var conn = Db.Open())
            using (var cmd = new NpgsqlCommand(
                "SELECT id, name, head, phone FROM departments ORDER BY id", conn))
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    list.Add(new Department
                    {
                        Id = r.GetInt32(0),
                        Name = Str(r, 1),
                        Head = Str(r, 2),
                        Phone = Str(r, 3)
                    });
            return list;
        }

        private static List<DocumentType> ReadDocumentTypes()
        {
            var list = new List<DocumentType>();
            using (var conn = Db.Open())
            using (var cmd = new NpgsqlCommand(
                "SELECT id, name, description FROM document_types ORDER BY id", conn))
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    list.Add(new DocumentType
                    {
                        Id = r.GetInt32(0),
                        Name = Str(r, 1),
                        Description = Str(r, 2)
                    });
            return list;
        }

        private static List<Executor> ReadExecutors()
        {
            var list = new List<Executor>();
            using (var conn = Db.Open())
            using (var cmd = new NpgsqlCommand(
                "SELECT id, full_name, position, department_id, phone FROM executors ORDER BY id", conn))
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    list.Add(new Executor
                    {
                        Id = r.GetInt32(0),
                        FullName = Str(r, 1),
                        Position = Str(r, 2),
                        DepartmentId = r.IsDBNull(3) ? 0 : r.GetInt32(3),
                        Phone = Str(r, 4)
                    });
            return list;
        }

        private static List<Document> ReadDocuments()
        {
            var list = new List<Document>();
            using (var conn = Db.Open())
            using (var cmd = new NpgsqlCommand(
                "SELECT id, reg_number, title, document_type_id, executor_id, department_id, reg_date, status, content FROM documents ORDER BY id", conn))
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    list.Add(new Document
                    {
                        Id = r.GetInt32(0),
                        RegNumber = Str(r, 1),
                        Title = Str(r, 2),
                        DocumentTypeId = r.IsDBNull(3) ? 0 : r.GetInt32(3),
                        ExecutorId = r.IsDBNull(4) ? 0 : r.GetInt32(4),
                        DepartmentId = r.IsDBNull(5) ? 0 : r.GetInt32(5),
                        RegDate = r.IsDBNull(6) ? "" : r.GetDateTime(6).ToString("dd.MM.yyyy"),
                        Status = Str(r, 7),
                        Content = Str(r, 8)
                    });
            return list;
        }

        private static string Str(NpgsqlDataReader r, int i)
        {
            return r.IsDBNull(i) ? "" : r.GetString(i);
        }

        // ---------- Сохранение таблиц (вставка/обновление + удаление лишнего) ----------

        public static void SaveUsers()
        {
            using (var conn = Db.Open())
            using (var tx = conn.BeginTransaction())
            {
                foreach (var u in Users)
                    using (var cmd = new NpgsqlCommand(
                        @"INSERT INTO users (id, login, password, full_name, role)
                          VALUES (@id,@login,@password,@full_name,@role)
                          ON CONFLICT (id) DO UPDATE SET
                            login=excluded.login, password=excluded.password,
                            full_name=excluded.full_name, role=excluded.role", conn, tx))
                    {
                        cmd.Parameters.AddWithValue("id", u.Id);
                        cmd.Parameters.AddWithValue("login", (object)u.Login ?? "");
                        cmd.Parameters.AddWithValue("password", (object)u.Password ?? "");
                        cmd.Parameters.AddWithValue("full_name", (object)u.FullName ?? "");
                        cmd.Parameters.AddWithValue("role", (object)u.Role ?? "");
                        cmd.ExecuteNonQuery();
                    }
                Prune(conn, tx, "users", Users.Select(x => x.Id));
                tx.Commit();
            }
        }

        public static void SaveDepartments()
        {
            using (var conn = Db.Open())
            using (var tx = conn.BeginTransaction())
            {
                foreach (var d in Departments)
                    using (var cmd = new NpgsqlCommand(
                        @"INSERT INTO departments (id, name, head, phone)
                          VALUES (@id,@name,@head,@phone)
                          ON CONFLICT (id) DO UPDATE SET
                            name=excluded.name, head=excluded.head, phone=excluded.phone", conn, tx))
                    {
                        cmd.Parameters.AddWithValue("id", d.Id);
                        cmd.Parameters.AddWithValue("name", (object)d.Name ?? "");
                        cmd.Parameters.AddWithValue("head", (object)d.Head ?? "");
                        cmd.Parameters.AddWithValue("phone", (object)d.Phone ?? "");
                        cmd.ExecuteNonQuery();
                    }
                Prune(conn, tx, "departments", Departments.Select(x => x.Id));
                tx.Commit();
            }
        }

        public static void SaveDocumentTypes()
        {
            using (var conn = Db.Open())
            using (var tx = conn.BeginTransaction())
            {
                foreach (var t in DocumentTypes)
                    using (var cmd = new NpgsqlCommand(
                        @"INSERT INTO document_types (id, name, description)
                          VALUES (@id,@name,@description)
                          ON CONFLICT (id) DO UPDATE SET
                            name=excluded.name, description=excluded.description", conn, tx))
                    {
                        cmd.Parameters.AddWithValue("id", t.Id);
                        cmd.Parameters.AddWithValue("name", (object)t.Name ?? "");
                        cmd.Parameters.AddWithValue("description", (object)t.Description ?? "");
                        cmd.ExecuteNonQuery();
                    }
                Prune(conn, tx, "document_types", DocumentTypes.Select(x => x.Id));
                tx.Commit();
            }
        }

        public static void SaveExecutors()
        {
            using (var conn = Db.Open())
            using (var tx = conn.BeginTransaction())
            {
                foreach (var e in Executors)
                    using (var cmd = new NpgsqlCommand(
                        @"INSERT INTO executors (id, full_name, position, department_id, phone)
                          VALUES (@id,@full_name,@position,@department_id,@phone)
                          ON CONFLICT (id) DO UPDATE SET
                            full_name=excluded.full_name, position=excluded.position,
                            department_id=excluded.department_id, phone=excluded.phone", conn, tx))
                    {
                        cmd.Parameters.AddWithValue("id", e.Id);
                        cmd.Parameters.AddWithValue("full_name", (object)e.FullName ?? "");
                        cmd.Parameters.AddWithValue("position", (object)e.Position ?? "");
                        cmd.Parameters.AddWithValue("department_id", e.DepartmentId);
                        cmd.Parameters.AddWithValue("phone", (object)e.Phone ?? "");
                        cmd.ExecuteNonQuery();
                    }
                Prune(conn, tx, "executors", Executors.Select(x => x.Id));
                tx.Commit();
            }
        }

        public static void SaveDocuments()
        {
            using (var conn = Db.Open())
            using (var tx = conn.BeginTransaction())
            {
                foreach (var d in Documents)
                    using (var cmd = new NpgsqlCommand(
                        @"INSERT INTO documents (id, reg_number, title, document_type_id, executor_id, department_id, reg_date, status, content)
                          VALUES (@id,@reg_number,@title,@document_type_id,@executor_id,@department_id,@reg_date,@status,@content)
                          ON CONFLICT (id) DO UPDATE SET
                            reg_number=excluded.reg_number, title=excluded.title,
                            document_type_id=excluded.document_type_id, executor_id=excluded.executor_id,
                            department_id=excluded.department_id, reg_date=excluded.reg_date,
                            status=excluded.status, content=excluded.content", conn, tx))
                    {
                        cmd.Parameters.AddWithValue("id", d.Id);
                        cmd.Parameters.AddWithValue("reg_number", (object)d.RegNumber ?? "");
                        cmd.Parameters.AddWithValue("title", (object)d.Title ?? "");
                        cmd.Parameters.AddWithValue("document_type_id", d.DocumentTypeId);
                        cmd.Parameters.AddWithValue("executor_id", d.ExecutorId);
                        cmd.Parameters.AddWithValue("department_id", d.DepartmentId);
                        var dateParam = cmd.Parameters.Add("reg_date", NpgsqlDbType.Date);
                        dateParam.Value = (object)ParseDate(d.RegDate) ?? DBNull.Value;
                        cmd.Parameters.AddWithValue("status", (object)d.Status ?? "");
                        cmd.Parameters.AddWithValue("content", (object)d.Content ?? "");
                        cmd.ExecuteNonQuery();
                    }
                Prune(conn, tx, "documents", Documents.Select(x => x.Id));
                tx.Commit();
            }
        }

        // Удаляет из таблицы записи, которых больше нет в списке приложения.
        private static void Prune(NpgsqlConnection conn, NpgsqlTransaction tx, string table, IEnumerable<int> ids)
        {
            var arr = ids.ToArray();
            using (var cmd = new NpgsqlCommand(
                "DELETE FROM " + table + " WHERE id <> ALL(@ids)", conn, tx))
            {
                cmd.Parameters.AddWithValue("ids", arr);
                cmd.ExecuteNonQuery();
            }
        }

        private static object ParseDate(string s)
        {
            DateTime dt;
            if (DateTime.TryParseExact(s, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
                return dt;
            return null;
        }

        // ---------- Идентификаторы ----------

        public static int NextUserId() { return Users.Count == 0 ? 1 : Users.Max(x => x.Id) + 1; }
        public static int NextDepartmentId() { return Departments.Count == 0 ? 1 : Departments.Max(x => x.Id) + 1; }
        public static int NextDocumentTypeId() { return DocumentTypes.Count == 0 ? 1 : DocumentTypes.Max(x => x.Id) + 1; }
        public static int NextExecutorId() { return Executors.Count == 0 ? 1 : Executors.Max(x => x.Id) + 1; }
        public static int NextDocumentId() { return Documents.Count == 0 ? 1 : Documents.Max(x => x.Id) + 1; }

        // ---------- Поиск названий по Id ----------

        public static string DepartmentName(int id)
        {
            var d = Departments.FirstOrDefault(x => x.Id == id);
            return d != null ? d.Name : "";
        }

        public static string DocumentTypeName(int id)
        {
            var t = DocumentTypes.FirstOrDefault(x => x.Id == id);
            return t != null ? t.Name : "";
        }

        public static string ExecutorName(int id)
        {
            var e = Executors.FirstOrDefault(x => x.Id == id);
            return e != null ? e.FullName : "";
        }

        public static User Authenticate(string login, string password)
        {
            return Users.FirstOrDefault(u =>
                string.Equals(u.Login, login, StringComparison.OrdinalIgnoreCase) &&
                u.Password == password);
        }

        private static void SeedIfEmpty()
        {
            if (Users.Count == 0)
            {
                Users.Add(new User
                {
                    Id = 1,
                    Login = "admin",
                    Password = "admin",
                    FullName = "Администратор",
                    Role = "Администратор"
                });
                SaveUsers();
            }

            if (Departments.Count == 0)
            {
                Departments.Add(new Department { Id = 1, Name = "Канцелярия", Head = "Иванова И.И.", Phone = "101" });
                Departments.Add(new Department { Id = 2, Name = "Бухгалтерия", Head = "Петрова П.П.", Phone = "102" });
                Departments.Add(new Department { Id = 3, Name = "Отдел кадров", Head = "Сидоров С.С.", Phone = "103" });
                SaveDepartments();
            }

            if (DocumentTypes.Count == 0)
            {
                DocumentTypes.Add(new DocumentType { Id = 1, Name = "Приказ", Description = "Распорядительный документ" });
                DocumentTypes.Add(new DocumentType { Id = 2, Name = "Письмо", Description = "Деловая переписка" });
                DocumentTypes.Add(new DocumentType { Id = 3, Name = "Договор", Description = "Соглашение сторон" });
                DocumentTypes.Add(new DocumentType { Id = 4, Name = "Служебная записка", Description = "Внутренний документ" });
                SaveDocumentTypes();
            }

            if (Executors.Count == 0)
            {
                Executors.Add(new Executor { Id = 1, FullName = "Иванова Ирина Ивановна", Position = "Секретарь", DepartmentId = 1, Phone = "101" });
                Executors.Add(new Executor { Id = 2, FullName = "Петрова Полина Петровна", Position = "Бухгалтер", DepartmentId = 2, Phone = "102" });
                Executors.Add(new Executor { Id = 3, FullName = "Сидоров Семён Семёнович", Position = "Инспектор по кадрам", DepartmentId = 3, Phone = "103" });
                SaveExecutors();
            }

            if (Documents.Count == 0)
            {
                Documents.Add(new Document
                {
                    Id = 1,
                    RegNumber = "01-15/001",
                    Title = "О приёме на работу",
                    DocumentTypeId = 1,
                    ExecutorId = 3,
                    DepartmentId = 3,
                    RegDate = DateTime.Today.ToString("dd.MM.yyyy"),
                    Status = "Исполнен",
                    Content = "Приказ о приёме сотрудника на должность."
                });
                SaveDocuments();
            }
        }
    }
}
