-- ============================================================
-- ИС «Делопроизводство». Схема базы данных PostgreSQL.
-- Выполнять в базе praktika_db (Query Tool в pgAdmin 4).
-- Создание самой базы: CREATE DATABASE praktika_db;
-- ============================================================
SET client_encoding = 'UTF8';

-- Пользователи (для формы авторизации)
CREATE TABLE IF NOT EXISTS users (
    id        integer PRIMARY KEY,
    login     varchar(50)  NOT NULL,
    password  varchar(100) NOT NULL,
    full_name varchar(150),
    role      varchar(50)
);

-- Департаменты
CREATE TABLE IF NOT EXISTS departments (
    id    integer PRIMARY KEY,
    name  varchar(150) NOT NULL,
    head  varchar(150),
    phone varchar(50)
);

-- Виды документов
CREATE TABLE IF NOT EXISTS document_types (
    id          integer PRIMARY KEY,
    name        varchar(150) NOT NULL,
    description varchar(500)
);

-- Исполнители
CREATE TABLE IF NOT EXISTS executors (
    id            integer PRIMARY KEY,
    full_name     varchar(150) NOT NULL,
    position      varchar(150),
    department_id integer REFERENCES departments(id),
    phone         varchar(50)
);

-- Карточки документов
CREATE TABLE IF NOT EXISTS documents (
    id               integer PRIMARY KEY,
    reg_number       varchar(50),
    title            varchar(300) NOT NULL,
    document_type_id integer REFERENCES document_types(id),
    executor_id      integer REFERENCES executors(id),
    department_id    integer REFERENCES departments(id),
    reg_date         date,
    status           varchar(50),
    content          text
);

-- ============================================================
-- Начальные (тестовые) данные
-- ============================================================
INSERT INTO users (id, login, password, full_name, role) VALUES
    (1, 'admin', 'admin', 'Администратор', 'Администратор')
ON CONFLICT (id) DO NOTHING;

INSERT INTO departments (id, name, head, phone) VALUES
    (1, 'Канцелярия',   'Иванова И.И.', '101'),
    (2, 'Бухгалтерия',  'Петрова П.П.', '102'),
    (3, 'Отдел кадров', 'Сидоров С.С.', '103')
ON CONFLICT (id) DO NOTHING;

INSERT INTO document_types (id, name, description) VALUES
    (1, 'Приказ',            'Распорядительный документ'),
    (2, 'Письмо',            'Деловая переписка'),
    (3, 'Договор',           'Соглашение сторон'),
    (4, 'Служебная записка', 'Внутренний документ')
ON CONFLICT (id) DO NOTHING;

INSERT INTO executors (id, full_name, position, department_id, phone) VALUES
    (1, 'Иванова Ирина Ивановна',   'Секретарь',           1, '101'),
    (2, 'Петрова Полина Петровна',  'Бухгалтер',           2, '102'),
    (3, 'Сидоров Семён Семёнович',  'Инспектор по кадрам', 3, '103')
ON CONFLICT (id) DO NOTHING;

INSERT INTO documents (id, reg_number, title, document_type_id, executor_id, department_id, reg_date, status, content) VALUES
    (1, '01-15/001', 'О приёме на работу', 1, 3, 3, DATE '2026-06-09', 'Исполнен', 'Приказ о приёме сотрудника на должность.')
ON CONFLICT (id) DO NOTHING;
